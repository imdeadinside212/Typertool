if (typeof jamActions !== "object") {var jamActions = {};(function() {jamActions.isActionsFile = function(e) {return e.type === "8BAC" || e.name.match(/\.atn$/i);};jamActions.isActionsPalette = function(e) {return e.type === "8BPF" && e.name.match(/^Actions Palette$/i) || e.name.match(/^Actions Palette.psp$/i);};function l(e, t) {var r = e.read(t);var a = 0;for (var n = 0; n < t; n++) {a = (a << 8) + r.charCodeAt(n);}return a;}function o(e, t) {return e.read(t);}function u(e) {var t = l(e, 4);return o(e, t);}function p(e) {var t = "";var r = l(e, 4);for (var a = 0; a < r; a++) {var n = l(e, 2);if (n !== 0) {t += String.fromCharCode(n);}}return t;}function y(e) {var t = 0;var r = o(e, 4);switch (r) {case "TEXT":t = app.stringIDToTypeID(u(e));break;case "long":t = app.charIDToTypeID(o(e, 4));break;default:throw new Error("[jamActions readEventId] Unrecognized event type: '" + r + "'");break;}return t;}function s(e) {e.seek(8, 1);}function c(e, t) {e.seek(t * 8, 1);}function f(e) {e.seek(1, 1);}function e(e) {e.seek(2, 1);}function h(e) {e.seek(4, 1);}function g(e) {e.seek(8, 1);}function d(e, t) {e.seek(t, 1);}function v(e) {var t = l(e, 4);d(e, t);}function m(e) {var t = l(e, 4);d(e, t * 2);}function T(e) {var t = l(e, 4);if (t) {d(e, t);} else {d(e, 4);}}function I(e) {m(e);T(e);}function D(e) {I(e);var t = l(e, 4);for (var r = 0; r < t; r++) {T(e);a(e);}}function b(e) {var t = l(e, 4);for (var r = 0; r < t; r++) {a(e);}}function a(e) {var t = o(e, 4);switch (t) {case "obj ":S(e);break;case "Objc":case "GlbO":D(e);break;case "type":case "GlbC":I(e);break;case "VlLs":b(e);break;case "doub":s(e);break;case "UntF":d(e, 4);s(e);break;case "TEXT":m(e);break;case "enum":T(e);T(e);break;case "long":h(e);break;case "comp":g(e);break;case "bool":f(e);break;case "alis":v(e);break;case "Pth ":v(e);break;case "tdta":v(e);break;case "ObAr":var r = l(e, 4);I(e);var a = l(e, 4);for (var n = 0; n < a; n++) {T(e);h(e);h(e);var i = l(e, 4);c(e, i);}break;default:throw new Error("[jamActions skipItem] Unrecognized item type: '" + t + "'");break;}}function S(e) {var t = l(e, 4);for (var r = 0; r < t; r++) {var a = o(e, 4);I(e);switch (a) {case "Clss":break;case "prop":T(e);break;case "Enmr":T(e);T(e);break;case "rele":h(e);break;case "Idnt":h(e);break;case "indx":h(e);break;case "name":m(e);break;default:throw new Error("[jamActions skipReference] Unrecognized item form: '" + a + "'");break;}}}jamActions.readActionDescriptor = function(e, t) {var r = "\0\0\0";var a = e.tell();if (!t) {if (e.read(4) === r) {r = "";} else {throw new Error("[jamActions.readActionDescriptor] Unrecognized version prefix");}}D(e);var n = e.tell();e.seek(a, 0);var i = r + e.read(n - a);var o = new ActionDescriptor();o.fromStream(i);return o;};jamActions.dataFromActionsFile = function(e, t) {var c = this;function r(e) {var t = {};t.name = localize(p(e));t.expanded = l(e, 1) !== 0;var r = l(e, 4);t.actions = [];for (var a = 0; a < r; a++) {var n = {};n.functionKey = l(e, 2);n.shiftKey = l(e, 1) !== 0;n.commandKey = l(e, 1) !== 0;n.colorIndex = l(e, 2);n.name = localize(p(e));n.expanded = l(e, 1) !== 0;var i = l(e, 4);n.commands = [];for (var o = 0; o < i; o++) {var s = {};s.expanded = l(e, 1) !== 0;s.enabled = l(e, 1) !== 0;s.withDialog = l(e, 1) !== 0;s.dialogOptions = l(e, 1);s.eventId = y(e);s.dictionaryName = u(e);if (l(e, 4) !== 0) {s.actionDescriptor = c.readActionDescriptor(e, true);}n.commands.push(s);}t.actions.push(n);}return t;}var a;if (typeof e === "string") {a = new File(e);} else if (e instanceof File) {a = e;} else {throw new Error("[jamActions.dataFromActionsFile] Invalid argument");}var n;if (a.open("r")) {try {a.encoding = "BINARY";var i = l(a, 4);if (i === 16) {n = {};n.version = i;if (t) {n.actionSets = [];var o = l(a, 4);for (var s = 0; s < o; s++) {n.actionSets.push(r(a));}} else {n.actionSet = r(a);}} else {n = "Unsupported actions file version: " + i;}} catch (e) {n = e.message;} finally {a.close();}} else {n = "Cannot open file";}return n;};jamActions.isLocalPlayCommand = function(e, t) {var r = null;if (e.eventId === app.stringIDToTypeID("play")) {var a = app.stringIDToTypeID("target");if (e.actionDescriptor.hasKey(a)) {var n = e.actionDescriptor.getReference(a);do {try {var i = n.getDesiredClass();} catch (e) {break;}switch (i) {case app.stringIDToTypeID("command"):var o = n.getIndex() - 1;break;case app.stringIDToTypeID("action"):var s = n.getName();break;case app.stringIDToTypeID("actionSet"):var c = n.getName();break;}n = n.getContainer();} while (n);}var l = app.stringIDToTypeID("continue");if (e.actionDescriptor.hasKey(l)) {var u = e.actionDescriptor.getBoolean(l);}if (typeof c !== "undefined" && c === t) {r = [ s, o, u ];}}return r;};jamActions.determineDialogMode = function(e) {var t;switch (e.dialogOptions) {case 0:t = e.withDialog ? DialogModes.ALL : DialogModes.NO;break;case 2:t = DialogModes.NO;break;case 1:case 3:t = DialogModes.ALL;break;}return t;};var x = null;jamActions.setCommandHandler = function(e) {x = e;};jamActions.traverseAction = function(e, t, a, n) {function r(e) {var t = n ? e.length : a + 1;for (var r = a; r < t; r++) {if (x !== null) {x(e[r]);}}}if (typeof a === "undefined") {a = 0;n = true;}var i = e.actions;if (typeof t === "string") {var o = t;for (var s = 0; s < i.length; s++) {var c = i[s];if (c.name === o) {r(c.commands);break;}}} else if (typeof t === "number") {var s = t;if (s >= 0 && s < i.length) {r(i[s].commands);}}};})();}if (typeof jamEngine !== "object") {var jamEngine = {};(function() {var T;jamEngine.meaningfulIds = false;jamEngine.parseFriendly = false;jamEngine.displayDialogs = DialogModes.ERROR;var a = {"'Algn'": [ "align", "alignment" ],"'AntA'": [ "antiAlias", "antiAliasedPICTAcquire" ],"'BckL'": [ "backgroundLayer", "backgroundLevel" ],"'BlcG'": [ "blackGenerationType", "blackGenerationCurve" ],"'BlcL'": [ "blackLevel", "blackLimit" ],"'Blks'": [ "blacks", "blocks" ],"'BlrM'": [ "blurMethod", "blurMore" ],"'BrgC'": [ "brightnessEvent", "brightnessContrast" ],"'BrsD'": [ "brushDetail", "brushesDefine" ],"'Brsh'": [ "brush", "brushes" ],"'Clcl'": [ "calculation", "calculations" ],"'ClrP'": [ "colorPalette", "coloredPencil" ],"'Cnst'": [ "constant", "constrain" ],"'CntC'": [ "centerCropMarks", "conteCrayon" ],"'Cntr'": [ "center", "contrast" ],"'CrtD'": [ "createDroplet", "createDuplicate" ],"'CstP'": [ "customPalette", "customPhosphors" ],"'Cstm'": [ "custom", "customPattern" ],"'Drkn'": [ "darken", "darkness" ],"'Dstr'": [ "distort", "distortion", "distribute", "distribution" ],"'Dstt'": [ "desaturate", "destWhiteMax" ],"'FlIn'": [ "fileInfo", "fillInverse" ],"'Gd  '": [ "good", "guide" ],"'GnrP'": [ "generalPreferences", "generalPrefs", "preferencesClass" ],"'GrSt'": [ "grainStippled", "graySetup" ],"'Grdn'": [ "gradientClassEvent", "gridMinor" ],"'Grn '": [ "grain", "green" ],"'Grns'": [ "graininess", "greens" ],"'HstP'": [ "historyPreferences", "historyPrefs" ],"'HstS'": [ "historyState", "historyStateSourceType" ],"'ImgP'": [ "imageCachePreferences", "imagePoint" ],"'In  '": [ "in", "stampIn" ],"'IntW'": [ "interfaceWhite", "intersectWith" ],"'Intr'": [ "interfaceIconFrameDimmed", "interlace", "interpolation", "intersect" ],"'JPEG'": [ "JPEG", "JPEGFormat" ],"'LghD'": [ "lightDirection", "lightDirectional" ],"'LghO'": [ "lightOmni", "lightenOnly" ],"'LghS'": [ "lightSource", "lightSpot" ],"'Lns '": [ "lens", "lines" ],"'Mgnt'": [ "magenta", "magentas" ],"'MrgL'": [ "mergeLayers", "mergedLayers" ],"'Mxm '": [ "maximum", "maximumQuality" ],"'NTSC'": [ "NTSC", "NTSCColors" ],"'NmbL'": [ "numberOfLayers", "numberOfLevels" ],"'PlgP'": [ "pluginPicker", "pluginPrefs" ],"'Pncl'": [ "pencilEraser", "pencilWidth" ],"'Pnt '": [ "paint", "point" ],"'Prsp'": [ "perspective", "perspectiveIndex" ],"'PrvM'": [ "previewMacThumbnail", "previewMagenta" ],"'Pstr'": [ "posterization", "posterize" ],"'RGBS'": [ "RGBSetup", "RGBSetupSource" ],"'Rds '": [ "radius", "reds" ],"'ScrD'": [ "scratchDisks", "screenDot" ],"'ShdI'": [ "shadingIntensity", "shadowIntensity" ],"'ShpC'": [ "shapeCurveType", "shapingCurve" ],"'ShrE'": [ "sharpenEdges", "shearEd" ],"'Shrp'": [ "sharpen", "sharpness" ],"'SplC'": [ "splitChannels", "supplementalCategories" ],"'Spot'": [ "spot", "spotColor" ],"'SprS'": [ "separationSetup", "sprayedStrokes" ],"'StrL'": [ "strokeLength", "strokeLocation" ],"'Strt'": [ "saturation", "start" ],"'TEXT'": [ "char", "textType" ],"'TIFF'": [ "TIFF", "TIFFFormat" ],"'TglO'": [ "toggleOptionsPalette", "toggleOthers" ],"'TrnG'": [ "transparencyGamutPreferences", "transparencyGrid", "transparencyGridSize" ],"'TrnS'": [ "transferSpec", "transparencyShape", "transparencyStop" ],"'Trns'": [ "transparency", "transparent" ],"'TxtC'": [ "textClickPoint", "textureCoverage" ],"'TxtF'": [ "textureFile", "textureFill" ],"'UsrM'": [ "userMaskEnabled", "userMaskOptions" ],"'c@#^'": [ "inherits", "pInherits" ],"'comp'": [ "comp", "sInt64" ],"'doub'": [ "floatType", "IEEE64BitFloatingPoint", "longFloat" ],"'long'": [ "integer", "longInteger", "sInt32" ],"'magn'": [ "magnitude", "uInt32" ],"'null'": [ "null", "target" ],"'shor'": [ "sInt16", "sMInt", "shortInteger" ],"'sing'": [ "IEEE32BitFloatingPoint", "sMFloat", "shortFloat" ]};jamEngine.getConflictingStringIdStrs = function(e) {return a[e] || null;};jamEngine.uniIdStrToId = function(e) {var t = 0;if (typeof e === "string") {if (e.length === 1 + 4 + 1 && e.charAt(0) === "'" && e.charAt(5) === "'") {t = app.charIDToTypeID(e.substring(1, 5));} else {t = app.stringIDToTypeID(e);}}return t;};var l = app.charIDToTypeID("    ");jamEngine.idToUniIdStrs = function(e) {var t = "";var r = app.typeIDToStringID(e);if (e >= l) {t = "'" + app.typeIDToCharID(e) + "'";if (r !== "") {if (t in a) {r = a[t];}}}return [ t, r ];};jamEngine.equivalentUniIdStrs = function(e, t) {return this.uniIdStrToId(e) === this.uniIdStrToId(t);};function h(e, t) {if (t.constructor === Array) {var r = t.length;for (var a = 0; a < r; a++) {var n = T.parseCompact(t[a]);var i = T.uniIdStrToId(n[0]);var o = T.parseCompact(n[1]);var s = o[0];var c = o[1];switch (s) {case "<class>":e.putClass(i);break;case "<enumerated>":var l = T.parseCompact(c);e.putEnumerated(i, T.uniIdStrToId(l[0]), T.uniIdStrToId(l[1]));break;case "<identifier>":e.putIdentifier(i, c);break;case "<index>":e.putIndex(i, c);break;case "<name>":e.putName(i, c);break;case "<offset>":e.putOffset(i, c);break;case "<property>":e.putProperty(i, T.uniIdStrToId(c));break;default:throw new Error("[jamEngine putInReference] Unknown reference form: " + s);break;}}} else {throw new Error("[jamEngine putInReference] JavaScript array expected");}}function g(e, t) {if (t.constructor === Array) {var r = t.length;for (var a = 0; a < r; a++) {var n = T.parseCompact(t[a]);var i = n[0];var o = n[1];switch (i) {case "<boolean>":e.putBoolean(o);break;case "<class>":e.putClass(T.uniIdStrToId(o));break;case "<data>":e.putData(o);break;case "<double>":e.putDouble(o);break;case "<enumerated>":var s = T.parseCompact(o);e.putEnumerated(T.uniIdStrToId(s[0]), T.uniIdStrToId(s[1]));break;case "<integer>":e.putInteger(o);break;case "<largeInteger>":e.putLargeInteger(o);break;case "<list>":var c = new ActionList();g(c, o);e.putList(c);break;case "<object>":var l = T.parseCompact(o);if (l[1]) {var u = new ActionDescriptor();d(u, l[1]);e.putObject(T.uniIdStrToId(l[0]), u);} else {e.putClass(T.uniIdStrToId(l[0]));}break;case "<path>":var p = new File(o);e.putPath(p);break;case "<reference>":var y = new ActionReference();h(y, o);e.putReference(y);break;case "<string>":e.putString(o);break;case "<unitDouble>":var f = T.parseCompact(o);e.putUnitDouble(T.uniIdStrToId(f[0]), f[1]);break;default:throw new Error("[jamEngine putInList] Unknown list type: " + i);break;}}} else {throw new Error("[jamEngine putInList] JavaScript array expected");}}function d(e, t) {if (t.constructor === Object) {for (var r in t) {if (t.hasOwnProperty(r)) {var a = T.uniIdStrToId(r);var n = T.parseCompact(t[r]);var i = n[0];var o = n[1];switch (i) {case "<boolean>":e.putBoolean(a, o);break;case "<class>":e.putClass(a, T.uniIdStrToId(o));break;case "<data>":e.putData(a, o);break;case "<double>":e.putDouble(a, o);break;case "<enumerated>":var s = T.parseCompact(o);e.putEnumerated(a, T.uniIdStrToId(s[0]), T.uniIdStrToId(s[1]));break;case "<integer>":e.putInteger(a, o);break;case "<largeInteger>":e.putLargeInteger(a, o);break;case "<list>":var c = new ActionList();g(c, o);e.putList(a, c);break;case "<object>":var l = T.parseCompact(o);if (l[1]) {var u = new ActionDescriptor();d(u, l[1]);e.putObject(a, T.uniIdStrToId(l[0]), u);} else {e.putClass(a, T.uniIdStrToId(l[0]));}break;case "<path>":var p = new File(o);e.putPath(a, p);break;case "<reference>":var y = new ActionReference();h(y, o);e.putReference(a, y);break;case "<string>":e.putString(a, o);break;case "<unitDouble>":var f = T.parseCompact(o);e.putUnitDouble(a, T.uniIdStrToId(f[0]), f[1]);break;default:throw new Error("[jamEngine putInDescriptor] Unknown descriptor type: " + i);break;}}}} else {throw new Error("[jamEngine putInDescriptor] JavaScript object expected");}}var u = {"'Algn'": {"<classKey>": {"bevelEmboss": "align","frameFX": "align","gradientFill": "align","gradientLayer": "align","patternFill": "align","patternLayer": "align"},"<event>": "align","<key>": "alignment"},"'AntA'": {"<class>": "antiAliasedPICTAcquire","<key>": "antiAlias"},"'BckL'": {"<class>": "backgroundLayer","<key>": "backgroundLevel"},"'BlcG'": {"<enumType>": "blackGenerationType","<key>": "blackGenerationCurve"},"'BlcL'": {"<classKey>": {"'GEfc'": "blackLevel","CMYKSetup": "blackLimit"},"<eventKey>": {"reticulation": "blackLevel"}},"'Blks'": {"<typeValue>": {"colors": "blacks","extrudeType": "blocks"}},"'BlrM'": {"<enumType>": "blurMethod","<event>": "blurMore","<key>": "blurMethod"},"'BrgC'": {"<class>": "brightnessContrast","<event>": "brightnessContrast"},"'BrsD'": {"<enumValue>": "brushesDefine","<key>": "brushDetail"},"'Brsh'": {"<class>": "brush","<classKey>": {"brushPreset": "brush","currentToolOptions": "brush","displayPrefs": "brush"},"<key>": "brushes"},"'Clcl'": {"<class>": "calculation","<enumValue>": "calculations","<key>": "calculation"},"'ClrP'": {"<typeValue>": {"'GEft'": "coloredPencil"},"<enumType>": "colorPalette","<event>": "coloredPencil"},"'Cnst'": {"<classKey>": {"channelMatrix": "constant"},"<unknown>": "constrain"},"'CntC'": {"<typeValue>": {"'GEft'": "conteCrayon"},"<event>": "conteCrayon","<key>": "centerCropMarks"},"'Cntr'": {"<classKey>": {"'GEfc'": "contrast","brightnessContrast": "contrast","document": "center","polygon": "center","quadrilateral": "center"},"<eventKey>": {"adaptCorrect": "contrast","brightnessEvent": "contrast","grain": "contrast","halftoneScreen": "contrast","sumie": "contrast","tornEdges": "contrast","waterPaper": "contrast"},"<enumValue>": "center"},"'CrtD'": {"<enumValue>": "createDuplicate","<event>": "createDroplet"},"'CstP'": {"<class>": "customPhosphors","<key>": "customPalette"},"'Cstm'": {"<enumValue>": "customPattern","<event>": "custom","<key>": "custom"},"'Drkn'": {"<enumValue>": "darken","<key>": "darkness"},"'Dstr'": {"<classKey>": {"'GEfc'": "distortion"},"<eventKey>": {"glass": "distortion","addNoise": "distribution"},"<enumType>": "distribution","<enumValue>": "distort","<event>": "distribute"},"'Dstt'": {"<enumValue>": "desaturate","<event>": "desaturate","<key>": "destWhiteMax"},"'FlIn'": {"<typeValue>": {"fillColor": "fillInverse","menuItemType": "fileInfo"},"<class>": "fileInfo","<key>": "fileInfo"},"'Gd  '": {"<class>": "guide","<enumValue>": "good"},"'GnrP'": {"<class>": "preferencesClass","<enumValue>": "generalPreferences","<key>": "generalPrefs"},"'GrSt'": {"<class>": "graySetup","<enumValue>": "grainStippled","<key>": "graySetup"},"'Grdn'": {"<class>": "gradientClassEvent","<event>": "gradientClassEvent","<key>": "gridMinor"},"'Grn '": {"<typeValue>": {"'GEft'": "grain"},"<classKey>": {"'GEfc'": "grain","RGBColor": "green","blackAndWhite": "green","channelMatrix": "green","channelMixer": "green"},"<eventKey>": {"blackAndWhite": "green","channelMixer": "green","filmGrain": "grain"},"<enumValue>": "green","<event>": "grain"},"'Grns'": {"<enumValue>": "greens","<key>": "graininess"},"'HstP'": {"<enumValue>": "historyPreferences","<key>": "historyPrefs"},"'HstS'": {"<class>": "historyState","<enumType>": "historyStateSourceType"},"'ImgP'": {"<class>": "imagePoint","<enumValue>": "imageCachePreferences"},"'In  '": {"<enumValue>": "stampIn","<key>": "in"},"'IntW'": {"<event>": "intersectWith","<key>": "interfaceWhite"},"'Intr'": {"<typeValue>": {"shapeOperation": "intersect"},"<classKey>": {"GIFFormat": "interlace","SaveForWeb": "interlace","application": "interfaceIconFrameDimmed","computedBrush": "interpolation","dBrush": "interpolation","gradientClassEvent": "interpolation","photoshopEPSFormat": "interpolation","sampledBrush": "interpolation"},"<eventKey>": {"convertMode": "interpolation","imageSize": "interpolation","transform": "interpolation"},"<event>": "intersect"},"'JPEG'": {"<class>": "JPEGFormat","<enumValue>": "JPEG"},"'LghD'": {"<enumType>": "lightDirection","<enumValue>": "lightDirectional","<key>": "lightDirection"},"'LghO'": {"<typeValue>": {"diffuseMode": "lightenOnly","lightType": "lightOmni"}},"'LghS'": {"<class>": "lightSource","<enumValue>": "lightSpot","<key>": "lightSource"},"'Lns '": {"<enumType>": "lens","<enumValue>": "lines","<key>": "lens"},"'Mgnt'": {"<typeValue>": {"channel": "magenta","colors": "magentas","guideGridColor": "magenta"},"<key>": "magenta"},"'MrgL'": {"<enumValue>": "mergedLayers","<event>": "mergeLayers"},"'Mxm '": {"<enumValue>": "maximumQuality","<event>": "maximum","<key>": "maximum"},"'NTSC'": {"<enumValue>": "NTSC","<event>": "NTSCColors"},"'NmbL'": {"<classKey>": {"'GEfc'": "numberOfLevels","document": "numberOfLayers"},"<eventKey>": {"cutout": "numberOfLevels"}},"'PlgP'": {"<class>": "pluginPrefs","<enumValue>": "pluginPicker","<key>": "pluginPrefs"},"'Pncl'": {"<enumValue>": "pencilEraser","<key>": "pencilWidth"},"'Pnt '": {"<typeValue>": {"textType": "point"},"<class>": "point","<event>": "paint"},"'Prsp'": {"<enumValue>": "perspective","<key>": "perspectiveIndex"},"'PrvM'": {"<enumValue>": "previewMagenta","<key>": "previewMacThumbnail"},"'Pstr'": {"<class>": "posterize","<event>": "posterize","<key>": "posterization"},"'RGBS'": {"<enumType>": "RGBSetupSource","<key>": "RGBSetup"},"'Rds '": {"<enumValue>": "reds","<key>": "radius"},"'ScrD'": {"<enumValue>": "screenDot","<key>": "scratchDisks"},"'ShdI'": {"<classKey>": {"'GEfc'": "shadowIntensity"},"<eventKey>": {"watercolor": "shadowIntensity"},"<unknown>": "shadingIntensity"},"'ShpC'": {"<classKey>": {"application": "shapingCurve"},"<class>": "shapingCurve","<key>": "shapeCurveType"},"'ShrE'": {"<event>": "sharpenEdges","<key>": "shearEd"},"'Shrp'": {"<event>": "sharpen","<key>": "sharpness"},"'SplC'": {"<event>": "splitChannels","<key>": "supplementalCategories"},"'Spot'": {"<enumValue>": "spotColor","<key>": "spot"},"'SprS'": {"<typeValue>": {"'GEft'": "sprayedStrokes"},"<enumValue>": "separationSetup","<event>": "sprayedStrokes"},"'StrL'": {"<enumType>": "strokeLocation","<key>": "strokeLength"},"'Strt'": {"<classKey>": {"currentToolOptions": "saturation","fileNamingRules": "start","HSBColorClass": "saturation","hueSatAdjustment": "saturation","hueSatAdjustmentV2": "saturation","lineClass": "start","range": "start","vibrance": "saturation"},"<eventKey>": {"replaceColor": "saturation","variations": "saturation","vibrance": "saturation"},"<enumValue>": "saturation"},"'TEXT'": {"<enumType>": "textType","<key>": "textType"},"'TIFF'": {"<class>": "TIFFFormat","<enumValue>": "TIFF"},"'TglO'": {"<enumValue>": "toggleOptionsPalette","<key>": "toggleOthers"},"'TrnG'": {"<classKey>": {"application": "transparencyGrid","transparencyPrefs": "transparencyGridSize"},"<enumType>": "transparencyGridSize","<enumValue>": "transparencyGamutPreferences"},"'TrnS'": {"<classKey>": {"bevelEmboss": "transparencyShape","dropShadow": "transparencyShape","innerGlow": "transparencyShape","innerShadow": "transparencyShape","outerGlow": "transparencyShape"},"<class>": "transparencyStop","<unknown>": "transferSpec"},"'Trns'": {"<enumValue>": "transparent","<key>": "transparency"},"'TxtC'": {"<classKey>": {"'GEfc'": "textureCoverage","textLayer": "textClickPoint"},"<eventKey>": {"underpainting": "textureCoverage"}},"'TxtF'": {"<event>": "textureFill","<key>": "textureFile"},"'UsrM'": {"<enumType>": "userMaskOptions","<key>": "userMaskEnabled"},"'null'": {"<class>": "null","<enumValue>": "null","<event>": "null","<key>": "target"}};function I(e, a) {var t;var r = e[0];var n = e[1];if (n < l) {t = app.typeIDToStringID(n);} else {t = "'" + app.typeIDToCharID(n) + "'";if (T.meaningfulIds) {if (t in u) {function i(e) {var t = "";for (var r in e) {if (e.hasOwnProperty(r)) {if (a[1] === T.uniIdStrToId(r)) {t = e[r];break;}}}return t;}var o = "";var s = u[t];if (a) {switch (r) {case "<key>":if (a[0] === "<class>" && "<classKey>" in s) {o = i(s["<classKey>"]);} else if (a[0] === "<event>" && "<eventKey>" in s) {o = i(s["<eventKey>"]);}break;case "<enumValue>":if (a[0] === "<enumType>" && "<typeValue>" in s) {o = i(s["<typeValue>"]);}break;}}if (o !== "") {t = o;} else if (r in s) {t = s[r];}} else {var c = app.typeIDToStringID(n);if (c !== "") {t = c;}}}}return t;}var m = "";var s = app.stringIDToTypeID("get");var c = app.stringIDToTypeID("target");var p = app.stringIDToTypeID("property");function D(e) {var t = 0;var r = [];do {try {var a = e.getDesiredClass();} catch (e) {break;}if (t !== 0) {var n = T.buildCompact("<property>", I([ "<key>", t ], [ "<class>", a ]));r.push(T.buildCompact(I([ "<class>", p ]), n));t = 0;}var i;var o = e.getForm();switch (o) {case ReferenceFormType.CLASSTYPE:i = T.buildCompact("<class>", null);break;case ReferenceFormType.ENUMERATED:var s = [ "<enumType>", e.getEnumeratedType() ];var c = [ "<enumValue>", e.getEnumeratedValue() ];i = T.buildCompact("<enumerated>", T.buildCompact(I(s), I(c, s)));break;case ReferenceFormType.IDENTIFIER:i = T.buildCompact("<identifier>", e.getIdentifier());break;case ReferenceFormType.INDEX:i = T.buildCompact("<index>", e.getIndex());break;case ReferenceFormType.NAME:i = T.buildCompact("<name>", e.getName());break;case ReferenceFormType.OFFSET:i = T.buildCompact("<offset>", e.getOffset());break;case ReferenceFormType.PROPERTY:if (a === p) {t = e.getProperty();} else {i = T.buildCompact("<property>", I([ "<key>", e.getProperty() ], [ "<class>", a ]));}break;default:throw new Error("[jamEngine getFromReference] Unknown reference form type: " + o);break;}if (a !== p) {r.push(T.buildCompact(I([ "<class>", a ]), i));}e = e.getContainer();} while (e);return r;}function b(e) {var t = [];var r = e.count;for (var a = 0; a < r; a++) {var n;var i;try {i = e.getType(a);} catch (e) {continue;}switch (i) {case DescValueType.BOOLEANTYPE:n = T.buildCompact("<boolean>", e.getBoolean(a));break;case DescValueType.CLASSTYPE:n = T.buildCompact("<class>", I([ "<class>", e.getClass(a) ]));break;case DescValueType.DOUBLETYPE:n = T.buildCompact("<double>", e.getDouble(a));break;case DescValueType.ENUMERATEDTYPE:var o = [ "<enumType>", e.getEnumerationType(a) ];var s = [ "<enumValue>", e.getEnumerationValue(a) ];n = T.buildCompact("<enumerated>", T.buildCompact(I(o), I(s, o)));break;case DescValueType.INTEGERTYPE:n = T.buildCompact("<integer>", e.getInteger(a));break;case DescValueType.LISTTYPE:n = T.buildCompact("<list>", b(e.getList(a)));break;case DescValueType.OBJECTTYPE:var c = [ "<class>", e.getObjectType(a) ];var l = e.getObjectValue(a);n = T.buildCompact("<object>", T.buildCompact(I(c), S(l, c)));break;case DescValueType.ALIASTYPE:try {var u = e.getPath(a);n = T.buildCompact("<path>", u.fsName);} catch (e) {n = T.buildCompact("<path>", m);}break;case DescValueType.REFERENCETYPE:n = T.buildCompact("<reference>", D(e.getReference(a)));break;case DescValueType.STRINGTYPE:n = T.buildCompact("<string>", e.getString(a));break;case DescValueType.UNITDOUBLE:var p = [ "<unit>", e.getUnitDoubleType(a) ];var y = e.getUnitDoubleValue(a);n = T.buildCompact("<unitDouble>", T.buildCompact(I(p), y));break;default:var f;var h;try {f = i === DescValueType.RAWTYPE;} catch (e) {}try {h = i === DescValueType.LARGEINTEGERTYPE;} catch (e) {}if (f) {n = T.buildCompact("<data>", e.getData(a));} else if (h) {n = T.buildCompact("<largeInteger>", e.getLargeInteger(a));} else {throw new Error("[jamEngine getFromList] Unknown descriptor value type: " + i);}break;}t[a] = n;}return t;}function S(e, t) {if (e) {var r = {};var a;try {a = e.count;} catch (e) {return null;}for (var n = 0; n < a; n++) {var i = e.getKey(n);var o = I([ "<key>", i ], t);var s;var c;try {c = e.getType(i);} catch (e) {continue;}switch (c) {case DescValueType.BOOLEANTYPE:s = T.buildCompact("<boolean>", e.getBoolean(i));break;case DescValueType.CLASSTYPE:s = T.buildCompact("<class>", I([ "<class>", e.getClass(i) ]));break;case DescValueType.DOUBLETYPE:s = T.buildCompact("<double>", e.getDouble(i));break;case DescValueType.ENUMERATEDTYPE:var l = [ "<enumType>", e.getEnumerationType(i) ];var u = [ "<enumValue>", e.getEnumerationValue(i) ];s = T.buildCompact("<enumerated>", T.buildCompact(I(l), I(u, l)));break;case DescValueType.INTEGERTYPE:s = T.buildCompact("<integer>", e.getInteger(i));break;case DescValueType.LISTTYPE:s = T.buildCompact("<list>", b(e.getList(i)));break;case DescValueType.OBJECTTYPE:var p = [ "<class>", e.getObjectType(i) ];var y = e.getObjectValue(i);s = T.buildCompact("<object>", T.buildCompact(I(p), S(y, p)));break;case DescValueType.ALIASTYPE:try {var f = e.getPath(i);s = T.buildCompact("<path>", f.fsName);} catch (e) {s = T.buildCompact("<path>", m);}break;case DescValueType.REFERENCETYPE:s = T.buildCompact("<reference>", D(e.getReference(i)));break;case DescValueType.STRINGTYPE:s = T.buildCompact("<string>", e.getString(i));break;case DescValueType.UNITDOUBLE:var h = [ "<unit>", e.getUnitDoubleType(i) ];var g = e.getUnitDoubleValue(i);s = T.buildCompact("<unitDouble>", T.buildCompact(I(h), g));break;default:var d;var v;try {d = c === DescValueType.RAWTYPE;} catch (e) {}try {v = c === DescValueType.LARGEINTEGERTYPE;} catch (e) {}if (d) {s = T.buildCompact("<data>", e.getData(i));} else if (v) {s = T.buildCompact("<largeInteger>", e.getLargeInteger(i));} else {throw new Error("[jamEngine getFromDescriptor] Unknown descriptor value type: " + c);}break;}r[o] = s;}return r;} else {return null;}}jamEngine.jsonToActionDescriptor = function(e) {T = this;var t;if (e) {t = new ActionDescriptor();d(t, e);}return t;};jamEngine.jsonToActionReference = function(e) {T = this;var t;if (e) {t = new ActionReference();h(t, e);}return t;};jamEngine.eventIdAndActionDescriptorToJson = function(e, t) {T = this;var r = [ "<event>", e ];return {"<event>": I(r),"<descriptor>": S(t, r)};};jamEngine.classIdAndActionDescriptorToJson = function(e, t) {T = this;var r = [ "<class>", e ];return {"<class>": I(r),"<descriptor>": S(t, r)};};jamEngine.actionReferenceToJson = function(e) {T = this;return D(e);};function y(e) {classId = 0;do {try {var t = e.getDesiredClass();} catch (e) {break;}if (t !== p) {classId = t;break;}e = e.getContainer();} while (e);return classId;}jamEngine.jsonPlay = function(e, t, r) {var a = this.uniIdStrToId(e);var n = this.jsonToActionDescriptor(t);var i;if (a === s) {var o = n.getReference(c);i = [ "<class>", y(o) ];} else {i = [ "<event>", a ];}return S(app.executeAction(a, n, r || this.displayDialogs), i);};jamEngine.jsonGet = function(e) {var t = this.jsonToActionReference(e);return S(app.executeActionGet(t), [ "<class>", y(t) ]);};jamEngine.normalizeJsonItem = function(e, t) {function m(e) {var t = T.parseCompact(e);var r = t[0];var a = t[1];var n;switch (r) {case "<boolean>":case "<data>":case "<double>":case "<identifier>":case "<index>":case "<integer>":case "<largeInteger>":case "<name>":case "<offset>":case "<path>":case "<string>":n = a;break;case "<class>":n = a && I([ "<class>", T.uniIdStrToId(a) ]);break;case "<enumerated>":var i = T.parseCompact(a);var o = [ "<enumType>", T.uniIdStrToId(i[0]) ];var s = [ "<enumValue>", T.uniIdStrToId(i[1]) ];n = T.buildCompact(I(o), I(s, o));break;case "<list>":n = [];for (var c = 0; c < a.length; c++) {n.push(m(a[c]));}break;case "<object>":var l = T.parseCompact(a);var u = [ "<class>", T.uniIdStrToId(l[0]) ];var p = l[1];var y;if (p === null) {y = null;} else {y = {};for (var f in p) {if (p.hasOwnProperty(f)) {var h = [ "<key>", T.uniIdStrToId(f) ];y[I(h, u)] = m(p[f]);}}}n = T.buildCompact(I(u), y);break;case "<property>":n = I([ "<key>", T.uniIdStrToId(a) ]);break;case "<reference>":n = [];for (var c = 0; c < a.length; c++) {var g = T.parseCompact(a[c]);n.push(T.buildCompact(I([ "<class>", T.uniIdStrToId(g[0]) ]), m(g[1])));}break;case "<unitDouble>":var d = T.parseCompact(a);var v = [ "<unit>", T.uniIdStrToId(d[0]) ];n = T.buildCompact(I(v), d[1]);break;default:throw new Error("[jamEngine.normalizeJsonItem] Unknown item type: " + r);break;}return T.buildCompact(r, n);}T = this;var r = this.meaningfulIds;var a = this.parseFriendly;if (t && t.constructor === Object) {if (typeof t.meaningfulIds !== "undefined") {this.meaningfulIds = t.meaningfulIds;}if (typeof t.parseFriendly !== "undefined") {this.parseFriendly = t.parseFriendly;}}var n = m(e);this.meaningfulIds = r;this.parseFriendly = a;return n;};function i(e) {var t = [];for (var r = 0; r < e.length; r++) {var a = e[r];var n = {};var i = a[0];var o = a[1][0];var s = a[1][1];switch (o) {case "<class>":case "<identifier>":case "<index>":case "<name>":case "<offset>":case "<property":n[i] = s;break;case "<enumerated>":n[i] = s[1];break;default:throw new Error("[jamEngine simplifyRef] Unexpected element form: " + o);break;}t.push(n);}return t;}function o(e, t) {var r;var a = e[0];var n = e[1];switch (a) {case "<boolean>":case "<class>":case "<data>":case "<double>":case "<integer>":case "<largeInteger>":case "<path>":case "<string>":r = n;break;case "<list>":r = f(n, t);break;case "<enumerated>":case "<unitDouble>":r = n[1];break;case "<object>":r = v(n[1], t);break;case "<reference>":r = i(n);break;default:throw new Error("[jamEngine simplifyItem] Unexpected item type: " + a);break;}return r;}function f(e, t) {var r = [];for (var a = 0; a < e.length; a++) {r.push(o(e[a], t));}return r;}function v(e, r) {var t = function(e, t) {return o(e[t], r);};var a = {};for (var n in e) {if (e.hasOwnProperty(n)) {var i = undefined;if (typeof r === "function") {i = r(e, n, t);}if (typeof i === "undefined") {i = o(e[n], r);}a[n] = i;}}return a;}jamEngine.simplifyObject = function(e, t) {return v(this.normalizeJsonItem(e, {"meaningfulIds": true,"parseFriendly": true})[1][1], t);};jamEngine.simplifyList = function(e, t) {return f(this.normalizeJsonItem(e, {"meaningfulIds": true,"parseFriendly": true})[1], t);};jamEngine.parseCompact = function(e) {var t = [];if (e.constructor === Object) {var r = [];for (var a in e) {if (e.hasOwnProperty(a)) {r.push(a);}}if (r.length === 1) {t[0] = r[0];t[1] = e[r[0]];} else {throw new Error("[jamEngine.parseCompact] Syntax error: " + e.toSource());}} else if (e.constructor === Array) {if (e.length === 2) {t[0] = e[0];t[1] = e[1];} else {throw new Error("[jamEngine.parseCompact] Syntax error: " + e.toSource());}} else {throw new Error("[jamEngine.parseCompact] JavaScript object or array expected");}return t;};jamEngine.compactToExplicit = function(e, t, r) {var a = {};var n = this.parseCompact(e);a[t || "<type>"] = n[0];a[r || "<value>"] = n[1];return a;};jamEngine.buildCompact = function(e, t) {var r;if (typeof e === "string") {if (this.parseFriendly) {r = [ e, t ];} else {r = {};r[e] = t;}} else {throw new Error("[jamEngine.buildCompact] String expected");}return r;};jamEngine.explicitToCompact = function(e, t, r) {var a;if (e.constructor === Object) {a = this.buildCompact(e[t || "<type>"], e[r || "<value>"]);} else {throw new Error("[jamEngine.explicitToCompact] JavaScript object expected");}return a;};for (var e in a) {if (a.hasOwnProperty(e)) {var t = a[e];for (var r = t.length - 1; r >= 0; r--) {var n = t[r];if (!(app.charIDToTypeID(e.substring(1, 5)) === app.stringIDToTypeID(n))) {t.splice(r, 1);}}if (t.length < 2) {delete a[e];}}}for (var e in u) {if (u.hasOwnProperty(e)) {if (e in a) {var x = u[e];for (var _ in x) {if (x.hasOwnProperty(_)) {switch (_) {case "<class>":case "<event>":case "<enumType>":case "<enumValue>":case "<key>":case "<unknown>":if (app.charIDToTypeID(e.substring(1, 5)) != app.stringIDToTypeID(x[_])) {throw new Error("[jamEngine] " + '"' + e + '" and "' + x[_] + '" are not equivalent ID strings');}break;case "<classKey>":case "<eventKey>":case "<typeValue>":for (var k in x[_]) {if (x[_].hasOwnProperty(k)) {if (app.charIDToTypeID(e.substring(1, 5)) != app.stringIDToTypeID(x[_][k])) {throw new Error("[jamEngine] " + '"' + e + '" and "' + x[_][k] + '" are not equivalent ID strings');}}}break;}}}} else {delete u[e];}}}})();}if (typeof jamHelpers !== "object") {var jamHelpers = {};(function() {jamHelpers.toColorObject = function(e) {var t;if (e.constructor === Object) {function o(e) {var t = {};for (var r in e) {if (e.hasOwnProperty(r)) {var a = e[r];var n = null;switch (r) {case "book":case "name":n = [ "<string>", localize(a) ];break;case "bookKey":n = [ "<data>", a ];break;case "bookID":n = [ "<integer>", a ];break;case "a":case "b":case "black":case "blue":case "brightness":case "cyan":case "gray":case "green":case "luminance":case "magenta":case "red":case "saturation":case "yellowColor":n = [ "<double>", a ];break;case "hue":n = [ "<unitDouble>", [ "angleUnit", a ] ];break;case "color":var i;if ("book" in a && "name" in a || "bookID" in a && "bookKey" in a) {i = "bookColor";} else if ("cyan" in a && "magenta" in a && "yellowColor" in a && "black" in a) {i = "CMYKColorClass";} else if ("gray" in a) {i = "grayscale";} else if ("hue" in a && "saturation" in a && "brightness" in a) {i = "HSBColorClass";} else if ("luminance" in a && "a" in a && "b" in a) {i = "labColor";} else if ("red" in a && "green" in a && "blue" in a) {i = "RGBColor";}n = [ "<object>", [ i, o(a) ] ];break;}if (n) {t[r] = n;}}}return t;}t = o({"color": e})["color"];} else if (e.constructor === Array) {var r = e[0];switch (jamEngine.uniIdStrToId(r)) {case jamEngine.uniIdStrToId("bookColor"):switch (e[1].length) {case 2:if (typeof e[1][0] === "string") {t = [ "<object>", [ "bookColor", {"book": [ "<string>", e[1][0] ],"name": [ "<string>", e[1][1] ]} ] ];} else if (typeof e[1][0] === "number") {t = [ "<object>", [ "bookColor", {"bookID": [ "<integer>", e[1][0] ],"bookKey": [ "<data>", e[1][1] ]} ] ];}break;case 4:t = [ "<object>", [ "bookColor", {"book": [ "<string>", e[1][0] ],"name": [ "<string>", e[1][1] ],"bookID": [ "<integer>", e[1][2] ],"bookKey": [ "<data>", e[1][3] ]} ] ];break;}break;case jamEngine.uniIdStrToId("CMYKColorClass"):t = [ "<object>", [ "CMYKColorClass", {"cyan": [ "<double>", e[1][0] ],"magenta": [ "<double>", e[1][1] ],"yellowColor": [ "<double>", e[1][2] ],"black": [ "<double>", e[1][3] ]} ] ];break;case jamEngine.uniIdStrToId("grayscale"):t = [ "<object>", [ "grayscale", {"gray": [ "<double>", e[1].constructor === Array ? e[1][0] : e[1] ]} ] ];break;case jamEngine.uniIdStrToId("HSBColorClass"):t = [ "<object>", [ "HSBColorClass", {"hue": [ "<unitDouble>", [ "angleUnit", e[1][0] ] ],"saturation": [ "<double>", e[1][1] ],"brightness": [ "<double>", e[1][2] ]} ] ];break;case jamEngine.uniIdStrToId("labColor"):t = [ "<object>", [ "labColor", {"luminance": [ "<double>", e[1][0] ],"a": [ "<double>", e[1][1] ],"b": [ "<double>", e[1][2] ]} ] ];break;case jamEngine.uniIdStrToId("RGBColor"):t = [ "<object>", [ "RGBColor", {"red": [ "<double>", e[1][0] ],"green": [ "<double>", e[1][1] ],"blue": [ "<double>", e[1][2] ]} ] ];break;default:throw new Error("[jamHelpers.toColorObject] Unrecognized color class: " + r);break;}}return t;};jamHelpers.fromColorObject = function(e, t) {var r;if (t) {r = jamEngine.simplifyObject(e);} else {var a = jamEngine.normalizeJsonItem(e, {"meaningfulIds": true,"parseFriendly": true});var n = a[1][0];var i = a[1][1];switch (n) {case "bookColor":var o = i["book"][1];var s = i["name"][1];if ("bookID" in i && "bookKey" in i) {var c = i["bookID"][1];var l = i["bookKey"][1];r = [ n, [ o, s, c, l ] ];} else {r = [ n, [ o, s ] ];}break;case "CMYKColorClass":var u = i["cyan"][1];var p = i["magenta"][1];var y = i["yellowColor"][1];var f = i["black"][1];r = [ n, [ u, p, y, f ] ];break;case "grayscale":var h = i["gray"][1];r = [ n, [ h ] ];break;case "HSBColorClass":var g = i["hue"][1][1];var d = i["saturation"][1];var v = i["brightness"][1];r = [ n, [ g, d, v ] ];break;case "labColor":var m = i["luminance"][1];var T = i["a"][1];var I = i["b"][1];r = [ n, [ m, T, I ] ];break;case "RGBColor":var D = i["red"][1];var b = i["green"][1];var S = i["blue"][1];r = [ n, [ D, b, S ] ];break;default:throw new Error("[jamHelpers.fromColorObject] Unrecognized color class: " + n);break;}}return r;};jamHelpers.nameToColorObject = function(e, t) {return this.toColorObject(jamColors.nameToColor(e, t));};jamHelpers.hexToColorObject = function(e) {return this.toColorObject([ "RGBColor", jamColors.hexToRgb(e) ]);};jamHelpers.hexFromColorObject = function(e, t, r) {var a = this.fromColorObject(e);return a[0] === "RGBColor" ? jamColors.rgbToHex(a[1], t, r) : null;};jamHelpers.toGradientObject = function(e) {var t;if (e.constructor === Object) {var s = this;function c(e) {var t = {};for (var r in e) {if (e.hasOwnProperty(r)) {var a = e[r];var n = null;var i;switch (r) {case "showTransparency":case "vectorColor":n = [ "<boolean>", a ];break;case "name":n = [ "<string>", localize(a) ];break;case "gradientForm":n = [ "<enumerated>", [ "gradientForm", a ] ];break;case "type":n = [ "<enumerated>", [ "colorStopType", a ] ];break;case "colorSpace":n = [ "<enumerated>", [ "colorSpace", a ] ];break;case "location":case "midpoint":case "randomSeed":case "smoothness":n = [ "<integer>", a ];break;case "interpolation":n = [ "<double>", a ];break;case "opacity":n = [ "<unitDouble>", [ "percentUnit", a ] ];break;case "colors":i = [];for (var o = 0; o < a.length; o++) {i.push([ "<object>", [ "colorStop", c(a[o]) ] ]);}n = [ "<list>", i ];break;case "transparency":i = [];for (var o = 0; o < a.length; o++) {i.push([ "<object>", [ "transparencyStop", c(a[o]) ] ]);}n = [ "<list>", i ];break;case "minimum":case "maximum":i = [];for (var o = 0; o < a.length; o++) {i.push([ "<integer>", a[o] ]);}n = [ "<list>", i ];break;case "color":n = s.toColorObject(a);break;case "gradient":n = [ "<object>", [ "gradientClassEvent", c(a) ] ];break;}if (n) {t[r] = n;}}}return t;}t = c({"gradient": e})["gradient"];} else if (e.constructor === Array) {var r = {};var a = e[0];if (a) {r["name"] = [ "<string>", a ];}var n = e[1];r["gradientForm"] = [ "<enumerated>", [ "gradientForm", n ] ];switch (jamEngine.uniIdStrToId(n)) {case jamEngine.uniIdStrToId("customStops"):r["interpolation"] = [ "<double>", e[2] ];var i = e[3];var o = [];for (var l = 0; l < i.length; l++) {var u = {};u["location"] = [ "<integer>", i[l][0] ];u["midpoint"] = [ "<integer>", i[l][1] ];var p = i[l][2];u["type"] = [ "<enumerated>", [ "colorStopType", p ] ];switch (jamEngine.uniIdStrToId(p)) {case jamEngine.uniIdStrToId("userStop"):u["color"] = this.toColorObject(i[l][3]);break;case jamEngine.uniIdStrToId("backgroundColor"):case jamEngine.uniIdStrToId("foregroundColor"):break;default:throw new Error("[jamHelpers.toGradientObject] Unrecognized color stop type: " + p);break;}o.push([ "<object>", [ "colorStop", u ] ]);}r["colors"] = [ "<list>", o ];var y = e[4];if (typeof y !== "undefined") {var f = [];for (var h = 0; h < y.length; h++) {var g = {};g["location"] = [ "<integer>", y[h][0] ];g["midpoint"] = [ "<integer>", y[h][1] ];g["opacity"] = [ "<unitDouble>", [ "percentUnit", y[h][2] ] ];f.push([ "<object>", [ "transparencyStop", g ] ]);}r["transparency"] = [ "<list>", f ];}break;case jamEngine.uniIdStrToId("colorNoise"):r["randomSeed"] = [ "<integer>", e[2] ];r["showTransparency"] = [ "<boolean>", e[3] ];r["vectorColor"] = [ "<boolean>", e[4] ];r["smoothness"] = [ "<integer>", e[5] ];var d = e[6];r["colorSpace"] = [ "<enumerated>", [ "colorSpace", d ] ];switch (jamEngine.uniIdStrToId(d)) {case jamEngine.uniIdStrToId("RGBColor"):case jamEngine.uniIdStrToId("HSBColorEnum"):case jamEngine.uniIdStrToId("labColor"):break;default:throw new Error("[jamHelpers.toGradientObject] Unrecognized color space: " + d);break;}r["minimum"] = this.toIntegerList(e[7]);r["maximum"] = this.toIntegerList(e[8]);break;default:throw new Error("[jamHelpers.toGradientObject] Unrecognized gradient form: " + n);break;}t = [ "<object>", [ "gradientClassEvent", r ] ];}return t;};jamHelpers.fromGradientObject = function(e, t) {var r;if (t) {r = jamEngine.simplifyObject(e);} else {r = [];var a = jamEngine.normalizeJsonItem(e, {"meaningfulIds": true,"parseFriendly": true});var n = a[1][1];var i = n["name"];r.push(i ? i[1] : null);var o = n["gradientForm"][1][1];r.push(o);switch (o) {case "customStops":r.push(n["interpolation"][1]);var s = n["colors"][1];var c = [];for (var l = 0; l < s.length; l++) {var u = s[l][1][1];var p = [];p.push(u["location"][1]);p.push(u["midpoint"][1]);var y = u["type"][1][1];p.push(y);switch (y) {case "userStop":p.push(this.fromColorObject(u["color"]));break;case "backgroundColor":case "foregroundColor":break;default:throw new Error("[jamHelpers.fromGradientObject] Unrecognized color stop type: " + y);break;}c.push(p);}r.push(c);var f = n["transparency"][1];var h = [];for (var g = 0; g < f.length; g++) {var d = f[g][1][1];var v = [];v.push(d["location"][1]);v.push(d["midpoint"][1]);v.push(d["opacity"][1][1]);h.push(v);}r.push(h);break;case "colorNoise":r.push(n["randomSeed"][1]);r.push(n["showTransparency"][1]);r.push(n["vectorColor"][1]);r.push(n["smoothness"][1]);var m = n["colorSpace"][1][1];r.push(m);switch (m) {case "RGBColor":case "HSBColorEnum":case "labColor":break;default:throw new Error("[jamHelpers.fromGradientObject] Unrecognized color space: " + m);break;}r.push(this.fromIntegerList(n["minimum"]));r.push(this.fromIntegerList(n["maximum"]));break;default:throw new Error("[jamHelpers.fromGradientObject] Unrecognized gradient form: " + o);break;}}return r;};jamHelpers.toCurvesAdjustmentList = function(e) {var t = [];for (var r = 0; r < e.length; r++) {var a = e[r];var n = [ "<reference>", [ [ "channel", [ "<enumerated>", [ "channel", a[0] ] ] ] ] ];var i = a[1];var o = i[0];var s = i[1];var c = [];switch (jamEngine.uniIdStrToId(o)) {case jamEngine.uniIdStrToId("mapping"):for (var l = 0; l < s.length; l++) {c.push([ "<integer>", s[l] ]);}var u = [ "<list>", c ];t.push([ "<object>", [ "curvesAdjustment", {"channel": n,"mapping": u} ] ]);break;case jamEngine.uniIdStrToId("curve"):for (var l = 0; l < s.length; l++) {var p = [ "<object>", [ "point", {"horizontal": [ "<double>", s[l][0] ],"vertical": [ "<double>", s[l][1] ]} ] ];c.push(p);}var y = [ "<list>", c ];t.push([ "<object>", [ "curvesAdjustment", {"channel": n,"curve": y} ] ]);break;default:throw new Error("[jamHelpers.toCurvesAdjustmentList] Unrecognized curve type");break;}}return [ "<list>", t ];};jamHelpers.toHueSatAdjustmentV2List = function(e) {var t = [];for (var r = 0; r < e.length; r++) {var a = e[r];var n;if (a.length === 3 && r === 0) {n = {"hue": [ "<integer>", a[0] ],"saturation": [ "<integer>", a[1] ],"lightness": [ "<integer>", a[2] ]};} else if (a.length === 1 + 4 + 3) {n = {"localRange": [ "<integer>", a[0] ],"beginRamp": [ "<integer>", a[1] ],"beginSustain": [ "<integer>", a[2] ],"endSustain": [ "<integer>", a[3] ],"endRamp": [ "<integer>", a[4] ],"hue": [ "<integer>", a[5] ],"saturation": [ "<integer>", a[6] ],"lightness": [ "<integer>", a[7] ]};}t.push([ "<object>", [ "hueSatAdjustmentV2", n ] ]);}return [ "<list>", t ];};jamHelpers.toBlendRangeList = function(e) {var t = [];var r;for (var a = 0; a < e.length; a++) {var n = e[a];if (n.constructor === Object) {function i(e) {var t = {};for (var r in e) {if (e.hasOwnProperty(r)) {var a = e[r];var n = null;switch (r) {case "channel":n = [ "<reference>", [ [ "channel", [ "<enumerated>", [ "channel", a ] ] ] ] ];break;case "srcBlackMin":case "srcBlackMax":case "srcWhiteMin":case "srcWhiteMax":case "destBlackMin":case "destBlackMax":case "destWhiteMin":case "destWhiteMax":n = [ "<integer>", a ];break;case "blendRange":n = [ "<object>", [ "blendRange", i(a) ] ];break;}if (n) {t[r] = n;}}}return t;}r = i({"blendRange": n})["blendRange"];} else if (n.constructor === Array) {r = [ "<object>", [ "blendRange", {"channel": [ "<reference>", [ [ "channel", [ "<enumerated>", [ "channel", n[0] ] ] ] ] ],"srcBlackMin": [ "<integer>", n[1] ],"srcBlackMax": [ "<integer>", n[2] ],"srcWhiteMin": [ "<integer>", n[3] ],"srcWhiteMax": [ "<integer>", n[4] ],"destBlackMin": [ "<integer>", n[5] ],"destBlackMax": [ "<integer>", n[6] ],"destWhiteMin": [ "<integer>", n[7] ],"destWhiteMax": [ "<integer>", n[8] ]} ] ];}t.push(r);}return [ "<list>", t ];};jamHelpers.fromBlendRangeList = function(e, t) {var r;if (t) {var a = function(e, t, r) {var a = undefined;if (t === "channel") {var n = r(e, t);a = n[0]["channel"];}return a;};r = jamEngine.simplifyList(e, a);} else {r = [];var n = jamEngine.normalizeJsonItem(e, {"meaningfulIds": true,"parseFriendly": true});for (index = 0; index < n[1].length; index++) {var i = n[1][index][1][1];var o = [ i["channel"][1][0][1][1][1], i["srcBlackMin"][1], i["srcBlackMax"][1], i["srcWhiteMin"][1], i["srcWhiteMax"][1], i["destBlackMin"][1], i["destBlackMax"][1], i["destWhiteMin"][1], i["destWhiteMax"][1] ];r.push(o);}}return r;};jamHelpers.toIntegerList = function(e) {var t = [];for (var r = 0; r < e.length; r++) {t.push([ "<integer>", e[r] ]);}return [ "<list>", t ];};jamHelpers.fromIntegerList = function(e) {var t = jamEngine.normalizeJsonItem(e, {"meaningfulIds": true,"parseFriendly": true});var r = [];var a = t[1];for (var n = 0; n < a.length; n++) {r.push(a[n][1]);}return r;};function T(e, t) {return typeof t === "undefined" ? [ "<double>", e ] : [ "<unitDouble>", [ t, e ] ];}jamHelpers.toPointObject = function(e) {var t = e[0];var r = e[1];var a = [ "<object>", [ "point", {"horizontal": T(t[0], r),"vertical": T(t[1], r)} ] ];return a;};jamHelpers.toPointList = function(e) {var t = e[0];var r = e[1];var a = [];for (var n = 0; n < t.length; n++) {a.push([ "<object>", [ "point", {"horizontal": T(t[n][0], r),"vertical": T(t[n][1], r)} ] ]);}return [ "<list>", a ];};jamHelpers.fromPointList = function(e) {var t = [];var r = jamEngine.normalizeJsonItem(e, {"meaningfulIds": true,"parseFriendly": true});var a = [];var n;function i(e) {var t;switch (e[0]) {case "<unitDouble>":n = e[1][0];t = e[1][1];break;case "<double>":n = undefined;t = e[1];break;}return t;}var o = r[1];for (var s = 0; s < o.length; s++) {a.push([ i(o[s][1][1]["horizontal"]), i(o[s][1][1]["vertical"]) ]);}t.push(a);if (n) {t.push(n);}return t;};jamHelpers.toOffsetObject = function(e) {var t = e[0];var r = e[1];var a = [ "<object>", [ "offset", {"horizontal": T(t[0], r),"vertical": T(t[1], r)} ] ];return a;};jamHelpers.toRectangleObject = function(e) {var t = e[0];var r = e[1];var a = {"left": T(t[0], r),"top": T(t[1], r),"right": T(t[2], r),"bottom": T(t[3], r)};if (t.length === 5) {a["radius"] = T(t[4], r);}return [ "<object>", [ "rectangle", a ] ];};jamHelpers.toEllipseObject = function(e) {var t = e[0];var r = e[1];var a = [ "<object>", [ "ellipse", {"left": T(t[0], r),"top": T(t[1], r),"right": T(t[2], r),"bottom": T(t[3], r)} ] ];return a;};jamHelpers.toCustomShapeObject = function(e) {var t = e[0];var r = e[1];var a = [ "<object>", [ "customShape", {"name": [ "<string>", t[0] ],"left": T(t[1], r),"top": T(t[2], r),"right": T(t[3], r),"bottom": T(t[4], r)} ] ];return a;};jamHelpers.toCurvePointList = function(e) {var t = [];var r;for (var a = 0; a < e.length; a++) {var n = e[a];if (n.constructor === Object) {function i(e) {var t = {};for (var r in e) {if (e.hasOwnProperty(r)) {var a = e[r];var n = null;switch (r) {case "continuity":n = [ "<boolean>", a ];break;case "horizontal":case "vertical":n = [ "<double>", a ];break;case "curvePoint":n = [ "<object>", [ "curvePoint", i(a) ] ];break;}if (n) {t[r] = n;}}}return t;}r = i({"curvePoint": n})["curvePoint"];} else if (n.constructor === Array) {switch (n.length) {case 2:r = [ "<object>", [ "curvePoint", {"horizontal": [ "<double>", n[0] ],"vertical": [ "<double>", n[1] ]} ] ];break;case 3:r = [ "<object>", [ "curvePoint", {"horizontal": [ "<double>", n[0] ],"vertical": [ "<double>", n[1] ],"continuity": [ "<boolean>", n[2] ]} ] ];break;}}t.push(r);}return [ "<list>", t ];};jamHelpers.fromCurvePointList = function(e, t) {var r;if (t) {r = jamEngine.simplifyList(e);} else {r = [];var a = jamEngine.normalizeJsonItem(e, {"meaningfulIds": true,"parseFriendly": true});for (index = 0; index < a[1].length; index++) {var n = a[1][index][1][1];var i = [ n["horizontal"][1], n["vertical"][1] ];if ("continuity" in n) {i.push(n["continuity"][1]);}r.push(i);}}return r;};jamHelpers.toRationalPointList = function(e) {var t = e[0];var r = e[1];var a = [];for (var n = 0; n < t.length; n++) {a.push([ "<object>", [ "rationalPoint", {"horizontal": T(t[n][0], r),"vertical": T(t[n][1], r)} ] ]);}return [ "<list>", a ];};jamHelpers.toPathComponentList = function(e) {var t;if (e.constructor === Object) {var s;if ("unit" in e) {s = e["unit"];}var r = e["pathComponents"];function c(e) {var t = {};for (var r in e) {if (e.hasOwnProperty(r)) {var a = e[r];var n = null;var i;switch (r) {case "closedSubpath":case "smooth":case "windingFill":n = [ "<boolean>", a ];break;case "shapeOperation":n = [ "<enumerated>", [ "shapeOperation", a ] ];break;case "horizontal":case "vertical":n = T(a, s);break;case "anchor":case "backward":case "forward":n = [ "<object>", [ "point", c(a) ] ];break;case "subpathListKey":i = [];for (var o = 0; o < a.length; o++) {i.push([ "<object>", [ "subpathsList", c(a[o]) ] ]);}n = [ "<list>", i ];break;case "points":i = [];for (var o = 0; o < a.length; o++) {i.push([ "<object>", [ "pathPoint", c(a[o]) ] ]);}n = [ "<list>", i ];break;case "pathComponents":i = [];for (var o = 0; o < a.length; o++) {i.push([ "<object>", [ "pathComponent", c(a[o]) ] ]);}n = [ "<list>", i ];break;}if (n) {t[r] = n;}}}return t;}t = c({"pathComponents": r})["pathComponents"];} else if (e.constructor === Array) {var a = [];var r = e[0];var s = e[1];for (var n = 0; n < r.length; n++) {var i = r[n][0];var o = r[n][1];var l = r[n][2];var u = [];for (var p = 0; p < o.length; p++) {var y = o[p][0];var f = o[p][1];var h = [];for (var g = 0; g < y.length; g++) {var d = y[g];switch (d.length) {case 1:h.push([ "<object>", [ "pathPoint", {"anchor": [ "<object>", [ "point", {"horizontal": T(d[0][0], s),"vertical": T(d[0][1], s)} ] ]} ] ]);break;case 3:case 4:h.push([ "<object>", [ "pathPoint", {"anchor": [ "<object>", [ "point", {"horizontal": T(d[0][0], s),"vertical": T(d[0][1], s)} ] ],"forward": [ "<object>", [ "point", {"horizontal": T(d[1][0], s),"vertical": T(d[1][1], s)} ] ],"backward": [ "<object>", [ "point", {"horizontal": T(d[2][0], s),"vertical": T(d[2][1], s)} ] ],"smooth": [ "<boolean>", d[3] || false ]} ] ]);break;}}var v = {};if (f) {v["closedSubpath"] = [ "<boolean>", f ];}v["points"] = [ "<list>", h ];u.push([ "<object>", [ "subpathsList", v ] ]);}var m = {};m["shapeOperation"] = [ "<enumerated>", [ "shapeOperation", i ] ];if (l) {m["windingFill"] = [ "<boolean>", l ];}m["subpathListKey"] = [ "<list>", u ];a.push([ "<object>", [ "pathComponent", m ] ]);}t = [ "<list>", a ];}return t;};jamHelpers.fromPathComponentList = function(e, t) {var r;if (t) {r = {};var a;var n = false;function i(e, t) {if (!n) {if (t === "horizontal") {var r = e[t];if (r[0] === "<unitDouble>") {a = r[1][0];}n = true;}}return undefined;}r["pathComponents"] = jamEngine.simplifyList(e, i);if (a) {r["unit"] = a;}} else {r = [];var o = jamEngine.normalizeJsonItem(e, {"meaningfulIds": true,"parseFriendly": true});var s = [];var a;function c(e) {var t;switch (e[0]) {case "<unitDouble>":a = e[1][0];t = e[1][1];break;case "<double>":a = undefined;t = e[1];break;}return t;}var l = o[1];for (var u = 0; u < l.length; u++) {var p = l[u][1][1];var y = p["shapeOperation"][1][1];var f = "windingFill" in p ? p["windingFill"][1] : false;var h = [];var g = p["subpathListKey"][1];for (var d = 0; d < g.length; d++) {var v = g[d][1][1];var m = "closedSubpath" in v ? v["closedSubpath"][1] : false;var T = [];var I = v["points"][1];for (var D = 0; D < I.length; D++) {var b = I[D][1][1];var S = [];var x = b["anchor"][1][1];S.push([ c(x["horizontal"]), c(x["vertical"]) ]);if ("forward" in b) {var _ = b["forward"][1][1];S.push([ c(_["horizontal"]), c(_["vertical"]) ]);}if ("backward" in b) {var k = b["backward"][1][1];S.push([ c(k["horizontal"]), c(k["vertical"]) ]);}var j = "smooth" in b ? b["smooth"][1] : false;if (j) {S.push(j);}T.push(S);}var L = [];L.push(T);if (m) {L.push(m);}h.push(L);}var E = [];E.push(y);E.push(h);if (f) {E.push(f);}s.push(E);}r.push(s);if (a) {r.push(a);}}return r;};})();}if (typeof jamJSON !== "object") {var jamJSON = {};(function() {var state;var stack;var container;var key;var value;var escapes = {"\\": "\\",'"': '"',"/": "/","t": "\t","n": "\n","r": "\r","f": "\f","b": "\b"};var action = {"{": {"go": function() {stack.push({"state": "ok"});container = {};state = "firstokey";},"ovalue": function() {stack.push({"container": container,"state": "ocomma","key": key});container = {};state = "firstokey";},"firstavalue": function() {stack.push({"container": container,"state": "acomma"});container = {};state = "firstokey";},"avalue": function() {stack.push({"container": container,"state": "acomma"});container = {};state = "firstokey";}},"}": {"firstokey": function() {var e = stack.pop();value = container;container = e.container;key = e.key;state = e.state;},"ocomma": function() {var e = stack.pop();container[key] = value;value = container;container = e.container;key = e.key;state = e.state;}},"[": {"go": function() {stack.push({"state": "ok"});container = [];state = "firstavalue";},"ovalue": function() {stack.push({"container": container,"state": "ocomma","key": key});container = [];state = "firstavalue";},"firstavalue": function() {stack.push({"container": container,"state": "acomma"});container = [];state = "firstavalue";},"avalue": function() {stack.push({"container": container,"state": "acomma"});container = [];state = "firstavalue";}},"]": {"firstavalue": function() {var e = stack.pop();value = container;container = e.container;key = e.key;state = e.state;},"acomma": function() {var e = stack.pop();container.push(value);value = container;container = e.container;key = e.key;state = e.state;}},":": {"colon": function() {if (container.hasOwnProperty(key)) {throw new SyntaxError("[jamJSON.parse] Duplicate key: “" + key + "”");}state = "ovalue";}},",": {"ocomma": function() {container[key] = value;state = "okey";},"acomma": function() {container.push(value);state = "avalue";}},"true": {"go": function() {value = true;state = "ok";},"ovalue": function() {value = true;state = "ocomma";},"firstavalue": function() {value = true;state = "acomma";},"avalue": function() {value = true;state = "acomma";}},"false": {"go": function() {value = false;state = "ok";},"ovalue": function() {value = false;state = "ocomma";},"firstavalue": function() {value = false;state = "acomma";},"avalue": function() {value = false;state = "acomma";}},"null": {"go": function() {value = null;state = "ok";},"ovalue": function() {value = null;state = "ocomma";},"firstavalue": function() {value = null;state = "acomma";},"avalue": function() {value = null;state = "acomma";}}};var number = {"go": function() {state = "ok";},"ovalue": function() {state = "ocomma";},"firstavalue": function() {state = "acomma";},"avalue": function() {state = "acomma";}};var string = {"go": function() {state = "ok";},"firstokey": function() {key = value;state = "colon";},"okey": function() {key = value;state = "colon";},"ovalue": function() {state = "ocomma";},"firstavalue": function() {state = "acomma";},"avalue": function() {state = "acomma";}};var commentFunc = function() {};function debackslashify(e) {return e.replace(/\\(?:u(.{4})|([^u]))/g, function(e, t, r) {return t ? String.fromCharCode(parseInt(t, 16)) : escapes[r];});}jamJSON.parse = function(text, validate, allowComments) {if (validate) {var tx = /^[\x20\t\n\r]*(?:([,:\[\]{}]|true|false|null)|(-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+\-]?[0-9]+)?)|"((?:[^\r\n\t\\\"]|\\(?:["\\\/trnfb]|u[0-9a-fA-F]{4}))*)")/;var txc = /^[\x20\t\n\r]*(?:(\/(?:\/.*|\*(?:.|[\r\n])*?\*\/))|([,:\[\]{}]|true|false|null)|(-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+\-]?[0-9]+)?)|"((?:[^\r\n\t\\\"]|\\(?:["\\\/trnfb]|u[0-9a-fA-F]{4}))*)")/;var r;var i;var actionFunc;state = "go";stack = [];try {while (true) {i = allowComments ? 1 : 0;r = allowComments ? txc.exec(text) : tx.exec(text);if (!r) {break;}if (allowComments && r[1]) {actionFunc = commentFunc;} else if (r[i + 1]) {actionFunc = action[r[i + 1]][state];} else if (r[i + 2]) {value = +r[i + 2];actionFunc = number[state];} else {value = debackslashify(r[i + 3]);actionFunc = string[state];}if (actionFunc) {actionFunc();text = text.slice(r[0].length);} else {break;}}} catch (e) {state = e;}if (state !== "ok" || /[^\x20\t\n\r]/.test(text)) {throw state instanceof SyntaxError ? state : new SyntaxError("[jamJSON.parse] Invalid JSON");}return value;} else {return eval("(" + text + ")");}};var escapable = /[\\\"\x00-\x1F\x7F-\x9F\u00AD\u0600-\u0604\u070F\u17B4\u17B5\u200C-\u200F\u2028-\u202F\u2060-\u206F\uFEFF\uFFF0-\uFFFF]/g;var meta = {"\b": "\\b","\t": "\\t","\n": "\\n","\f": "\\f","\r": "\\r",'"': '\\"',"\\": "\\\\"};var gap;var indent;var prefixIndent;function quote(e) {escapable.lastIndex = 0;return escapable.test(e) ? '"' + e.replace(escapable, function(e) {var t = meta[e];return typeof t === "string" ? t : "\\u" + ("0000" + e.charCodeAt(0).toString(16).toUpperCase()).slice(-4);}) + '"' : '"' + e + '"';}function str(e) {var t;var r;var a;var n = gap;var i;switch (typeof e) {case "string":return quote(e);case "number":return isFinite(e) ? String(e) : "null";case "boolean":case "null":return String(e);case "object":if (!e) {return "null";}gap += indent;i = [];if (e.constructor === Array) {for (t = 0; t < e.length; t++) {i[t] = str(e[t]);}var o = gap ? "[\n" + prefixIndent + n + "]" : "[ ]";var s = gap ? "[\n" + prefixIndent + gap + i.join(",\n" + prefixIndent + gap) + "\n" + prefixIndent + n + "]" : "[ " + i.join(", ") + " ]";a = i.length === 0 ? o : s;gap = n;return a;} else {for (r in e) {if (e.hasOwnProperty(r)) {a = str(e[r]);if (a) {i.push(quote(r) + (gap && (a.charAt(0) === "{" || a.charAt(0) === "[") ? ":\n" + prefixIndent + gap : ": ") + a);}}}var c = gap ? "{\n" + prefixIndent + n + "}" : "{ }";var l = gap ? "{\n" + prefixIndent + gap + i.join(",\n" + prefixIndent + gap) + "\n" + prefixIndent + n + "}" : "{ " + i.join(", ") + " }";a = i.length === 0 ? c : l;gap = n;return a;}default:throw new SyntaxError("[jamJSON.stringify] Invalid JSON");}}jamJSON.stringify = function(e, t, r) {var a;gap = "";indent = "";prefixIndent = "";if (typeof t === "number") {for (a = 0; a < t; a++) {indent += " ";}} else if (typeof t === "string") {indent = t;}if (typeof r === "number") {for (a = 0; a < r; a++) {prefixIndent += " ";}} else if (typeof r === "string") {prefixIndent = r;}return prefixIndent + str(e);};})();}if (typeof jamText !== "object") {var jamText = {};(function() {jamText.toLayerTextObject = function(e) {var l;if ("typeUnit" in e) {l = e["typeUnit"];}var t = e["layerText"];function u(e, t) {var r = {};for (var a in e) {if (e.hasOwnProperty(a)) {var n = e[a];var i = null;var o;switch (a) {case "bookKey":i = [ "<data>", n ];break;case "rowMajorOrder":case "syntheticBold":case "syntheticItalic":case "autoLeading":case "ligature":case "altligature":case "contextualLigatures":case "alternateLigatures":case "oldStyle":case "fractions":case "ordinals":case "swash":case "titling":case "connectionForms":case "stylisticAlternates":case "ornaments":case "proportionalMetrics":case "kana":case "italics":case "ruby":case "enableWariChu":case "noBreak":case "fill":case "stroke":case "fillFirst":case "fillOverPrint":case "strokeOverPrint":case "hyphenate":case "hyphenateCapitalized":case "hangingRoman":case "keepTogether":case "kurikaeshiMojiShori":case "textEveryLineComposer":case "flip":i = [ "<boolean>", n ];break;case "textKey":case "fontPostScriptName":case "fontName":case "fontStyleName":case "book":case "name":i = [ "<string>", n ];break;case "rowCount":case "columnCount":case "from":case "to":case "fontScript":case "fontTechnology":case "tracking":case "wariChuCount":case "wariChuLineGap":case "wariChuWidow":case "wariChuOrphan":case "tcyUpDown":case "tcyLeftRight":case "jiDori":case "bookID":case "dropCapMultiplier":case "hyphenateWordSize":case "hyphenatePreLength":case "hyphenatePostLength":case "hyphenateLimit":case "autoTCY":case "kerning":case "pathTypeSpacing":i = [ "<integer>", n ];break;case "warpValue":case "warpPerspective":case "warpPerspectiveOther":case "xx":case "xy":case "yx":case "yy":case "tx":case "ty":case "top":case "left":case "bottom":case "right":case "horizontalScale":case "verticalScale":case "characterRotation":case "mojiZume":case "wariChuScale":case "a":case "b":case "black":case "blue":case "brightness":case "cyan":case "gray":case "green":case "luminance":case "magenta":case "red":case "saturation":case "yellowColor":case "lineDashoffset":case "autoLeadingPercentage":case "hyphenationZone":case "hyphenationPreference":case "justificationWordMinimum":case "justificationWordDesired":case "justificationWordMaximum":case "justificationLetterMinimum":case "justificationLetterDesired":case "justificationLetterMaximum":case "justificationGlyphMinimum":case "justificationGlyphDesired":case "justificationGlyphMaximum":case "defaultTabWidth":case "start":case "end":i = [ "<double>", n ];break;case "rowGutter":case "columnGutter":case "spacing":case "firstBaselineMinimum":case "size":case "leading":case "baselineShift":case "underlineOffset":case "lineWidth":case "miterLimit":case "firstLineIndent":case "startIndent":case "endIndent":case "spaceBefore":case "spaceAfter":i = l ? [ "<unitDouble>", [ l, n ] ] : [ "<double>", n ];break;case "horizontal":case "vertical":i = t ? [ "<unitDouble>", [ t, n ] ] : [ "<double>", n ];break;case "hue":i = [ "<unitDouble>", [ "angleUnit", n ] ];break;case "warpStyle":case "textGridding":case "orientation":case "textType":case "frameBaselineAlignment":case "autoKern":case "fontCaps":case "baseline":case "otbaseline":case "strikethrough":case "underline":case "figureStyle":case "baselineDirection":case "textLanguage":case "japaneseAlternate":case "gridAlignment":case "wariChuJustification":case "lineCap":case "lineJoin":case "leadingType":case "burasagari":case "preferredKinsokuOrder":case "pathTypeEffect":case "pathTypeAlignment":case "pathTypeAlignTo":case "directionType":case "textComposerEngine":case "kashidaWidthType":case "digitSet":case "dirOverride":case "kashidas":case "diacVPos":i = [ "<enumerated>", [ a, n ] ];break;case "antiAlias":i = [ "<enumerated>", [ "antiAliasType", n ] ];break;case "warpRotate":i = [ "<enumerated>", [ "orientation", n ] ];break;case "alignment":case "singleWordJustification":i = [ "<enumerated>", [ "alignmentType", n ] ];break;case "textShape":case "textStyleRange":case "paragraphStyleRange":case "kerningRange":o = [];for (var s = 0; s < n.length; s++) {o.push([ "<object>", [ a, u(n[s]) ] ]);}i = [ "<list>", o ];break;case "warp":case "transform":case "textStyle":case "paragraphStyle":i = [ "<object>", [ a, u(n) ] ];break;case "defaultStyle":i = [ "<object>", [ "textStyle", u(n) ] ];break;case "color":case "strokeColor":var c;if ("book" in n && "name" in n || "bookID" in n && "bookKey" in n) {c = "bookColor";} else if ("cyan" in n && "magenta" in n && "yellowColor" in n && "black" in n) {c = "CMYKColorClass";} else if ("gray" in n) {c = "grayscale";} else if ("hue" in n && "saturation" in n && "brightness" in n) {c = "HSBColorClass";} else if ("luminance" in n && "a" in n && "b" in n) {c = "labColor";} else if ("red" in n && "green" in n && "blue" in n) {c = "RGBColor";}i = [ "<object>", [ c, u(n) ] ];break;case "textClickPoint":i = [ "<object>", [ "point", u(n, "percentUnit") ] ];break;case "base":i = [ "<object>", [ "point", u(n) ] ];break;case "bounds":i = [ "<object>", [ "rectangle", u(n) ] ];break;case "path":i = [ "<object>", [ "pathClass", {"pathComponents": jamHelpers.toPathComponentList(n)} ] ];break;case "tRange":i = [ "<object>", [ "range", u(n) ] ];break;case "textLayer":i = [ "<object>", [ "textLayer", u(n) ] ];break;case "mojiKumiName":case "kinsokuSetName":if (true) {i = [ "<enumerated>", [ a, n ] ];} else {i = [ "<string>", n ];}break;case "leftAki":case "rightAki":if (true) {i = [ "<double>", n ];} else {i = l ? [ "<unitDouble>", [ l, n ] ] : [ "<double>", n ];}break;}if (i) {r[a] = i;}}}return r;}return u({"textLayer": t})["textLayer"];};jamText.fromLayerTextObject = function(e) {var t = {};var n;var i = false;function r(e, t) {var r;if (t === "path") {r = jamHelpers.fromPathComponentList(e[t][1][1]["pathComponents"], true);} else if (!i) {switch (t) {case "rowGutter":case "columnGutter":case "spacing":case "firstBaselineMinimum":case "size":case "leading":case "baselineShift":case "underlineOffset":case "lineWidth":case "miterLimit":case "firstLineIndent":case "startIndent":case "endIndent":case "spaceBefore":case "spaceAfter":case "leftAki":case "rightAki":var a = e[t];if (a[0] === "<unitDouble>") {n = a[1][0];}i = true;break;}}return r;}t["layerText"] = jamEngine.simplifyObject(e, r);if (n) {t["typeUnit"] = n;}return t;};jamText.setLayerText = function(e) {var t = jamEngine.meaningfulIds;var r = jamEngine.parseFriendly;jamEngine.meaningfulIds = true;jamEngine.parseFriendly = true;var a = false;try {resultObj = jamEngine.jsonGet([ {"property": {"<property>": "textKey"}}, {"layer": {"<enumerated>": {"ordinal": "targetEnum"}}} ]);if ("textKey" in resultObj) {a = true;}} catch (e) {}jamEngine.meaningfulIds = t;jamEngine.parseFriendly = r;if (a) {jamEngine.jsonPlay("set", {"target": [ "<reference>", [ [ "layer", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ],"to": this.toLayerTextObject(e)});} else {jamEngine.jsonPlay("make", {"target": [ "<reference>", [ [ "textLayer", [ "<class>", null ] ] ] ],"using": this.toLayerTextObject(e)});}};jamText.getLayerText = function() {var e = null;var t = jamEngine.meaningfulIds;var r = jamEngine.parseFriendly;jamEngine.meaningfulIds = true;jamEngine.parseFriendly = true;try {var a = jamEngine.jsonGet([ {"property": {"<property>": "textKey"}}, {"layer": {"<enumerated>": {"ordinal": "targetEnum"}}} ]);if ("textKey" in a) {e = this.fromLayerTextObject(a["textKey"]);}} catch (e) {}jamEngine.meaningfulIds = t;jamEngine.parseFriendly = r;return e;};})();}if (typeof jamStyles !== "object") {var jamStyles = {};(function() {jamStyles.isStylesFile = function(e) {return e.type === "8BSL" || e.name.match(/\.asl$/i);};jamStyles.isStylesPalette = function(e) {return e.name.match(/^Styles.psp$/i);};jamStyles.toLayerEffectsObject = function(e) {function u(e, t) {var r = {};for (var a in e) {if (e.hasOwnProperty(a)) {var n = e[a];var i = null;var o;switch (a) {case "align":case "antiAlias":case "antialiasGloss":case "continuity":case "dither":case "enabled":case "invert":case "invertTexture":case "layerConceals":case "linked":case "reverse":case "showTransparency":case "useGlobalAngle":case "useShape":case "useTexture":case "vectorColor":i = [ "<boolean>", n ];break;case "book":case "ID":case "name":i = [ "<string>", localize(n) ];break;case "bookKey":i = [ "<data>", n ];break;case "bookID":case "location":case "midpoint":case "randomSeed":case "smoothness":i = [ "<integer>", n ];break;case "a":case "b":case "black":case "blue":case "brightness":case "cyan":case "gray":case "green":case "interpolation":case "luminance":case "magenta":case "red":case "saturation":case "yellowColor":i = [ "<double>", n ];break;case "angle":case "hue":case "localLightingAngle":case "localLightingAltitude":i = [ "<unitDouble>", [ "angleUnit", n ] ];break;case "chokeMatte":case "highlightOpacity":case "inputRange":case "noise":case "opacity":case "scale":case "shadingNoise":case "shadowOpacity":case "strengthRatio":case "textureDepth":i = [ "<unitDouble>", [ "percentUnit", n ] ];break;case "blur":case "distance":case "size":case "softness":i = [ "<unitDouble>", [ "pixelsUnit", n ] ];break;case "horizontal":case "vertical":i = t ? [ "<unitDouble>", [ t, n ] ] : [ "<double>", n ];break;case "type":var s;switch (n) {case "linear":case "radial":case "angle":case "reflected":case "diamond":case "shapeburst":s = "gradientType";break;case "foregroundColor":case "backgroundColor":case "userStop":s = "colorStopType";break;}i = [ "<enumerated>", [ s, n ] ];break;case "colorSpace":i = [ "<enumerated>", [ "colorSpace", n ] ];break;case "gradientForm":i = [ "<enumerated>", [ "gradientForm", n ] ];break;case "paintType":i = [ "<enumerated>", [ "frameFill", n ] ];break;case "bevelDirection":i = [ "<enumerated>", [ "bevelEmbossStampStyle", n ] ];break;case "bevelStyle":i = [ "<enumerated>", [ "bevelEmbossStyle", n ] ];break;case "bevelTechnique":i = [ "<enumerated>", [ "bevelTechnique", n ] ];break;case "glowTechnique":i = [ "<enumerated>", [ "matteTechnique", n ] ];break;case "innerGlowSource":i = [ "<enumerated>", [ "innerGlowSourceType", n ] ];break;case "style":i = [ "<enumerated>", [ "frameStyle", n ] ];break;case "highlightMode":case "mode":case "shadowMode":i = [ "<enumerated>", [ "blendMode", n ] ];break;case "bevelEmboss":case "chromeFX":case "dropShadow":case "frameFX":case "gradientFill":case "innerGlow":case "innerShadow":case "outerGlow":case "pattern":case "patternFill":case "solidFill":i = [ "<object>", [ a, u(n) ] ];break;case "color":case "highlightColor":case "shadowColor":var c;if ("book" in n && "name" in n || "bookID" in n && "bookKey" in n) {c = "bookColor";} else if ("cyan" in n && "magenta" in n && "yellowColor" in n && "black" in n) {c = "CMYKColorClass";} else if ("gray" in n) {c = "grayscale";} else if ("hue" in n && "saturation" in n && "brightness" in n) {c = "HSBColorClass";} else if ("luminance" in n && "a" in n && "b" in n) {c = "labColor";} else if ("red" in n && "green" in n && "blue" in n) {c = "RGBColor";}i = [ "<object>", [ c, u(n) ] ];break;case "gradient":i = [ "<object>", [ "gradientClassEvent", u(n) ] ];break;case "mappingShape":case "transparencyShape":i = [ "<object>", [ "shapingCurve", u(n) ] ];break;case "offset":i = [ "<object>", [ "point", u(n, "percentUnit") ] ];break;case "phase":i = [ "<object>", [ "point", u(n) ] ];break;case "minimum":case "maximum":o = [];for (var l = 0; l < n.length; l++) {o.push([ "<integer>", n[l] ]);}i = [ "<list>", o ];break;case "colors":o = [];for (var l = 0; l < n.length; l++) {o.push([ "<object>", [ "colorStop", u(n[l]) ] ]);}i = [ "<list>", o ];break;case "transparency":o = [];for (var l = 0; l < n.length; l++) {o.push([ "<object>", [ "transparencyStop", u(n[l]) ] ]);}i = [ "<list>", o ];break;case "curve":o = [];for (var l = 0; l < n.length; l++) {o.push([ "<object>", [ "curvePoint", u(n[l]) ] ]);}i = [ "<list>", o ];break;case "layerEffects":i = [ "<object>", [ "layerEffects", u(n) ] ];break;}if (i) {r[a] = i;}}}return r;}return u({"layerEffects": e})["layerEffects"];};jamStyles.fromLayerEffectsObject = function(e) {return jamEngine.simplifyObject(e);};jamStyles.toBlendOptionsObject = function(e) {function s(e) {var t = {};for (var r in e) {if (e.hasOwnProperty(r)) {var a = e[r];var n = null;var i;switch (r) {case "blendClipped":case "blendInterior":case "layerMaskAsGlobalMask":case "transparencyShapesLayer":case "vectorMaskAsGlobalMask":n = [ "<boolean>", a ];break;case "srcBlackMin":case "srcBlackMax":case "srcWhiteMin":case "srcWhiteMax":case "destBlackMin":case "destBlackMax":case "destWhiteMin":case "destWhiteMax":n = [ "<integer>", a ];break;case "fillOpacity":case "opacity":n = [ "<unitDouble>", [ "percentUnit", a ] ];break;case "mode":n = [ "<enumerated>", [ "blendMode", a ] ];break;case "knockout":n = [ "<enumerated>", [ "knockout", a ] ];break;case "channel":n = [ "<reference>", [ [ "channel", [ "<enumerated>", [ "channel", a ] ] ] ] ];break;case "blendRange":i = [];for (var o = 0; o < a.length; o++) {i.push([ "<object>", [ "blendRange", s(a[o]) ] ]);}n = [ "<list>", i ];break;case "channelRestrictions":i = [];for (var o = 0; o < a.length; o++) {i.push([ "<enumerated>", [ "channel", a[o] ] ]);}n = [ "<list>", i ];break;case "blendOptions":n = [ "<object>", [ "blendOptions", s(a) ] ];break;}if (n) {t[r] = n;}}}return t;}return s({"blendOptions": e})["blendOptions"];};jamStyles.fromBlendOptionsObject = function(e) {var t = function(e, t, r) {var a = undefined;if (t === "channel") {var n = r(e, t);a = n[0]["channel"];}return a;};return jamEngine.simplifyObject(e, t);};jamStyles.toDocumentModeObject = function(e) {function i(e) {var t = {};for (var r in e) {if (e.hasOwnProperty(r)) {var a = e[r];var n = null;switch (r) {case "colorSpace":n = [ "<enumerated>", [ "colorSpace", a ] ];break;case "depth":n = [ "<integer>", a ];break;case "documentMode":n = [ "<object>", [ "documentMode", i(a) ] ];break;}if (n) {t[r] = n;}}}return t;}return i({"documentMode": e})["documentMode"];};jamStyles.fromDocumentModeObject = function(e) {return jamEngine.simplifyObject(e);};function p() {var e = {};var t = jamEngine.meaningfulIds;var r = jamEngine.parseFriendly;jamEngine.meaningfulIds = true;jamEngine.parseFriendly = true;var a;a = jamEngine.jsonGet([ [ "property", [ "<property>", "mode" ] ], [ "document", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ]);e["colorSpace"] = a["mode"][1][1];a = jamEngine.jsonGet([ [ "property", [ "<property>", "depth" ] ], [ "document", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ]);e["depth"] = a["depth"][1];jamEngine.meaningfulIds = t;jamEngine.parseFriendly = r;return e;}function y() {var e = jamEngine.meaningfulIds;var t = jamEngine.parseFriendly;jamEngine.meaningfulIds = true;jamEngine.parseFriendly = true;var r = jamEngine.jsonGet([ [ "property", [ "<property>", "resolution" ] ], [ "document", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ]);jamEngine.meaningfulIds = e;jamEngine.parseFriendly = t;return r["resolution"][1][1];}jamStyles.setLayerStyle = function(e, t) {if (e && ("blendOptions" in e || "layerEffects" in e)) {var r = {};if ("blendOptions" in e) {defaultBlendOptionsObj = {"mode": "normal","opacity": 100,"fillOpacity": 100,"channelRestrictions": [],"knockout": "none","blendInterior": false,"blendClipped": true,"transparencyShapesLayer": true,"layerMaskAsGlobalMask": false,"vectorMaskAsGlobalMask": false,"blendRange": []};var a = p();var n;var i;switch (a["colorSpace"]) {case "CMYKColorEnum":case "CMYK64":n = [ "cyan", "magenta", "yellow", "black" ];i = [ "gray", "cyan", "magenta", "yellow", "black" ];break;case "duotone":case "grayScale":case "gray16":n = [ "black" ];i = [ "black" ];break;case "labColor":case "lab48":n = [ "lightness", "a", "b" ];i = [ "lightness", "a", "b" ];break;case "RGBColor":case "RGB48":n = [ "red", "green", "blue" ];i = [ "gray", "red", "green", "blue" ];break;}defaultBlendOptionsObj["channelRestrictions"] = n;for (var o = 0; o < i.length; o++) {defaultBlendRangeObj = {"channel": i[o],"srcBlackMin": 0,"srcBlackMax": 0,"srcWhiteMin": 255,"srcWhiteMax": 255,"destBlackMin": 0,"destBlackMax": 0,"destWhiteMin": 255,"destWhiteMax": 255};defaultBlendOptionsObj["blendRange"].push(defaultBlendRangeObj);}var s = jamUtils.mergeData(e["blendOptions"], defaultBlendOptionsObj);var c = this.toBlendOptionsObject(s)[1][1];for (var l in c) {if (c.hasOwnProperty(l)) {r[l] = c[l];}}}var u;if ("layerEffects" in e) {u = e["layerEffects"];r["layerEffects"] = this.toLayerEffectsObject(u);}jamEngine.jsonPlay("set", {"target": [ "<reference>", [ [ "layer", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ],"to": [ "<object>", [ "layer", r ] ]});if (u) {if ("scale" in u && !t) {this.scaleLayerEffects(y() / 72 / (u["scale"] / 100) * 100);}}} else {this.clearLayerStyle();}};function u() {var e = jamEngine.meaningfulIds;var t = jamEngine.parseFriendly;jamEngine.meaningfulIds = true;jamEngine.parseFriendly = true;var r = jamEngine.jsonGet([ [ "property", [ "<property>", "presetManager" ] ], [ "application", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ]);var a = r["presetManager"][1];var n;for (var i = 0; i < a.length; i++) {var o = a[i][1];if (o[0] === "styleClass") {n = o[1]["name"][1].length;break;}}jamEngine.meaningfulIds = e;jamEngine.parseFriendly = t;return n;}function f() {var e = jamEngine.meaningfulIds;var t = jamEngine.parseFriendly;jamEngine.meaningfulIds = true;jamEngine.parseFriendly = true;var r = false;try {var a = jamEngine.jsonGet([ [ "property", [ "<property>", "background" ] ], [ "layer", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ]);r = !a["background"][1];} catch (e) {}var e = jamEngine.meaningfulIds;var t = jamEngine.parseFriendly;return r;}jamStyles.getLayerStyle = function() {var e = null;if (f()) {var t = u();var r = new Date();var a = "Temp-Layer-Style-" + r.getTime();try {jamEngine.jsonPlay("make", {"target": [ "<reference>", [ [ "style", [ "<class>", null ] ] ] ],"name": [ "<string>", a ],"using": [ "<reference>", [ [ "layer", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ],"blendOptions": [ "<boolean>", true ],"layerEffects": [ "<boolean>", true ]});} catch (e) {}var n = u();if (n === t + 1) {var i = new File(Folder.temp + "/" + a + ".asl");jamEngine.jsonPlay("set", {"target": [ "<path>", i.fsName ],"to": [ "<list>", [ [ "<reference>", [ [ "style", [ "<index>", n ] ] ] ] ] ]});jamEngine.jsonPlay("delete", {"target": [ "<list>", [ [ "<reference>", [ [ "style", [ "<index>", n ] ] ] ] ] ]});var o = this.dataFromStylesFile(i);if (typeof o === "string") {alert(o + "\n" + "Styles file: “" + File.decode(i.name) + "”");} else {e = o["styles"][0];if ("name" in e) {delete e["name"];}if ("ID" in e) {delete e["ID"];}if ("documentMode" in e) {delete e["documentMode"];}if ("layerEffects" in e) {var s = e["layerEffects"];if ("masterFXSwitch" in s) {delete s["masterFXSwitch"];}}}if (arguments.length > 0) {var c = arguments[0];if (c && c.constructor === Object) {if ("patterns" in c) {var l = this.patternsFromStylesFile(i);if (typeof l === "string") {alert(l + "\n" + "Styles file: “" + File.decode(i.name) + "”");} else {c["patterns"] = l;}}}}i.remove();}}return e;};jamStyles.copyLayerStyle = function() {try {jamEngine.jsonPlay("copyEffects", null);} catch (e) {}};jamStyles.pasteLayerStyle = function() {try {jamEngine.jsonPlay("pasteEffects", {});} catch (e) {}};jamStyles.clearLayerStyle = function() {try {jamEngine.jsonPlay("disableLayerStyle", {"target": [ "<reference>", [ [ "layer", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ]});} catch (e) {}};jamStyles.applyLayerStyle = function(e, t) {var r = {"target": [ "<reference>", [ [ "style", [ "<name>", e ] ] ] ],"to": [ "<reference>", [ [ "layer", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ]};if (typeof t !== "undefined" && t) {r["merge"] = [ "<boolean>", t ];}jamEngine.jsonPlay("applyStyle", r);};jamStyles.scaleLayerEffects = function(e) {jamEngine.jsonPlay("scaleEffectsEvent", {"scale": [ "<unitDouble>", [ "percentUnit", e ] ]});};jamStyles.removeLayerEffect = function(e) {try {jamEngine.jsonPlay("disableSingleFX", {"target": [ "<reference>", [ [ e, [ "<class>", null ] ], [ "layer", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ]});} catch (e) {}};jamStyles.removeLayerEffects = function(e) {for (var t = 0; t < e.length; t++) {this.removeLayerEffect(e[t]);}};jamStyles.removeAllLayerEffects = function() {try {jamEngine.jsonPlay("disableLayerFX", {"target": [ "<reference>", [ [ "layer", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ]});} catch (e) {}};jamStyles.showHideLayerEffects = function(e, t) {var r = [];for (var a = 0; a < e.length; a++) {r.push([ "<reference>", [ [ e[a], [ "<class>", null ] ], [ "layer", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ]);}try {jamEngine.jsonPlay(t ? "show" : "hide", {"target": [ "<list>", r ]}, DialogModes.NO);} catch (e) {}};jamStyles.showHideLayerEffect = function(e, t) {this.showHideLayerEffects([ e ], t);};jamStyles.showHideAllLayerEffects = function(e) {this.showHideLayerEffects([ "layerEffects" ], e);};jamStyles.showHideAllDocumentEffects = function(e) {jamEngine.jsonPlay("set", {"target": [ "<reference>", [ [ "property", [ "<property>", "layerFXVisible" ] ], [ "document", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ],"to": [ "<object>", [ "layerFXVisible", {"layerFXVisible": [ "<boolean>", e || false ]} ] ]});};function r(e, t, r) {var a = {"globalLightingAngle": [ "<unitDouble>", [ "angleUnit", t ] ]};if (typeof r !== "undefined") {a["globalAltitude"] = [ "<unitDouble>", [ "angleUnit", r ] ];}jamEngine.jsonPlay("set", {"target": [ "<reference>", [ [ "property", [ "<property>", "globalAngle" ] ], [ e, [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ],"to": [ "<object>", [ "globalAngle", a ] ]});}jamStyles.setApplicationGlobalAngle = function(e, t) {r("application", e, t);};jamStyles.setDocumentGlobalAngle = function(e, t) {r("document", e, t);};function _(e, t) {var r = e.read(t);var a = 0;for (var n = 0; n < t; n++) {a = (a << 8) + r.charCodeAt(n);}return a;}function k(e) {var t = "";var r = _(e, 4);for (var a = 0; a < r; a++) {var n = _(e, 2);if (n !== 0) {t += String.fromCharCode(n);}}return t;}function l(e, t) {return e.read(t);}function j(e) {var t = _(e, 1);return l(e, t);}jamStyles.dataFromStylesFile = function(e, t) {var r = [ "Bitmap", "Grayscale", "Indexed", "RGB", "CMYK", null, null, "Multichannel", "Duotone", "Lab" ];var a;if (typeof e === "string") {a = new File(e);} else if (e instanceof File) {a = e;}var n;if (a.open("r")) {try {a.encoding = "BINARY";var i;if (this.isStylesPalette(a)) {i = 2;} else if (this.isStylesFile(a)) {i = _(a, 2);}if (i === 2) {var o = a.read(4);if (o === "8BSL") {var s = _(a, 2);if (s === 3) {var c = _(a, 4);var l = a.tell() + c;if (t) {var u = [];while (a.tell() < l) {var p = {};var y = _(a, 4);var f = a.tell() + y;var h = _(a, 4);p["version"] = h;if (h === 1) {p["imageMode"] = r[_(a, 4)];p["height"] = _(a, 2);p["width"] = _(a, 2);p["name"] = k(a);p["ID"] = j(a);} else {p["error"] = "Unsupported version";}u.push(p);a.seek(f + (4 - y % 4) % 4, 0);}}a.seek(l, 0);var g = jamEngine.meaningfulIds;var d = jamEngine.parseFriendly;jamEngine.meaningfulIds = true;jamEngine.parseFriendly = true;var v;var m;var T = [];var I = _(a, 4);for (var D = 0; D < I; D++) {var b = {};var S = _(a, 4);var x = a.tell() + S;v = jamActions.readActionDescriptor(a);m = jamEngine.classIdAndActionDescriptorToJson(0, v)["<descriptor>"];b["name"] = m["name"][1];b["ID"] = m["ID"][1];v = jamActions.readActionDescriptor(a);m = jamEngine.classIdAndActionDescriptorToJson(0, v)["<descriptor>"];if ("documentMode" in m) {b["documentMode"] = this.fromDocumentModeObject(m["documentMode"]);}if ("blendOptions" in m) {b["blendOptions"] = this.fromBlendOptionsObject(m["blendOptions"]);}if ("layerEffects" in m) {b["layerEffects"] = this.fromLayerEffectsObject(m["layerEffects"]);}T.push(b);a.seek(x, 0);}jamEngine.meaningfulIds = g;jamEngine.parseFriendly = d;n = {};if (t) {n["patterns"] = u;}n["styles"] = T;} else {throw new Error("[jamStyles.dataFromStylesFile] Unrecognized sub-version: " + s);}} else {throw new Error("[jamStyles.dataFromStylesFile] Unrecognized magic number: " + o);}} else {throw new Error("[jamStyles.dataFromStylesFile] Unrecognized format version: " + i);}} catch (e) {n = e.message;} finally {a.close();}} else {n = "[jamStyles.dataFromStylesFile] Cannot open file";}return n;};jamStyles.patternsFromStylesFile = function(e) {var t;if (typeof e === "string") {t = new File(e);} else if (e instanceof File) {t = e;}var r;if (t.open("r")) {try {t.encoding = "BINARY";var a;if (this.isStylesPalette(t)) {a = 2;} else if (this.isStylesFile(t)) {a = _(t, 2);}if (a === 2) {var n = t.read(4);if (n === "8BSL") {var i = _(t, 2);if (i === 3) {var o = _(t, 4);var s = t.tell() + o;var r = [];while (t.tell() < s) {var c = _(t, 4);r.push(l(t, c));t.seek((4 - c % 4) % 4, 1);}} else {throw new Error("[jamStyles.patternsFromStylesFile] Unrecognized sub-version: " + i);}} else {throw new Error("[jamStyles.patternsFromStylesFile] Unrecognized magic number: " + n);}} else {throw new Error("[jamStyles.patternsFromStylesFile] Unrecognized format version: " + a);}} catch (e) {r = e.message;} finally {t.close();}} else {r = "[jamStyles.patternsFromStylesFile] Cannot open file";}return r;};jamStyles.patternsFileFromPatterns = function(e, t) {var r;if (typeof e === "string") {r = new File(e);} else if (e instanceof File) {r = e;}if (r.open("w", "8BPT", "8BIM")) {r.encoding = "BINARY";r.write("8BPT");r.write("\0");var a = t.length;r.write(String.fromCharCode(a >> 24 & 255, a >> 16 & 255, a >> 8 & 255, a & 255));for (var n = 0; n < a; n++) {r.write(t[n]);}r.close();}};})();}if (typeof jamUtils !== "object") {var jamUtils = {};(function() {jamUtils.toDistanceUnit = function(e, t) {return e / t * 72;};jamUtils.fromDistanceUnit = function(e, t) {return e / 72 * t;};jamUtils.fontExists = function(e) {var t = true;var r = false;if (t) {for (var a = 0; a < app.fonts.length; a++) {if (app.fonts[a].postScriptName === e) {r = true;break;}}} else {var n = jamEngine.meaningfulIds;var i = jamEngine.parseFriendly;jamEngine.meaningfulIds = true;jamEngine.parseFriendly = true;var o = jamEngine.jsonGet([ [ "property", [ "<property>", "fontList" ] ], [ "application", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ]);var s = o["fontList"][1][1]["fontPostScriptName"][1];for (var a = 0; a < s.length; a++) {if (s[a][1] === e) {r = true;break;}}jamEngine.meaningfulIds = n;jamEngine.parseFriendly = i;}return r;};jamUtils.loadAction = function(e, t, r) {try {jamEngine.jsonGet([ [ "action", [ "<name>", e ] ], [ "actionSet", [ "<name>", t ] ] ]);var a = true;} catch (e) {var a = false;}if (!a) {jamEngine.jsonPlay("open", {"target": [ "<path>", r ]});}};jamUtils.loadActionSet = function(e, t) {try {jamEngine.jsonGet([ [ "actionSet", [ "<name>", e ] ] ]);var r = true;} catch (e) {var r = false;}if (!r) {jamEngine.jsonPlay("open", {"target": [ "<path>", t ]});}};jamUtils.loadPreset = function(e, t, r) {var a = false;var n = true;var i = {"brush": "brush","colors": "color","gradientClassEvent": "gradientClassEvent","style": "styleClass","pattern": "'PttR'","shapingCurve": "shapingCurve","customShape": "customShape","toolPreset": "toolPreset"};var o = i[e];var s = jamEngine.meaningfulIds;var c = jamEngine.parseFriendly;jamEngine.meaningfulIds = true;jamEngine.parseFriendly = true;var l = false;var u = jamEngine.jsonGet([ [ "property", [ "<property>", "presetManager" ] ], [ "application", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ]);var p = u["presetManager"][1];for (var y = 0; y < p.length; y++) {var f = p[y][1];if (f[0] === o) {var h = f[1]["name"][1];for (var g = 0; g < h.length; g++) {if (h[g][1] === t) {l = true;break;}}break;}}if (!l) {if (a) {app.load(new File(r));} else if (n) {jamEngine.jsonPlay("open", {"target": [ "<path>", r ]});} else {jamEngine.jsonPlay("set", {"target": [ "<reference>", [ [ "property", [ "<property>", e ] ], [ "application", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ],"to": [ "<path>", r ],"append": [ "<boolean>", true ]});}}jamEngine.meaningfulIds = s;jamEngine.parseFriendly = c;};function a(e) {var t;if (e instanceof File) {t = e;} else if (typeof e === "string") {t = new File(e);} else {throw new Error("[jamUtils getFileObject] Invalid argument");}return t;}jamUtils.readTextFile = function(e) {var t = null;var r = a(e);if (r.open("r")) {t = r.read();r.close();}return t;};jamUtils.readJsonFile = function(e) {return jamJSON.parse(this.readTextFile(e), true);};jamUtils.writeTextFile = function(e, t) {var r = a(e);if (r.open("w", "TEXT")) {r.encoding = "UTF-8";r.lineFeed = "unix";r.write("\ufeff");r.write(t);r.close();}};jamUtils.writeJsonFile = function(e, t, r) {this.writeTextFile(e, jamJSON.stringify(t, r));};jamUtils.cloneData = function(e) {var t;if (e === null) {t = e;} else if (e.constructor === Object) {t = {};for (var r in e) {if (e.hasOwnProperty(r)) {t[r] = this.cloneData(e[r]);}}} else if (e.constructor === Array) {t = [];for (var a = 0; a < e.length; a++) {t.push(this.cloneData(e[a]));}} else {t = e;}return t;};jamUtils.mergeData = function(e, t) {for (var r in t) {if (t.hasOwnProperty(r)) {if (r in e) {if (t[r] !== null && t[r].constructor === Object) {e[r] = this.mergeData(e[r], t[r]);}} else {e[r] = this.cloneData(t[r]);}}}return e;};var o = "jsonCustomOptions";jamUtils.getCustomOptions = function(e, t) {var r = jamEngine.meaningfulIds;var a = jamEngine.parseFriendly;jamEngine.meaningfulIds = true;jamEngine.parseFriendly = false;try {var n = jamEngine.classIdAndActionDescriptorToJson(jamEngine.uniIdStrToId(e), app.getCustomOptions(e));var i = jamJSON.parse(n["<descriptor>"][o]["<string>"], true);} catch (e) {var i = {};}jamEngine.meaningfulIds = r;jamEngine.parseFriendly = a;return this.mergeData(i, t);};jamUtils.putCustomOptions = function(e, t, r) {var a = {};a[o] = [ "<string>", jamJSON.stringify(t) ];app.putCustomOptions(e, jamEngine.jsonToActionDescriptor(a), r);};jamUtils.eraseCustomOptions = function(e) {app.eraseCustomOptions(e);};jamUtils.dataToHexaString = function(e, t) {var r = [ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" ];var a = "";var n = e.length;for (var i = 0; i < n; i++) {var o = e.charCodeAt(i);if (o >= 0 && o <= 255) {a += r[(o & 240) >> 4] + r[o & 15];} else {throw new Error("[jamUtils.dataToHexaString] Invalid data string");}}if (t) {a = a.toLowerCase();}return a;};jamUtils.hexaToDataString = function(e) {var t = "";var r = e.length;if (r % 2 === 0 && /^[0-9A-Fa-f]*$/.test(e)) {for (var a = 0; a < r; a += 2) {var n = e.slice(a, a + 2);t += String.fromCharCode(parseInt(n, 16));}} else {throw new Error("[jamUtils.hexaToDataString] Invalid hexa string");}return t;};})();}(function(e) {function d(e) {return String(e || "").toLowerCase().replace(/[^a-z0-9]+/g, "");}function v(e) {var t = String(e || "").toLowerCase();return {"bold": /(bold|demi|semi|black|heavy)/.test(t),"italic": /(italic|oblique|slanted)/.test(t)};}var i = null;var o = -1;var s = [];function m(e) {var t = e && typeof e.length === "number" ? e.length : 0;if (e === i && t === o) return s;var r = [];for (var a = 0; a < t; a++) {var n = e[a] || {};r.push({"font": n,"name": d(n.name),"postScriptName": d(n.postScriptName),"family": d(n.family),"traits": v(n.style)});}i = e;o = t;s = r;return r;}function T(e, t) {var r = d(t.fontPostScriptName);var a = d(t.fontName);var n;if (r) {for (n = 0; n < e.length; n++) {if (e[n].postScriptName === r || e[n].name === r) return e[n];}}if (a) {for (n = 0; n < e.length; n++) {if (e[n].name === a || e[n].family === a) return e[n];}}return null;}function t(e, t, r) {if (!e || !t || !t.bold && !t.italic) return e;var a = m(r);var n = T(a, e);var i = v(e.fontStyleName);var o = n ? n.traits : i;var s = !!(t.bold || e.syntheticBold || o.bold || i.bold);var c = !!(t.italic || e.syntheticItalic || o.italic || i.italic);var l = n ? n.family : d(e.fontName);var u = n;var p = -1;for (var y = 0; y < a.length; y++) {var f = a[y];if (!l || f.family !== l) continue;if (f.traits.bold && !s) continue;if (f.traits.italic && !c) continue;var h = 0;if (s && f.traits.bold) h += t.bold ? 200 : 100;if (c && f.traits.italic) h += t.italic ? 200 : 100;if (f === n) h += 5;if (h > p) {u = f;p = h;}}var g = u ? u.traits : o;if (u) {e.fontPostScriptName = u.font.postScriptName || u.font.name || e.fontPostScriptName;e.fontName = u.font.family || u.font.name || e.fontName;e.fontStyleName = u.font.style || e.fontStyleName;}e.syntheticBold = !!(s && !g.bold);e.syntheticItalic = !!(c && !g.italic);return e;}e.resolveTypeRFontVariant = t;if (typeof module !== "undefined" && module.exports) module.exports = {"resolveTypeRFontVariant": t};})(this);var charID = {"AdjustmentLayer": 1097099891,"Back": 1113678699,"Background": 1113811815,"Bottom": 1114926957,"By": 1115234336,"Channel": 1130917484,"Contract": 1131312227,"Delete": 1147958304,"Document": 1147366766,"Expand": 1165521006,"FrameSelect": 1718838636,"From": 1181904749,"Hide": 1214521376,"Horizontal": 1215461998,"Layer": 1283027488,"LayerID": 1283027529,"Left": 1281713780,"Make": 1298866208,"Move": 1836021349,"None": 1315925605,"Null": 1853189228,"Offset": 1332114292,"Ordinal": 1332896878,"Path": 1348564072,"PixelUnit": 592476268,"Point": 1349415968,"Property": 1349677170,"Right": 1382508660,"Select": 1936483188,"SelectionClass": 1668506988,"Set": 1936028772,"Show": 1399355168,"Size": 1400512544,"Target": 1416783732,"Text": 1417180192,"TextLayer": 1417170034,"TextShapeType": 1413830740,"TextStyle": 1417180243,"TextStyleRange": 1417180276,"To": 1411391520,"Tolerance": 1416393326,"Top": 1416589344,"Vertical": 1450341475,"Visible": 1450402412,"WorkPath": 1467116368};var _SAFE_PARAGRAPH_PROPS = [ "align", "alignment", "firstLineIndent", "startIndent", "endIndent", "spaceBefore", "spaceAfter", "autoLeadingPercentage", "leadingType", "hyphenate", "hyphenateWordSize", "hyphenatePreLength", "hyphenatePostLength", "hyphenateLimit", "hyphenationZone", "hyphenateCapitalized", "hangingRoman", "burasagari", "textEveryLineComposer", "textComposerEngine" ];var _DEFAULT_SELECTION_SCALE = .9;var _MIN_TEXTBOX_WIDTH = 10;var _TEMP_SELECTION_CHANNEL = "__TyperSelectionTemp__";var _SELECTION_OPEN_RATIO = .1;var _MIN_SELECTION_OPEN_RADIUS = 4;var _hostState = {"fallbackTextSize": 20,"setActiveLayerText": {"data": null,"result": ""},"setSelectedTextLayers": {"data": null,"result": ""},"setTextShapeRText": {"data": null,"result": ""},"getRenderedTextLines": {"result": ""},"getAllRenderedTextLines": {"result": "","scanBubbles": false},"createTextLayerInSelection": {"data": null,"result": "","point": false,"padding": 0},"alignTextLayerToSelection": {"result": "","resize": false,"keep": false,"padding": 0,"placements": {}},"alignTextLayersToDoubleBubble": {"result": "","resize": false,"padding": 0,"entries": null},"changeActiveLayerTextSize": {"value": 0,"result": ""},"selectionMonitor": {"lastBoundsKey": null,"lastBounds": null,"multiWarnBounds": null,"callback": null},"createTextLayersInStoredSelections": {"data": null,"result": "","point": false,"padding": 0,"selections": []},"hiddenCleaningLayerIdsByDocument": {},"documentSession": String(new Date().getTime()) + ":" + String(Math.random()),"lastOpenedDocId": null,"suspendedRun": null,"pathScanFails": 0,"pathScanBackoffAt": 0};var _PATH_SCAN_RETRY_MS = 3 * 60 * 1e3;function _suspendedHistoryIndex(e, t, r, a) {var n = e.historyStates.length - 1;if ((n < 0 || e.historyStates[n].name !== t) && r >= 0) {try {var i = new ActionReference();i.putIndex(stringIDToTypeID("historyState"), r + 1);var o = new ActionDescriptor();o.putReference(charID.Null, i);executeAction(charID.Select, o, DialogModes.NO);n = e.historyStates.length - 1;if (a && n >= 0 && e.historyStates[n].name === t) a.selected = true;} catch (e) {}}if (n < 0 || e.historyStates[n].name !== t) {app.refresh();n = e.historyStates.length - 1;}return n >= 0 && e.historyStates[n].name === t ? n : -1;}function _withTemporaryHistory(e, t, r) {var a = app.activeDocument;var n = e;var i = null;var o = null;var s = false;var c = !!(r && r.discardRedo);try {var l = a.historyStates.length;o = _getActiveHistoryIndex();if (_hostState.temporaryHistoryFailed || l < (c ? 1 : 2) || !c && o !== l - 1) {return {"error": "historyBusy"};}if (a.historyStates[l - 1].name === n) n += " (temporary)";i = app.preferences.numberOfHistoryStates;if (!(i > 0)) return {"error": "historyBusy"};if (l >= i) {s = true;app.preferences.numberOfHistoryStates = l + 1;if (app.preferences.numberOfHistoryStates <= l) throw new Error("historyCapacity");}} catch (e) {if (s) {try {app.preferences.numberOfHistoryStates = i;} catch (e) {}}return {"error": "historyBusy"};}var u = null;var p = _hostState.suspendedRun;_hostState.suspendedRun = function() {try {u = t();} catch (e) {u = null;}};try {a.suspendHistory(n, "_hostState.suspendedRun()");} catch (e) {u = null;} finally {_hostState.suspendedRun = p;try {var y = {"selected": false};var f = _suspendedHistoryIndex(a, n, o, y);if (f > 0) {if (!y.selected || f - 1 !== o) a.activeHistoryState = a.historyStates[f - 1];var h = new ActionReference();h.putIndex(stringIDToTypeID("historyState"), f + 1);var g = new ActionDescriptor();g.putReference(charID.Null, h);executeAction(charID.Delete, g, DialogModes.NO);}} catch (e) {_hostState.temporaryHistoryFailed = true;u = {"error": "historyBusy"};} finally {if (s) {try {app.preferences.numberOfHistoryStates = i;} catch (e) {_hostState.temporaryHistoryFailed = true;u = {"error": "historyBusy"};}}}}return u;}function _clone(e) {if (!e || typeof e !== "object") return e;if (e instanceof Array) {var t = [];for (var r = 0; r < e.length; r++) {t[r] = _clone(e[r]);}return t;}var a = {};for (var n in e) {if (e.hasOwnProperty(n)) {a[n] = _clone(e[n]);}}return a;}function _normalizeTextKey(e) {return String(e || "").replace(/\r\n/g, "\r").replace(/\n/g, "\r");}function _getHostDefaultStyle() {return {"layerText": {"textGridding": "none","orientation": "horizontal","antiAlias": "antiAliasSmooth","textStyleRange": [ {"from": 0,"to": 100,"textStyle": {"fontPostScriptName": "Tahoma","fontName": "Tahoma","fontStyleName": "Regular","fontScript": 0,"fontTechnology": 1,"fontAvailable": true,"size": 14,"impliedFontSize": 14,"horizontalScale": 100,"verticalScale": 100,"autoLeading": true,"tracking": 0,"baselineShift": 0,"impliedBaselineShift": 0,"autoKern": "metricsKern","fontCaps": "normal","digitSet": "defaultDigits","diacXOffset": 0,"markYDistFromBaseline": 100,"otbaseline": "normal","ligature": true,"altligature": false,"connectionForms": false,"contextualLigatures": true,"baselineDirection": "withStream","color": {"red": 0,"green": 0,"blue": 0}}} ],"paragraphStyleRange": [ {"from": 0,"to": 100,"paragraphStyle": {"burasagari": "burasagariNone","singleWordJustification": "justifyAll","justificationMethodType": "justifMethodAutomatic","textEveryLineComposer": false,"alignment": "center","hangingRoman": true,"hyphenate": true}} ]},"typeUnit": "pixelsUnit"};}function _getHostDefaultStroke() {return {"enabled": false,"size": 0,"opacity": 100,"position": "outer","color": {"r": 255,"g": 255,"b": 255}};}function _ensureStyle(e) {var t = e ? _clone(e) : {};if (!t.textProps || !t.textProps.layerText) {t.textProps = _getHostDefaultStyle();}if (typeof t.stroke === "undefined") {t.stroke = _getHostDefaultStroke();}return t;}function _overrideStyleTextSize(e, t) {if (!e || !(t > 0)) return e;var r = e.textProps && e.textProps.layerText && e.textProps.layerText.textStyleRange;if (!r || !r.length) return e;for (var a = 0; a < r.length; a++) {if (!r[a] || !r[a].textStyle) continue;r[a].textStyle.size = t;if (r[a].textStyle.impliedFontSize != null) {r[a].textStyle.impliedFontSize = t;}}return e;}function _isPunctuationOnlyText(e) {return typeof e === "string" && /^[!?.,;:'"()\[\]~\-\u00A1\u00AB\u00BB\u00BF\u060C\u061B\u061F\u2013\u2014\u2018\u2019\u201C\u201D\u2026\u203C\u203D\u2047\u2048\u2049\u3001\u3002\u301C\uFF01\uFF1F\uFF5E]+$/.test(e.replace(/[\s\u00A0\u202F]+/g, ""));}function _scaleStyleForPunctuationOnlyText(e, t) {if (!e) return e;var r = parseFloat(e.punctuationOnlyScale);if (!(r > 1) || !_isPunctuationOnlyText(t)) return e;var a = _clone(e);var n = a.textProps && a.textProps.layerText && a.textProps.layerText.textStyleRange;if (!n) return a;var i = [ "size", "impliedFontSize", "leading", "impliedLeading" ];for (var o = 0; o < n.length; o++) {var s = n[o] && n[o].textStyle;if (!s) continue;for (var c = 0; c < i.length; c++) {if (typeof s[i[c]] === "number") s[i[c]] *= r;}}return a;}function _punctuationOnlyBoxDimensions(e, t) {if (t.textSizeOverride > 0 || !t.style) return e;var r = parseFloat(t.style.punctuationOnlyScale);if (!(r > 1) || !_isPunctuationOnlyText(t.text)) return e;return {"width": e.width * r,"height": e.height * r};}function _resolveStyleSizeForDocument(t) {if (!t || t.autoSizeByPageWidth !== true || !documents.length) return t;var e = t.sizePresets;if (!e || e.length < 2) return t;var r;try {r = activeDocument.width && activeDocument.width.as ? activeDocument.width.as("px") : parseFloat(activeDocument.width);} catch (e) {return t;}if (isNaN(r) || r <= 0) return t;var a = parseInt(t.sizePresetDefaultIndex, 10);if (isNaN(a) || a < 0 || a >= e.length) a = 0;var n = parseFloat(e[a]);var i = -1;var o = t.sizePresetMinWidths || [];for (var s = 0; s < e.length; s++) {if (s === a) continue;var c = parseFloat(o[s]);var l = parseFloat(e[s]);if (!isNaN(c) && c > 0 && !isNaN(l) && l > 0 && r >= c && c > i) {i = c;n = l;}}if (isNaN(n) || n <= 0) return t;var u = t.textProps && t.textProps.layerText && t.textProps.layerText.textStyleRange;if (!u || !u[0] || !u[0].textStyle) return t;u[0].textStyle.size = n;if (u[0].textStyle.impliedFontSize != null) {u[0].textStyle.impliedFontSize = n;}return t;}function _changeToPointText() {try {if (app.activeDocument && app.activeDocument.activeLayer && app.activeDocument.activeLayer.textItem) {app.activeDocument.activeLayer.textItem.kind = TextType.POINTTEXT;return;}} catch (e) {}var e = new ActionReference();e.putProperty(charID.Property, charID.TextShapeType);e.putEnumerated(charID.TextLayer, charID.Ordinal, charID.Target);var t = new ActionDescriptor();t.putReference(charID.Null, e);t.putEnumerated(charID.To, charID.TextShapeType, charID.Point);executeAction(charID.Set, t, DialogModes.NO);}function _changeToBoxText() {var e = new ActionReference();e.putProperty(charID.Property, charID.TextShapeType);e.putEnumerated(charID.TextLayer, charID.Ordinal, charID.Target);var t = new ActionDescriptor();t.putReference(charID.Null, e);t.putEnumerated(charID.To, charID.TextShapeType, stringIDToTypeID("box"));executeAction(charID.Set, t, DialogModes.NO);}function _layerIsTextLayer() {var e = _getCurrent(charID.Layer, charID.Text);return e.hasKey(charID.Text);}function _getActiveLayerId() {var e = stringIDToTypeID("layerID");var t = new ActionReference();t.putProperty(charID.Property, e);t.putEnumerated(charID.Layer, charID.Ordinal, charID.Target);return executeActionGet(t).getInteger(e);}function _duplicateActiveLayer() {var e = new ActionReference();e.putEnumerated(charID.Layer, charID.Ordinal, charID.Target);var t = new ActionDescriptor();t.putReference(charID.Null, e);executeAction(stringIDToTypeID("duplicate"), t, DialogModes.NO);}function _deleteActiveLayer() {var e = new ActionReference();e.putEnumerated(charID.Layer, charID.Ordinal, charID.Target);var t = new ActionDescriptor();t.putReference(charID.Null, e);executeAction(charID.Delete, t, DialogModes.NO);}function _selectLayerById(e) {var t = new ActionReference();t.putIdentifier(charID.Layer, e);var r = new ActionDescriptor();r.putReference(charID.Null, t);executeAction(charID.Select, r, DialogModes.NO);}function _selectLayersById(e) {if (!e || !e.length) return;for (var t = 0; t < e.length; t++) {var r = new ActionReference();r.putIdentifier(charID.Layer, e[t]);var a = new ActionDescriptor();a.putReference(charID.Null, r);a.putBoolean(stringIDToTypeID("makeVisible"), false);if (t > 0) {a.putEnumerated(stringIDToTypeID("selectionModifier"), stringIDToTypeID("selectionModifierType"), stringIDToTypeID("addToSelection"));}executeAction(charID.Select, a, DialogModes.NO);}}function _textLayerIsPointText() {var e = _getCurrent(charID.Layer, charID.Text).getObjectValue(charID.Text);var t = e.getList(stringIDToTypeID("textShape")).getObjectValue(0).getEnumerationValue(charID.TextShapeType);return t === charID.Point;}function _resolveStylePointText(e, t) {return true;if (e && e.textType === "point") return true;if (e && e.textType === "paragraph") return false;return !!t;}function _getTextLayerSize() {try {var e = jamText.getLayerText();if (e && e.layerText && e.layerText.textStyleRange && e.layerText.textStyleRange[0] && e.layerText.textStyleRange[0].textStyle && e.layerText.textStyleRange[0].textStyle.size) {return e.layerText.textStyleRange[0].textStyle.size;}} catch (e) {}return _hostState.fallbackTextSize || 20;}function _convertPixelToPoint(e) {return parseInt(e) / activeDocument.resolution * 72;}function _convertPixelToPointExact(e) {return e / activeDocument.resolution * 72;}function _getMeasureBoxSpanPoints() {var e = 2e4;try {var t = app.preferences.rulerUnits;app.preferences.rulerUnits = Units.PIXELS;var r = 2 * Math.max(parseFloat(activeDocument.width), parseFloat(activeDocument.height));app.preferences.rulerUnits = t;if (r > 0 && r < e) e = r;} catch (e) {}return _convertPixelToPointExact(e);}function _createCurrent(e, t) {var r = new ActionReference();if (t > 0) r.putProperty(charID.Property, t);r.putEnumerated(e, charID.Ordinal, charID.Target);return r;}function _getCurrent(e, t) {return executeActionGet(_createCurrent(e, t));}function _getCurrentDocumentId() {var e = stringIDToTypeID("documentID");return _getCurrent(charID.Document, e).getInteger(e);}function _documentHasBackgroundLayer() {var e = new ActionReference();e.putProperty(charID.Property, charID.Background);e.putEnumerated(charID.Layer, charID.Ordinal, charID.Back);return executeActionGet(e).getBoolean(charID.Background);}function _getLayerByIndex(e) {var t = new ActionReference();t.putIndex(charID.Layer, e);return executeActionGet(t);}function _layerExistsById(e) {try {var t = new ActionReference();t.putIdentifier(charID.Layer, e);executeActionGet(t);return true;} catch (e) {return false;}}function _setLayerVisibilityByIds(e, t) {if (!e || !e.length) return 0;var r = new ActionList();var a = 0;for (var n = 0; n < e.length; n++) {if (t && !_layerExistsById(e[n])) continue;var i = new ActionReference();i.putIdentifier(charID.Layer, e[n]);r.putReference(i);a++;}if (!a) return 0;var o = new ActionDescriptor();o.putList(charID.Null, r);executeAction(t ? charID.Show : charID.Hide, o, DialogModes.NO);return a;}function _collectVisibleCleaningLayerIds() {var e = stringIDToTypeID("numberOfLayers");var t = stringIDToTypeID("layerSection");var r = stringIDToTypeID("layerSectionStart");var a = stringIDToTypeID("layerSectionEnd");var n = _getCurrent(charID.Document, e).getInteger(e);var i = _documentHasBackgroundLayer() ? 0 : 1;var o = [];var s = [];while (n > i) {var c = _getLayerByIndex(n);var l = c.getEnumerationValue(t);if (l === r) {o.push(c.getBoolean(charID.Visible));} else if (l === a) {o.pop();} else {var u = true;for (var p = 0; p < o.length; p++) {u = u && o[p];}if (u && !c.hasKey(charID.Text) && !c.getBoolean(charID.Background) && c.getBoolean(charID.Visible) && !c.hasKey(charID.AdjustmentLayer)) {s.push(c.getInteger(charID.LayerID));}}n--;}return s;}function toggleCleaningLayers() {if (!documents.length) return "doc";var e = String(_getCurrentDocumentId());var t = _hostState.hiddenCleaningLayerIdsByDocument;if (t.hasOwnProperty(e)) {var r = t[e];_setLayerVisibilityByIds(r, true);delete t[e];return "shown:" + r.length;}var a = _collectVisibleCleaningLayerIds();_setLayerVisibilityByIds(a, false);t[e] = a;return "hidden:" + a.length;}function _deselect() {var e = new ActionReference();e.putProperty(charID.Channel, charID.FrameSelect);var t = new ActionDescriptor();t.putReference(charID.Null, e);t.putEnumerated(charID.To, charID.Ordinal, charID.None);executeAction(charID.Set, t, DialogModes.NO);}function _getBoundsFromDescriptor(e) {var t = e.getInteger(charID.Top);var r = e.getInteger(charID.Left);var a = e.getInteger(charID.Right);var n = e.getInteger(charID.Bottom);return {"top": t,"left": r,"right": a,"bottom": n,"width": a - r,"height": n - t,"xMid": (r + a) / 2,"yMid": (t + n) / 2};}function _getCurrentSelectionBounds() {var e = _getCurrent(charID.Document, charID.FrameSelect);if (e.hasKey(charID.FrameSelect)) {var t = e.getObjectValue(charID.FrameSelect);return _getBoundsFromDescriptor(t);}}function _getCurrentTextLayerBounds() {var e = stringIDToTypeID("bounds");var t = _getCurrent(charID.Layer, e).getObjectValue(e);return _getBoundsFromDescriptor(t);}function _modifySelectionBounds(e) {if (e == 0) return;var t = new ActionDescriptor();t.putUnitDouble(charID.By, charID.PixelUnit, Math.abs(e));executeAction(e > 0 ? charID.Expand : charID.Contract, t, DialogModes.NO);}function _getAdjustedSelectionBounds(e, t) {if (!e || t === 0) return e;var r;try {r = app.activeDocument;} catch (e) {r = null;}if (!r || !r.selection) {return _getAdjustedSelectionBoundsFallback(e, t);}var a = _createTempSelectionChannel(r);if (!a) {return _getAdjustedSelectionBoundsFallback(e, t);}var n = null;try {_modifySelectionBounds(t);n = _getCurrentSelectionBounds();} catch (e) {n = null;} finally {try {r.selection.load(a);} catch (e) {}try {a.remove();} catch (e) {}}if (!n) {return _getAdjustedSelectionBoundsFallback(e, t);}return n;}function _createTempSelectionChannel(e) {var t = null;try {t = e.channels.getByName(_TEMP_SELECTION_CHANNEL);t.remove();} catch (e) {}try {t = e.channels.add();t.name = _TEMP_SELECTION_CHANNEL;e.selection.store(t);return t;} catch (e) {if (t) {try {t.remove();} catch (e) {}}return null;}}function _getAdjustedSelectionBoundsFallback(e, t) {if (!e || t === 0) return e;var r = Math.abs(t);if (t < 0) {if (e.width <= r * 2 || e.height <= r * 2) {return null;}var a = {"top": e.top + r,"left": e.left + r,"right": e.right - r,"bottom": e.bottom - r};a.width = a.right - a.left;a.height = a.bottom - a.top;a.xMid = (a.left + a.right) / 2;a.yMid = (a.top + a.bottom) / 2;return a;} else {var n = {"top": Math.max(e.top - r, 0),"left": Math.max(e.left - r, 0),"right": e.right + r,"bottom": e.bottom + r};n.width = n.right - n.left;n.height = n.bottom - n.top;n.xMid = (n.left + n.right) / 2;n.yMid = (n.top + n.bottom) / 2;return n;}}function _clampAdjustAmount(e, t) {if (!e || t >= 0) return t;var r = Math.floor(Math.min(e.width, e.height) / 2 - 1);if (r <= 0) return 0;return -Math.min(Math.abs(t), r);}function _getAdaptiveSelectionOpenRadius(e) {if (!e) return 0;var t = Math.min(e.width, e.height);var r = Math.floor(t / 2 - 1);if (r <= 0) return 0;var a = Math.max(_MIN_SELECTION_OPEN_RADIUS, Math.round(t * _SELECTION_OPEN_RATIO));return Math.min(a, r);}function _getAdaptiveOpenedSelectionBounds(e, t) {if (!e) return e;var r = _getAdaptiveSelectionOpenRadius(e);if (r <= 0) return e;var a;try {a = app.activeDocument;} catch (e) {a = null;}if (!a || !a.selection) {return e;}var n = _createTempSelectionChannel(a);if (!n) {return e;}var i = null;var o = r;try {while (o >= 1 && !i) {if (o !== r) {try {a.selection.load(n);} catch (e) {break;}}var s = null;_fillSelectionHoles(t, e);try {_modifySelectionBounds(-o);var c = _getCurrentSelectionBounds();if (c && c.width > 1 && c.height > 1) {_modifySelectionBounds(o);s = _getCurrentSelectionBounds();}} catch (e) {s = null;}if (s && s.width * s.height >= 200) {i = s;} else {o = Math.floor(o / 2);}}} finally {try {a.selection.load(n);} catch (e) {}try {n.remove();} catch (e) {}}return i || e;}function _fillSelectionHoles(e, t) {for (var r = 0; e && r < e.length; r++) {var a = _rectOverlap(e[r], t);if (!a) continue;try {_addRectToSelection(a);} catch (e) {}}}function _selectionBoundsKey(e) {if (!e) return "";return e.xMid + "_" + e.yMid + "_" + e.width + "_" + e.height;}function _calculateSelectionDimensions(e, t) {if (!e) return {"width": 0,"height": 0};var r = e.width * _DEFAULT_SELECTION_SCALE;if (t > 0) {r = Math.max(r - t * 2, _MIN_TEXTBOX_WIDTH);}return {"width": r,"height": e.height};}function _resizeTextBoxToContent(e, t) {var r = jamText.getLayerText();var a = r.layerText.textStyleRange[0].textStyle.size;_setTextBoxSize(e, t.height + a + 2);}function _positionLayerWithinSelection(e, t) {if (!e || !t) return;var r = e.xMid - t.xMid;var a = e.yMid - t.yMid;_moveLayer(r, a);}function _createMagicWandSelection(e) {try {var t = _getCurrentTextLayerBounds();var r = Math.max(t.left - 5, 0);var a = Math.max(t.yMid, 0);_checkWandPointOnCanvas(r, a);var n = new ActionDescriptor();var i = new ActionReference();i.putProperty(charID.Channel, charID.FrameSelect);n.putReference(charID.Null, i);var o = new ActionDescriptor();o.putUnitDouble(charID.Horizontal, charID.PixelUnit, r);o.putUnitDouble(charID.Vertical, charID.PixelUnit, a);n.putObject(charID.To, stringIDToTypeID("paint"), o);n.putInteger(stringIDToTypeID("tolerance"), e || 20);n.putBoolean(stringIDToTypeID("contiguous"), true);n.putBoolean(stringIDToTypeID("merged"), true);n.putBoolean(stringIDToTypeID("antiAlias"), true);executeAction(charID.Set, n, DialogModes.NO);} catch (e) {}}function _moveLayer(e, t) {var r = new ActionDescriptor();r.putUnitDouble(charID.Horizontal, charID.PixelUnit, e);r.putUnitDouble(charID.Vertical, charID.PixelUnit, t);var a = new ActionDescriptor();a.putReference(charID.Null, _createCurrent(charID.Layer));a.putObject(charID.To, charID.Offset, r);executeAction(charID.Move, a, DialogModes.NO);}var _AUTO_CENTER_MODES = {"single": true,"multi": true};var _BUBBLE_WAND_TOLERANCE = 20;var _MAX_BUBBLE_RATIO = 40;var _MIN_BUBBLE_AREA = 200;var _MIN_BUBBLE_TEXT_COVER = .5;var _MIN_DISPLAYED_TEXT_SIZE = 1;var _SAVED_SELECTION_CHANNEL = "__TyperSavedSelection__";function _rectFrom(e, t, r, a) {e = Number(e);t = Number(t);r = Number(r);a = Number(a);if (!isFinite(e) || !isFinite(t) || !isFinite(r) || !isFinite(a)) return null;if (r <= e || a <= t) return null;return {"top": t,"left": e,"right": r,"bottom": a,"width": r - e,"height": a - t,"xMid": (e + r) / 2,"yMid": (t + a) / 2};}function _unionRect(e) {if (!e || !e.length) return null;var t = e[0].left, r = e[0].top, a = e[0].right, n = e[0].bottom;for (var i = 1; i < e.length; i++) {if (e[i].left < t) t = e[i].left;if (e[i].top < r) r = e[i].top;if (e[i].right > a) a = e[i].right;if (e[i].bottom > n) n = e[i].bottom;}return _rectFrom(t, r, a, n);}function _sameRect(e, t) {return !!(e && t && e.left === t.left && e.top === t.top && e.right === t.right && e.bottom === t.bottom);}function _usableBubble(e, t) {if (!e) return null;var r = e.width * e.height;if (t && t.width && t.height && r > t.width * t.height * .45) return null;if (r < _MIN_BUBBLE_AREA) return null;return e;}function _rectOverlap(e, t) {if (!e || !t) return null;return _rectFrom(Math.max(e.left, t.left), Math.max(e.top, t.top), Math.min(e.right, t.right), Math.min(e.bottom, t.bottom));}function _containsPoint(e, t, r, a) {var n = a || 0;return t >= e.left - n && t <= e.right + n && r >= e.top - n && r <= e.bottom + n;}function _containsBox(e, t, r) {var a = r === undefined ? 2 : r;return t.left >= e.left - a && t.right <= e.right + a && t.top >= e.top - a && t.bottom <= e.bottom + a;}function _bubbleCandidateValid(e, t, r, a, n) {if (!_usableBubble(e, r) || !t) return false;if (!_containsPoint(e, t.xMid, t.yMid, 1)) return false;if (e.width * e.height < t.width * t.height * _MIN_BUBBLE_TEXT_COVER) return false;var i = 4 * (n > 0 ? n : 20);var o = (t.width + i) * (t.height + i);if (e.width * e.height > o * _MAX_BUBBLE_RATIO) return false;var s = a || [];for (var c = 0; c < s.length; c++) {if (_containsPoint(e, s[c].xMid, s[c].yMid)) return false;}return true;}function _probePoints(e, t) {return [ [ e.left - t, e.yMid ], [ e.right + t, e.yMid ], [ e.xMid, e.top - t ], [ e.xMid, e.bottom + t ], [ e.xMid, e.yMid ] ];}function _probeMargin(e) {var t = Number(e);if (!isFinite(t) || !t) t = 20;return Math.max(5, Math.min(40, Math.round(t * .25)));}function _pickBubble(e, t, r) {if (e && e.whole) return e;if (_containsBox(t, r)) {t.whole = true;return t;}return !e || t.width * t.height < e.width * e.height ? t : e;}function _copyProbe(e, t, r) {var a = _rectFrom(e.left, e.top, e.right, e.bottom);a.probeX = t;a.probeY = r;return a;}function _sortByKey(e, t) {for (var r = 1; r < e.length; r++) {var a = e[r];var n = r - 1;while (n >= 0 && e[n][t] > a[t]) {e[n + 1] = e[n];n--;}e[n + 1] = a;}return e;}function _separatedOrder(e, t, r) {var a = [];for (var n = 0; n < e.length; n++) {a.push({"box": e[n],"index": n,"sum": e[n][t] + e[n][r]});}_sortByKey(a, "sum");for (var i = 1; i < a.length; i++) {if (a[i].box[t] < a[i - 1].box[r]) return null;}return a;}function _cutLimits(e, t, r, a, n, i, o) {var s = [];for (var c = 0; c < t.length; c++) s.push([ e[a], e[n] ]);for (var l = 1; l < r.length; l++) {var u = (i(r[l - 1]) + o(r[l])) / 2;s[r[l - 1].index][1] = u;s[r[l].index][0] = u;}return s;}function _boxRight(e) {return e.box.right;}function _boxLeft(e) {return e.box.left;}function _boxBottom(e) {return e.box.bottom;}function _boxTop(e) {return e.box.top;}function _entryCentre(e) {return e.centre;}function _splitBubble(e, t) {var r = [];var a;var n = _separatedOrder(t, "left", "right");var i = _separatedOrder(t, "top", "bottom");if (!n && !i) {var o = t[0].xMid, s = t[0].xMid, c = t[0].yMid, l = t[0].yMid;for (a = 1; a < t.length; a++) {o = Math.min(o, t[a].xMid);s = Math.max(s, t[a].xMid);c = Math.min(c, t[a].yMid);l = Math.max(l, t[a].yMid);}var u = s - o >= l - c;var p = u ? "xMid" : "yMid";var y = [];for (a = 0; a < t.length; a++) y.push({"box": t[a],"index": a,"centre": t[a][p]});_sortByKey(y, "centre");var f = u ? _cutLimits(e, t, y, "left", "right", _entryCentre, _entryCentre) : _cutLimits(e, t, y, "top", "bottom", _entryCentre, _entryCentre);for (a = 0; a < t.length; a++) {r.push((u ? _rectFrom(f[a][0], e.top, f[a][1], e.bottom) : _rectFrom(e.left, f[a][0], e.right, f[a][1])) || e);}return r;}var h = n ? _cutLimits(e, t, n, "left", "right", _boxRight, _boxLeft) : null;var g = i ? _cutLimits(e, t, i, "top", "bottom", _boxBottom, _boxTop) : null;for (a = 0; a < t.length; a++) {var d = h ? h[a][0] : e.left;var v = h ? h[a][1] : e.right;var m = g ? g[a][0] : e.top;var T = g ? g[a][1] : e.bottom;r.push(_rectFrom(d, m, v, T) || e);}return r;}function _idInList(e, t) {for (var r = 0; r < t.length; r++) {if (t[r] === e) return true;}return false;}function _autoCenterEnabled(e) {return !!(e && _AUTO_CENTER_MODES[e.autoCenter] === true);}function _doubleBubbleEntriesValid(e) {if (!e || e.length < 2) return false;for (var t = 0; t < e.length; t++) {if (!e[t] || !e[t].text) return false;}return true;}function _transformScale(e) {var t = e && e.transform;if (!t) return 1;var r = Number(t.xx) || 0, a = Number(t.xy) || 0, n = Number(t.yx) || 0, i = Number(t.yy) || 0;var o = Math.sqrt(r * r + a * a);var s = Math.sqrt(n * n + i * i);var c = s || o;return isFinite(c) && c > 0 ? c : 1;}function _typeValueToPixels(e, t, r) {if (t === "pixelsUnit") return e;if (t === "millimetersUnit") return e * r / 25.4;return e * r / 72;}function _typeValueToPoints(e, t, r) {if (t === "pixelsUnit") return e * 72 / (r || 72);if (t === "millimetersUnit") return e * 72 / 25.4;return e;}function _pointsToTypeUnit(e, t, r) {if (t === "pixelsUnit") return e * (r || 72) / 72;if (t === "millimetersUnit") return e * 25.4 / 72;return e;}function _displayedTextSize(e, t) {var r = {"value": NaN,"unit": "pointsUnit","pixels": NaN};var a = e && e.layerText;var n = a && a.textStyleRange && a.textStyleRange[0];var i = n && n.textStyle;if (!i) return r;r.unit = e.typeUnit || "pointsUnit";var o = Number(i.size);var s = Number(i.impliedFontSize);var c = NaN;if (isFinite(s) && s > 0) {c = s;} else if (isFinite(o)) {c = o * _transformScale(a);}if (!isFinite(c) || c <= 0) return r;r.value = c;r.pixels = _typeValueToPixels(c, r.unit, t || 72);return r;}function _displayedStyleValue(e, t, r, a) {var n = e[r];if (n !== undefined && n !== null && isFinite(Number(n))) return Number(n);return Number(e[t]) * a;}function _scaleTextShape(e, t) {if (!e || e.textType !== "box" || !e.bounds) return null;var r = _clone(e);var a = [ "top", "left", "right", "bottom" ];for (var n = 0; n < a.length; n++) {var i = Number(r.bounds[a[n]]);if (isFinite(i)) r.bounds[a[n]] = i * t;}return r;}function _textResizePlan(e, t, r) {var a = e && e.layerText;var n = a && a.textStyleRange;if (!n || !n.length) return null;var i = [];for (var o = 0; o < n.length; o++) {if (n[o] && n[o].textStyle && Number(n[o].textStyle.size) > 0) i.push(n[o].textStyle);}if (!i.length) return null;var s = i[0];var c = Number(s.size);var l = _displayedTextSize(e, r).value;if (!(c > 0) || !(l > 0) || !isFinite(t)) return null;var u = Math.max(_MIN_DISPLAYED_TEXT_SIZE, l + t);var p = true;var y = !s.autoLeading && s.leading !== undefined && s.leading !== null;for (var f = 0; f < i.length; f++) {if (Number(i[f].size) !== c) p = false;if (i[f].autoLeading || i[f].leading === undefined || Number(i[f].leading) !== Number(s.leading)) y = false;}var h = a.textShape && a.textShape[0];var g = u / l;return {"ratio": g,"nextShown": u,"base": c,"unit": e.typeUnit || "pointsUnit","uniform": p,"scaleLeading": y,"nextLeading": y ? _displayedStyleValue(s, "leading", "impliedLeading", _transformScale(a)) * g : NaN,"frame": h && h.textType === "box" && h.bounds ? _clone(h) : null};}function _appliedSizeRatio(e, t, r) {if (e && t && e.unit === t.unit && e.value > 0 && t.value > 0) {return t.value / e.value;}return r;}var _KNOWN_TYPE_UNITS = {"pointsUnit": true,"pixelsUnit": true,"millimetersUnit": true};function _keepLiveTextSize(e, t, r) {var a = t && t.layerText && t.layerText.textStyleRange && t.layerText.textStyleRange[0];var n = a && a.textStyle;var i = e && e.layerText && e.layerText.textStyleRange;if (!n || !i) return e;var o = t.typeUnit;var s = e.typeUnit;var c = false;if (!s && o) {e.typeUnit = o;} else if (o && s && o !== s) {if (!_KNOWN_TYPE_UNITS[o] || !_KNOWN_TYPE_UNITS[s]) return e;c = true;}var l = [ "size", "leading", "autoLeading" ];for (var u = 0; u < i.length; u++) {var p = i[u] && i[u].textStyle;if (!p) continue;for (var y = 0; y < l.length; y++) {var f = n[l[y]];if (f === undefined) continue;if (c && l[y] !== "autoLeading") {f = _pointsToTypeUnit(_typeValueToPoints(Number(f), o, r), s, r);}p[l[y]] = _clone(f);}if (n.autoLeading === true) delete p.leading;delete p.impliedFontSize;delete p.impliedLeading;}return e;}function _getDocumentPixelSize() {var e = {"width": 0,"height": 0};try {var t = app.activeDocument;e.width = t.width && t.width.as ? t.width.as("px") : parseFloat(t.width);e.height = t.height && t.height.as ? t.height.as("px") : parseFloat(t.height);} catch (e) {}if (!isFinite(e.width)) e.width = 0;if (!isFinite(e.height)) e.height = 0;return e;}function _getDocumentResolution() {try {var e = Number(app.activeDocument.resolution);if (e > 0) return e;} catch (e) {}return 72;}function _checkWandPointOnCanvas(e, t) {var r = _getDocumentPixelSize();if (r.width > 0 && e >= r.width) throw new Error("wand point off canvas");if (r.height > 0 && t >= r.height) throw new Error("wand point off canvas");}function _magicWandAt(e, t, r) {var a = Math.max(e, 0);var n = Math.max(t, 0);_checkWandPointOnCanvas(a, n);var i = new ActionDescriptor();var o = new ActionReference();o.putProperty(charID.Channel, charID.FrameSelect);i.putReference(charID.Null, o);var s = new ActionDescriptor();s.putUnitDouble(charID.Horizontal, charID.PixelUnit, a);s.putUnitDouble(charID.Vertical, charID.PixelUnit, n);i.putObject(charID.To, stringIDToTypeID("paint"), s);i.putInteger(stringIDToTypeID("tolerance"), r || _BUBBLE_WAND_TOLERANCE);i.putBoolean(stringIDToTypeID("contiguous"), true);i.putBoolean(stringIDToTypeID("merged"), true);i.putBoolean(stringIDToTypeID("antiAlias"), true);executeAction(charID.Set, i, DialogModes.NO);}function _liveSelectionBounds() {try {var e = _getCurrentSelectionBounds();return e ? _rectFrom(e.left, e.top, e.right, e.bottom) : null;} catch (e) {return null;}}function _intersectSelectionWithRect(e) {var t = new ActionDescriptor();var r = new ActionReference();r.putProperty(charID.Channel, charID.FrameSelect);t.putReference(charID.Null, r);var a = new ActionDescriptor();a.putUnitDouble(charID.Top, charID.PixelUnit, e.top);a.putUnitDouble(charID.Left, charID.PixelUnit, e.left);a.putUnitDouble(charID.Bottom, charID.PixelUnit, e.bottom);a.putUnitDouble(charID.Right, charID.PixelUnit, e.right);t.putObject(charID.To, stringIDToTypeID("rectangle"), a);executeAction(stringIDToTypeID("intersectWith"), t, DialogModes.NO);}function _addRectToSelection(e) {var t = new ActionDescriptor();var r = new ActionReference();r.putProperty(charID.Channel, charID.FrameSelect);t.putReference(charID.Null, r);var a = new ActionDescriptor();a.putUnitDouble(charID.Top, charID.PixelUnit, e.top);a.putUnitDouble(charID.Left, charID.PixelUnit, e.left);a.putUnitDouble(charID.Bottom, charID.PixelUnit, e.bottom);a.putUnitDouble(charID.Right, charID.PixelUnit, e.right);t.putObject(charID.To, stringIDToTypeID("rectangle"), a);executeAction(stringIDToTypeID("addTo"), t, DialogModes.NO);}function _channelExists(e) {try {var t = new ActionReference();t.putName(charID.Channel, e);executeActionGet(t);return true;} catch (e) {return false;}}function _deleteChannelByName(e) {if (!_channelExists(e)) return;try {var t = new ActionReference();t.putName(charID.Channel, e);var r = new ActionDescriptor();r.putReference(charID.Null, t);executeAction(charID.Delete, r, DialogModes.NO);} catch (e) {}}function _storeSelectionChannel(e) {_deleteChannelByName(e);var t = new ActionReference();t.putProperty(charID.Channel, charID.FrameSelect);var r = new ActionDescriptor();r.putReference(charID.Null, t);r.putString(stringIDToTypeID("name"), e);executeAction(stringIDToTypeID("duplicate"), r, DialogModes.NO);}function _loadSelectionChannel(e) {var t = new ActionReference();t.putProperty(charID.Channel, charID.FrameSelect);var r = new ActionReference();r.putName(charID.Channel, e);var a = new ActionDescriptor();a.putReference(charID.Null, t);a.putReference(charID.To, r);executeAction(charID.Set, a, DialogModes.NO);}function _saveSelectionState() {var t = {"had": false,"stored": false};try {t.had = !!_getCurrentSelectionBounds();} catch (e) {t.had = false;}if (t.had) {try {_storeSelectionChannel(_SAVED_SELECTION_CHANNEL);t.stored = true;} catch (e) {_deleteChannelByName(_SAVED_SELECTION_CHANNEL);}}return t;}function _restoreSelectionState(e, t) {var r = false;if (e && e.stored) {if (!t) {try {_loadSelectionChannel(_SAVED_SELECTION_CHANNEL);r = true;} catch (e) {}}_deleteChannelByName(_SAVED_SELECTION_CHANNEL);}if (!r) {try {_deselect();} catch (e) {}}}function _layerBoxFromDescriptor(e) {var t = [ "boundsNoEffects", "bounds" ];for (var r = 0; r < t.length; r++) {var a = stringIDToTypeID(t[r]);if (e && e.hasKey && e.hasKey(a)) {var n = _getBoundsFromDescriptor(e.getObjectValue(a));return _rectFrom(n.left, n.top, n.right, n.bottom);}}return null;}function _currentLayerBox() {var e = stringIDToTypeID("boundsNoEffects");try {var t = _getCurrent(charID.Layer, e);if (t.hasKey(e)) return _layerBoxFromDescriptor(t);} catch (e) {}var r = _getCurrentTextLayerBounds();return r ? _rectFrom(r.left, r.top, r.right, r.bottom) : null;}function _currentDisplayedTextPixels() {try {return _displayedTextSize(jamText.getLayerText(), _getDocumentResolution()).pixels;} catch (e) {return NaN;}}function _safeActiveLayerId() {try {return _getActiveLayerId();} catch (e) {return null;}}function _probeBubble(e, t, r, a) {var n = {"best": null,"loose": null};if (!e) return n;var i = r || [];var o = _probePoints(e, _probeMargin(isFinite(t) ? t : 20));for (var s = 0; s < o.length; s++) {try {_magicWandAt(o[s][0], o[s][1], _BUBBLE_WAND_TOLERANCE);var c = _liveSelectionBounds();if (!c || !_bubbleCandidateValid(c, e, a, [], t)) continue;n.loose = _pickBubble(n.loose, _copyProbe(c, o[s][0], o[s][1]), e);var l = false;for (var u = 0; u < i.length; u++) {if (_containsPoint(c, i[u].xMid, i[u].yMid)) {l = true;break;}}if (l) continue;n.best = _pickBubble(n.best, _copyProbe(c, o[s][0], o[s][1]), e);if (n.best.whole) break;} catch (e) {}}if (n.best && !_sameRect(n.best, _liveSelectionBounds())) {try {_magicWandAt(n.best.probeX, n.best.probeY, _BUBBLE_WAND_TOLERANCE);} catch (e) {}}return n;}function _openedBubble(e, t, r) {var a = null;try {a = _getAdaptiveOpenedSelectionBounds(e, r || (t ? [ t ] : null));} catch (e) {a = null;}if (!a || a.error) return e;var n = _rectFrom(a.left, a.top, a.right, a.bottom);if (!n || n.width * n.height < _MIN_BUBBLE_AREA) return e;if (!_containsBox(e, n, 2)) return e;if (t && !_containsPoint(n, t.xMid, t.yMid, 1)) return e;return n;}function _wandCoversBox(e, t) {try {_magicWandAt(e.probeX, e.probeY, _BUBBLE_WAND_TOLERANCE);_intersectSelectionWithRect(t);var r = _liveSelectionBounds();return !!(r && r.width >= t.width * .5 && r.height >= t.height * .5);} catch (e) {return false;}}function _tightLobe(e, t, r, a) {if (!t || !e) return null;try {_magicWandAt(e.probeX, e.probeY, _BUBBLE_WAND_TOLERANCE);_intersectSelectionWithRect(t);var n = _liveSelectionBounds();if (n && _usableBubble(n, a) && _containsPoint(n, r.xMid, r.yMid, 1)) return n;} catch (e) {}return null;}function _layerLockedByDescriptor(e) {try {var t = stringIDToTypeID("layerLocking");if (!e.hasKey(t)) return false;var r = e.getObjectValue(t);var a = [ "protectAll", "protectPosition" ];for (var n = 0; n < a.length; n++) {var i = stringIDToTypeID(a[n]);if (r.hasKey(i) && r.getBoolean(i)) return true;}} catch (e) {}return false;}function _textNeighbours(e) {var t = [];try {var r = stringIDToTypeID("numberOfLayers");var a = stringIDToTypeID("layerSection");var n = stringIDToTypeID("layerSectionStart");var i = stringIDToTypeID("layerSectionEnd");var o = _getCurrent(charID.Document, r).getInteger(r);var s = [];for (;o >= 1; o--) {try {var c = _getLayerByIndex(o);var l = c.getEnumerationValue(a);if (l === n) {s.push({"visible": c.getBoolean(charID.Visible),"locked": _layerLockedByDescriptor(c)});continue;}if (l === i) {s.pop();continue;}var u = c.getBoolean(charID.Visible);var p = _layerLockedByDescriptor(c);for (var y = 0; y < s.length; y++) {u = u && s[y].visible;p = p || s[y].locked;}if (!u || !c.hasKey(charID.Text)) continue;var f = c.getInteger(charID.LayerID);if (_idInList(f, e)) continue;var h = _layerBoxFromDescriptor(c);if (h) t.push({"id": f,"box": h,"neighbour": true,"locked": p,"rect": null});} catch (e) {}}} catch (e) {}return t;}function _withoutLettering(e) {var t = [];var r = _textNeighbours([]);for (var a = 0; a < r.length; a++) t.push(r[a].id);try {_setLayerVisibilityByIds(t, false);} catch (e) {}try {return e();} finally {try {_setLayerVisibilityByIds(t, true);} catch (e) {}}}function _placeLayerInRect(e, t, r) {if (t && !_textLayerIsPointText()) {var a = _calculateSelectionDimensions(e, r).width;_setTextBoxSize(a, e.height * 3);var n = _currentLayerBox();if (n) {var i = _currentDisplayedTextPixels();if (!(i > 0)) i = 20;_setTextBoxSize(a, n.height + i + 2);}}var o = _currentLayerBox();if (!o) return false;var s = e.xMid - o.xMid;var c = e.yMid - o.yMid;if (s || c) _moveLayer(s, c);return true;}function _autoCenterLayers(e, t) {var r = t.autoCenter;var a = !!t.resizeTextBox;var n = t.padding || 0;var i = _getDocumentPixelSize();var o = [];var s, c;for (s = 0; s < e.length; s++) {try {_selectLayerById(e[s]);var l = _currentLayerBox();if (l) o.push({"id": e[s],"box": l,"sizePixels": _currentDisplayedTextPixels(),"rect": null,"merged": null});} catch (e) {}}if (!o.length) return;var u = _textNeighbours(e);for (s = 0; s < o.length; s++) {var p = [];for (c = 0; c < o.length; c++) if (c !== s) p.push(o[c].box);for (c = 0; c < u.length; c++) p.push(u[c].box);try {var y = _probeBubble(o[s].box, o[s].sizePixels, p, i);if (y.best) o[s].rect = _openedBubble(y.best, o[s].box); else o[s].merged = y.loose;} catch (e) {}}var f = [];if (r === "multi") {for (s = 0; s < o.length; s++) {var h = o[s];if (h.rect || !h.merged) continue;var g = h.merged;var d = [];for (c = 0; c < o.length; c++) if (c !== s && !o[c].rect) d.push(o[c]);for (c = 0; c < u.length; c++) if (!u[c].rect) d.push(u[c]);var v = [ h ];for (c = 0; c < d.length; c++) {var m = d[c];if (_containsPoint(g, m.box.xMid, m.box.yMid, 1) && _wandCoversBox(g, m.box)) v.push(m);}try {_magicWandAt(g.probeX, g.probeY, _BUBBLE_WAND_TOLERANCE);} catch (e) {continue;}var T = [];for (c = 0; c < v.length; c++) T.push(v[c].box);var I = _openedBubble(g, h.box, T);if (v.length === 1) {h.rect = I;continue;}var D = _splitBubble(I, T);for (c = 0; c < v.length; c++) {v[c].rect = _tightLobe(g, D[c], v[c].box, i) || D[c];if (v[c].neighbour && !v[c].locked) f.push(v[c]);}}}try {_deselect();} catch (e) {}var b = o.concat(f);for (s = 0; s < b.length; s++) {if (!b[s].rect) continue;try {_selectLayerById(b[s].id);if (b[s].neighbour) _placeLayerInRect(b[s].rect, false, 0); else _placeLayerInRect(b[s].rect, a, n);} catch (e) {}}}function _autoCenterCreated(e, t) {if (!_autoCenterEnabled(t)) return;var r = [];for (var a = 0; a < (e || []).length; a++) {if (e[a] !== null && e[a] !== undefined) r.push(e[a]);}if (!r.length) return;var n = _safeActiveLayerId();var i = _saveSelectionState();try {_autoCenterLayers(r, t);} catch (e) {}_restoreSelectionState(i, false);try {_selectLayerById(n !== null ? n : r[r.length - 1]);} catch (e) {}}function _targetLayerEntries() {var e = [];var t = stringIDToTypeID("targetLayers");var r = stringIDToTypeID("layerID");var a = [];var n = new ActionReference();n.putProperty(charID.Property, t);n.putEnumerated(charID.Document, charID.Ordinal, charID.Target);var i = executeActionGet(n);if (i.hasKey(t)) {var o = i.getList(t);var s = _documentHasBackgroundLayer() ? 0 : 1;for (var c = 0; c < o.count; c++) a.push(o.getReference(c).getIndex() + s);} else {a.push(-1);}for (var l = 0; l < a.length; l++) {var u = new ActionReference();u.putProperty(charID.Property, charID.Text);var p = new ActionReference();p.putProperty(charID.Property, r);if (a[l] === -1) {u.putEnumerated(charID.Layer, charID.Ordinal, charID.Target);p.putEnumerated(charID.Layer, charID.Ordinal, charID.Target);} else {u.putIndex(charID.Layer, a[l]);p.putIndex(charID.Layer, a[l]);}var y = false;try {y = executeActionGet(u).hasKey(charID.Text);} catch (e) {y = false;}e.push({"id": executeActionGet(p).getInteger(r),"text": y});}return e;}function _splitDoubleBubble(e, t, r) {var a = {"result": "","consumed": false};var n = _getDocumentPixelSize();var i = _usableBubble(_liveSelectionBounds(), n);var o = [];var s, c;for (s = 0; s < e.length; s++) {_selectLayerById(e[s].id);var l = _currentLayerBox();if (!l) {a.result = "doubleBubbleEmpty";return a;}o.push({"id": e[s].id,"box": l,"sizePixels": _currentDisplayedTextPixels(),"rect": null});}var u = [];for (s = 0; s < o.length; s++) u.push(o[s].box);var p = null;var y = !!i;for (s = 0; y && s < o.length; s++) {y = _containsPoint(i, o[s].box.xMid, o[s].box.yMid, 1);}if (y) {p = {"rect": _openedBubble(i, null, u),"probe": null};a.consumed = true;} else {var f = false;for (s = 0; s < o.length; s++) {var h = [];for (c = 0; c < o.length; c++) if (c !== s) h.push(o[c].box);var g = _probeBubble(o[s].box, o[s].sizePixels, h, n).best;if (g) o[s].rect = _openedBubble(g, o[s].box); else f = true;}if (f) {var d = _probeBubble(_unionRect(u), o[0].sizePixels, [], n).best;for (s = 0; d && s < o.length; s++) {if (!_containsPoint(d, o[s].box.xMid, o[s].box.yMid, 1)) d = null;}if (!d) {a.result = "doubleBubbleNotFound";return a;}p = {"rect": _openedBubble(d, null, u),"probe": d};}}if (p) {var v = _splitBubble(p.rect, u);for (s = 0; s < o.length; s++) {o[s].rect = p.probe && _tightLobe(p.probe, v[s], o[s].box, n) || v[s];}}try {_deselect();} catch (e) {}var m = [];for (s = 0; s < o.length; s++) {_selectLayerById(o[s].id);if (!_placeLayerInRect(o[s].rect, t, r)) {a.result = "doubleBubbleEmpty";return a;}m.push(o[s].id);}_selectLayersById(m);return a;}function _alignTextLayersToDoubleBubble() {var e = _hostState.alignTextLayersToDoubleBubble;var t = _saveSelectionState();var r = {"result": "","consumed": false};try {r = _splitDoubleBubble(e.entries || [], e.resize, e.padding);} catch (e) {r.result = "scriptError: " + (e && e.message ? e.message : e);}_restoreSelectionState(t, r.consumed && !r.result);e.result = r.result;}function _getLayerStroke(e) {try {var t = new ActionReference();t.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("Lefx"));if (typeof e === "number") {t.putIndex(charIDToTypeID("Lyr "), e);} else {t.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));}var r = executeActionGet(t);if (!r.hasKey(charIDToTypeID("Lefx"))) return null;var a = r.getObjectValue(charIDToTypeID("Lefx"));var n = null;if (a.hasKey(charIDToTypeID("FrFX"))) {try {n = a.getObjectValue(charIDToTypeID("FrFX"));} catch (e) {n = null;}}if (!n) {var i = stringIDToTypeID("frameFXMulti");if (a.hasKey(i)) {var o = a.getList(i);if (o.count > 0) n = o.getObjectValue(0);}}if (!n) return null;var s = {"r": 0,"g": 0,"b": 0};try {var c = n.getObjectValue(charIDToTypeID("Clr "));if (c.hasKey(charIDToTypeID("Rd  "))) {s = {"r": c.getDouble(charIDToTypeID("Rd  ")),"g": c.getDouble(charIDToTypeID("Grn ")),"b": c.getDouble(charIDToTypeID("Bl  "))};} else if (c.hasKey(charIDToTypeID("Gry "))) {var l = Math.round(255 * (1 - c.getDouble(charIDToTypeID("Gry ")) / 100));s = {"r": l,"g": l,"b": l};}} catch (e) {}var u = true;try {u = n.getBoolean(charIDToTypeID("enab"));} catch (e) {}var p = "other";try {p = n.getEnumerationValue(charIDToTypeID("Styl")) == charIDToTypeID("OutF") ? "outer" : "other";} catch (e) {}var y = 0;try {y = n.getUnitDoubleValue(charIDToTypeID("Sz  "));} catch (e) {}var f = 100;try {f = n.getUnitDoubleValue(charIDToTypeID("Opct"));} catch (e) {}return {"enabled": u,"position": p,"size": y,"opacity": f,"color": s};} catch (e) {return null;}}function _setLayerStroke(e) {if (!e || e.enabled === false || e.size <= 0 && e.enabled !== true) return;var t = new ActionDescriptor();var r = new ActionReference();r.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("Lefx"));r.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));t.putReference(charIDToTypeID("null"), r);var a = new ActionDescriptor();a.putUnitDouble(charIDToTypeID("Scl "), charIDToTypeID("#Prc"), 100);var n = new ActionDescriptor();n.putBoolean(charIDToTypeID("enab"), true);n.putBoolean(stringIDToTypeID("present"), true);n.putBoolean(stringIDToTypeID("showInDialog"), true);n.putEnumerated(charIDToTypeID("Styl"), charIDToTypeID("FStl"), charIDToTypeID("OutF"));n.putEnumerated(charIDToTypeID("PntT"), charIDToTypeID("FrFl"), charIDToTypeID("SClr"));n.putEnumerated(charIDToTypeID("Md  "), charIDToTypeID("BlnM"), charIDToTypeID("Nrml"));n.putUnitDouble(charIDToTypeID("Sz  "), charIDToTypeID("#Pxl"), e.size || 3);n.putUnitDouble(charIDToTypeID("Opct"), charIDToTypeID("#Prc"), e.opacity || 100);var i = new ActionDescriptor();i.putDouble(charIDToTypeID("Rd  "), e.color.r);i.putDouble(charIDToTypeID("Grn "), e.color.g);i.putDouble(charIDToTypeID("Bl  "), e.color.b);n.putObject(charIDToTypeID("Clr "), charIDToTypeID("RGBC"), i);a.putObject(charIDToTypeID("FrFX"), charIDToTypeID("FrFX"), n);t.putObject(charIDToTypeID("T   "), charIDToTypeID("Lefx"), a);executeAction(charIDToTypeID("setd"), t, DialogModes.NO);}function _setDiacXOffset(e) {var t = new ActionDescriptor();var r = new ActionReference();r.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("TxtS"));r.putEnumerated(charIDToTypeID("TxLr"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));t.putReference(charIDToTypeID("null"), r);var a = new ActionDescriptor();a.putInteger(stringIDToTypeID("textOverrideFeatureName"), 808466486);a.putInteger(stringIDToTypeID("typeStyleOperationType"), 3);a.putUnitDouble(stringIDToTypeID("diacXOffset"), charIDToTypeID("#Pxl"), e);t.putObject(charIDToTypeID("T   "), charIDToTypeID("TxtS"), a);executeAction(charIDToTypeID("setd"), t, DialogModes.NO);}function _setMarkYOffset(e) {var t = new ActionDescriptor();var r = new ActionReference();r.putProperty(charIDToTypeID("Prpr"), charIDToTypeID("TxtS"));r.putEnumerated(charIDToTypeID("TxLr"), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));t.putReference(charIDToTypeID("null"), r);var a = new ActionDescriptor();a.putInteger(stringIDToTypeID("textOverrideFeatureName"), 808466488);a.putInteger(stringIDToTypeID("typeStyleOperationType"), 3);a.putUnitDouble(stringIDToTypeID("markYDistFromBaseline"), charIDToTypeID("#Pxl"), e);t.putObject(charIDToTypeID("T   "), charIDToTypeID("TxtS"), a);executeAction(charIDToTypeID("setd"), t, DialogModes.NO);}function _applyMiddleEast(e) {if (!e) return;if (e.diacXOffset != null) _setDiacXOffset(e.diacXOffset);if (e.markYDistFromBaseline != null) _setMarkYOffset(e.markYDistFromBaseline);}function _restoreMiddleEastOffsets(e) {if (!e) return;var t = e.diacXOffset != null && e.diacXOffset !== 0;var r = e.markYDistFromBaseline != null && e.markYDistFromBaseline !== 100;if (t || r) _applyMiddleEast(e);}function _setParagraphDirection(e, t) {e.directionType = t === "rtl" ? "dirRightToLeft" : "dirLeftToRight";if (t === "rtl") e.textComposerEngine = "textOptycaComposer";}function _bakeDirection(e, t) {for (var r = 0; r < e.length; r++) {var a = e[r] || {};var n = a.paragraphStyle || {};_setParagraphDirection(n, t);a.paragraphStyle = n;e[r] = a;}}function _stripDirection(e) {for (var t = 0; t < e.length; t++) {var r = e[t].paragraphStyle || {};delete r.directionType;delete r.textComposerEngine;}}function _applyTextDirection(e) {if (!e) return;try {var t = new ActionDescriptor();t.putEnumerated(stringIDToTypeID("directionType"), stringIDToTypeID("directionType"), stringIDToTypeID(e === "rtl" ? "dirRightToLeft" : "dirLeftToRight"));if (e === "rtl") {t.putEnumerated(stringIDToTypeID("textComposerEngine"), stringIDToTypeID("textComposerEngine"), stringIDToTypeID("textOptycaComposer"));}var r = new ActionReference();r.putProperty(charID.Property, stringIDToTypeID("paragraphStyle"));r.putEnumerated(charID.TextLayer, charID.Ordinal, charID.Target);var a = new ActionDescriptor();a.putReference(charID.Null, r);a.putObject(charID.To, stringIDToTypeID("paragraphStyle"), t);executeAction(charID.Set, a, DialogModes.NO);} catch (e) {}}function _buildRichTextRanges(e, t, r) {if (!e || !e.textStyle || !t || !t.length) return null;var a = [];var n = 0;for (var i = 0; i < t.length; i++) {var o = t[i] || {};var s = o.text || "";var c = s.length;if (!c) continue;var l = _clone(e.textStyle);resolveTypeRFontVariant(l, o, app.fonts);a.push({"from": n,"to": n + c,"textStyle": l});n += c;}if (n < r) {a.push({"from": n,"to": r,"textStyle": _clone(e.textStyle)});}return a.length ? a : null;}function _applyRichTextRanges(e, t, r) {if (!e || !e.layerText || !t || !t.length) return false;var a = e.layerText.textStyleRange && e.layerText.textStyleRange[0];var n = _buildRichTextRanges(a, t, r);if (!n) return false;e.layerText.textStyleRange = n;return true;}function _topSlotOfStack(e, t, r) {var a = 0;for (var n = e + 1; n <= t; n++) {var i = r(n);if (i === "layerSectionEnd") {a++;} else if (i === "layerSectionStart") {if (!a) return n - 1;a--;}}return t;}function _layerSectionAt(e) {var t = stringIDToTypeID("layerSection");var r = new ActionReference();r.putProperty(charID.Property, t);r.putIndex(charID.Layer, e);return typeIDToStringID(executeActionGet(r).getEnumerationValue(t));}function _raiseNewTextLayer() {try {var e = stringIDToTypeID("itemIndex");var t = stringIDToTypeID("numberOfLayers");var r = _documentHasBackgroundLayer() ? 1 : 0;var a = _getCurrent(charID.Layer, e).getInteger(e) - r;var n = _getCurrent(charID.Document, t).getInteger(t);var i = _topSlotOfStack(a, n, _layerSectionAt);var o = new ActionReference();o.putEnumerated(charID.Layer, charID.Ordinal, charID.Target);if (i !== a) {var s = new ActionReference();s.putIndex(charID.Layer, i + r);var c = new ActionDescriptor();c.putReference(charID.Null, o);c.putReference(charID.To, s);c.putBoolean(charIDToTypeID("Adjs"), false);c.putInteger(charIDToTypeID("Vrsn"), 5);executeAction(charID.Move, c, DialogModes.NO);}var l = stringIDToTypeID("group");if (_getCurrent(charID.Layer, l).getBoolean(l)) {var u = new ActionDescriptor();u.putReference(charID.Null, o);executeAction(charIDToTypeID("Ungr"), u, DialogModes.NO);}} catch (e) {}}function _createAndSetLayerText(e, t, r) {var a = _scaleStyleForPunctuationOnlyText(_resolveStyleSizeForDocument(_ensureStyle(e.style)), e.text);if (e.textSizeOverride > 0) {_overrideStyleTextSize(a, e.textSizeOverride);}a.textProps.layerText.textKey = _normalizeTextKey(e.text);a.textProps.layerText.textStyleRange[0].to = e.text.length;a.textProps.layerText.paragraphStyleRange[0].to = e.text.length;_applyRichTextRanges(a.textProps, e.richTextRuns, e.text.length);var n = a.textProps.layerText.textStyleRange[0].textStyle.size;if (typeof n !== "number") {try {var i = jamText.getLayerText();_hostState.fallbackTextSize = i.layerText.textStyleRange[0].textStyle.size;} catch (e) {}a.textProps.layerText.textStyleRange[0].textStyle.size = _hostState.fallbackTextSize;}a.textProps.layerText.textShape = [ {"textType": "box","orientation": "horizontal","bounds": {"top": 0,"left": 0,"right": _convertPixelToPoint(t),"bottom": _convertPixelToPoint(r)}} ];var o = false;if (e.direction && a.textProps.layerText.paragraphStyleRange) {_bakeDirection(a.textProps.layerText.paragraphStyleRange, e.direction);o = true;}try {jamEngine.jsonPlay("make", {"target": [ "<reference>", [ [ "textLayer", [ "<class>", null ] ] ] ],"using": jamText.toLayerTextObject(a.textProps)});} catch (e) {if (!o) throw e;_stripDirection(a.textProps.layerText.paragraphStyleRange);jamEngine.jsonPlay("make", {"target": [ "<reference>", [ [ "textLayer", [ "<class>", null ] ] ] ],"using": jamText.toLayerTextObject(a.textProps)});o = false;}_raiseNewTextLayer();_applyMiddleEast(a.textProps.layerText.textStyleRange[0].textStyle);if (a.stroke) {_setLayerStroke(a.stroke);}if (e.direction && !o) {_applyTextDirection(e.direction);}}function _setTextBoxSize(e, t) {var r = [ {"textType": "box","orientation": "horizontal","bounds": {"top": 0,"left": 0,"right": _convertPixelToPoint(e),"bottom": _convertPixelToPoint(t)}} ];jamText.setLayerText({"layerText": {"textShape": r}});}function _checkSelection(e) {var t = _getCurrentSelectionBounds();if (t === undefined) {return {"error": "noSelection"};}var r = 0;var a = false;if (e && e.adjustAmount !== undefined) {r = e.adjustAmount;}if (e && e.adaptiveOpen) {a = true;}var n = t;if (a) {n = _getAdaptiveOpenedSelectionBounds(t, e.holes);} else if (r !== 0) {n = _getAdjustedSelectionBounds(t, r);}if (!n || n.width * n.height < 200) {return {"error": "smallSelection"};}return n;}function _forEachSelectedLayer(e) {var t = [];var r = new ActionReference();var a = stringIDToTypeID("targetLayers");r.putProperty(charID.Property, a);r.putEnumerated(charID.Document, charID.Ordinal, charID.Target);var n = executeActionGet(r);if (n.hasKey(a)) {n = n.getList(a);var i = new ActionReference();i.putProperty(charID.Property, charID.Background);i.putEnumerated(charID.Layer, charID.Ordinal, charID.Back);var o = executeActionGet(i).getBoolean(charID.Background) ? 0 : 1;for (var s = 0; s < n.count; s++) {t.push(n.getReference(s).getIndex() + o);}}if (t.length > 1) {for (var c = 0; c < t.length; c++) {var l = new ActionDescriptor();var u = new ActionReference();u.putIndex(charID.Layer, t[c]);l.putReference(charID.Null, u);executeAction(charID.Select, l, DialogModes.NO);e(t[c]);}var p = new ActionReference();for (var y = 0; y < t.length; y++) {p.putIndex(charID.Layer, t[y]);}var f = new ActionDescriptor();f.putReference(charID.Null, p);executeAction(charID.Select, f, DialogModes.NO);} else if (t.length === 1) {e(t[0]);}return t.length;}function _setActiveLayerText() {var e = _hostState.setActiveLayerText;var z = e.data;e.result = "";if (!z) {return;} else if (!documents.length) {e.result = "doc";return;} else if (!_layerIsTextLayer()) {e.result = "layer";return;}var K = z.text;var V = z.style ? _resolveStyleSizeForDocument(_clone(z.style)) : z.style;var H = V;var G = z.richTextRuns;var J = 0;if (z.contentOnly && (!G || !G.length)) {_forEachSelectedLayer(function() {app.activeDocument.activeLayer.textItem.contents = _normalizeTextKey(K);if (z.direction === "rtl") _applyTextDirection("rtl");});e.result = "";return;}_forEachSelectedLayer(function() {var e = _getCurrentTextLayerBounds();var t = _textLayerIsPointText();var r = _resolveStylePointText(H, t);if (t) _changeToBoxText();var a = jamText.getLayerText();H = _scaleStyleForPunctuationOnlyText(V, K || a.layerText.textKey);if (z.preserveActiveTextSize && H && a.layerText.textStyleRange && a.layerText.textStyleRange[0] && a.layerText.textStyleRange[0].textStyle) {_overrideStyleTextSize(H, a.layerText.textStyleRange[0].textStyle.size);}var n;if (K && H) {n = H.textProps;if (n.layerText.textStyleRange[0].textStyle.size == null && a.layerText.textStyleRange && a.layerText.textStyleRange[0] && a.layerText.textStyleRange[0].textStyle.size != null) {n.layerText.textStyleRange[0].textStyle.size = a.layerText.textStyleRange[0].textStyle.size;}n.layerText.textKey = _normalizeTextKey(K);n.layerText.textStyleRange[0].to = K.length;n.layerText.paragraphStyleRange[0].to = K.length;J = K.length;_applyRichTextRanges(n, G, J);} else if (K) {n = {"layerText": {"textKey": _normalizeTextKey(K)}};if (a.layerText.textStyleRange && a.layerText.textStyleRange[0]) {n.layerText.textStyleRange = [ a.layerText.textStyleRange[0] ];n.layerText.textStyleRange[0].to = K.length;}if (a.layerText.paragraphStyleRange && a.layerText.paragraphStyleRange[0]) {var i = a.layerText.paragraphStyleRange[0].paragraphStyle || {};var o = {};for (var s = 0; s < _SAFE_PARAGRAPH_PROPS.length; s++) {var c = _SAFE_PARAGRAPH_PROPS[s];if (i[c] !== undefined) {o[c] = i[c];}}n.layerText.paragraphStyleRange = [ {"from": 0,"to": K.length,"paragraphStyle": o} ];}J = K.length;_applyRichTextRanges(n, G, J);} else if (H) {var l = a.layerText.textKey || "";n = H.textProps;n.layerText.textStyleRange[0].to = l.length;n.layerText.paragraphStyleRange[0].to = l.length;J = l.length;}var u = a.layerText.textShape && a.layerText.textShape[0];if (t && u && u.bounds) {var p = a.layerText.textStyleRange && a.layerText.textStyleRange[0] && a.layerText.textStyleRange[0].textStyle;var y = H && H.textProps && H.textProps.layerText && H.textProps.layerText.textStyleRange && H.textProps.layerText.textStyleRange[0] && H.textProps.layerText.textStyleRange[0].textStyle;var f = p && p.size;var h = y && y.size != null ? y.size : f;var g = f && h ? h / f : 1;if (!(g > 0)) g = 1;if (g < 1) g = 1;var d = u.bounds;var v = d.right - d.left;var m = d.bottom - d.top;var T = typeof e.width === "number" ? _convertPixelToPoint(e.width) : v;var I = typeof e.height === "number" ? _convertPixelToPoint(e.height) : m;var D = v * g;var b = m * g;if (D < T * g) D = T * g;var S = (h || f || 12) * .5;if (D < T + S) D = T + S;var x = (h || f || 12) * .75;if (b < I * g) b = I * g;if (b < I + x) b = I + x;d.right = d.left + D;d.bottom = d.top + b;}var _ = H && H.textProps && H.textProps.layerText && H.textProps.layerText.antiAlias;n.layerText.antiAlias = _ || a.layerText.antiAlias || "antiAliasSmooth";if (u) {n.layerText.textShape = [ u ];}n.typeUnit = a.typeUnit;var k = z.direction;if (k === "") k = null;var j = false;if (k && n.layerText.paragraphStyleRange) {_bakeDirection(n.layerText.paragraphStyleRange, k);j = true;}var L = n.layerText.textShape && n.layerText.textShape[0];var E = null;if (!t && L && L.bounds && K) {var C = _getMeasureBoxSpanPoints();E = {"top": L.bounds.top || 0,"left": L.bounds.left || 0,"right": L.bounds.right,"bottom": L.bounds.bottom};L.bounds.right = E.left + C;L.bounds.bottom = E.top + C;}try {jamText.setLayerText(n);} catch (e) {if (!j) throw e;_stripDirection(n.layerText.paragraphStyleRange);jamText.setLayerText(n);_applyTextDirection(k);}_applyMiddleEast(n.layerText.textStyleRange[0].textStyle);if (H && H.stroke) {_setLayerStroke(H.stroke);}if (r) {_changeToPointText();} else {var A = 12;var w = H && H.textProps.layerText.textStyleRange[0].textStyle.size;if (w != null) {A = w;} else if (a.layerText.textStyleRange && a.layerText.textStyleRange[0] && a.layerText.textStyleRange[0].textStyle.size != null) {A = a.layerText.textStyleRange[0].textStyle.size;}var O = n.layerText.textShape && n.layerText.textShape[0];var P = false;if (O && O.bounds && E) {try {var R = _getCurrentTextLayerBounds();if (R.width > 0 && R.height > 0) {var B = Math.max(2, A * .4);O.bounds.right = E.left + _convertPixelToPointExact(R.width) + B;O.bounds.bottom = E.top + _convertPixelToPointExact(R.height) + A + 2;jamText.setLayerText({"layerText": {"textShape": [ O ]}});P = true;}} catch (e) {}}if (!P && O) {if (E) {O.bounds.right = E.right;O.bounds.bottom = E.bottom;jamText.setLayerText({"layerText": {"textShape": n.layerText.textShape}});}var N = _getCurrentTextLayerBounds();O.bounds.bottom = _convertPixelToPoint(N.height + A + 2);jamText.setLayerText({"layerText": {"textShape": n.layerText.textShape}});}}var M = _getCurrentTextLayerBounds();if (!e.bottom) e = M;var F = e.xMid - M.xMid;var U = e.yMid - M.yMid;if (F || U) _moveLayer(F, U);});e.result = "";}function _setTextShapeRText() {var t = _hostState.setTextShapeRText;var r = t.data;t.result = "";if (!r) {return;} else if (!documents.length) {t.result = "doc";return;} else if (!_layerIsTextLayer()) {t.result = "layer";return;}var a = false;try {var e = _resolveStyleSizeForDocument(_clone(r.style));var n = e.textProps;var i = r.text;var o = _getCurrentTextLayerBounds();var s = _textLayerIsPointText();var c = null;try {c = jamText.getLayerText();} catch (e) {}var l = {"layerText": {"textKey": _normalizeTextKey(i)}};var u = _clone(n.layerText.textStyleRange[0]);u.from = 0;u.to = i.length;l.layerText.textStyleRange = [ u ];var p = n.layerText.paragraphStyleRange && n.layerText.paragraphStyleRange[0];var y = p && p.paragraphStyle || {};var f = {};for (var h = 0; h < _SAFE_PARAGRAPH_PROPS.length; h++) {var g = _SAFE_PARAGRAPH_PROPS[h];if (y[g] !== undefined) {f[g] = y[g];}}l.layerText.paragraphStyleRange = [ {"from": 0,"to": i.length,"paragraphStyle": f} ];_applyRichTextRanges(l, r.richTextRuns, i.length);l.layerText.antiAlias = n.layerText.antiAlias || "antiAliasSmooth";l.typeUnit = n.typeUnit;_keepLiveTextSize(l, c, _getDocumentResolution());var d = r.direction;if (d === "") d = null;var v = false;if (d) {_bakeDirection(l.layerText.paragraphStyleRange, d);v = true;}if (!s) {_changeToPointText();a = true;}try {jamText.setLayerText(l);} catch (e) {if (!v) throw e;_stripDirection(l.layerText.paragraphStyleRange);jamText.setLayerText(l);_applyTextDirection(d);}_restoreMiddleEastOffsets(u.textStyle);a = false;var m = _getCurrentTextLayerBounds();if (!o.bottom) o = m;var T = o.xMid - m.xMid;var I = o.yMid - m.yMid;if (T || I) _moveLayer(T, I);t.result = "";} catch (e) {if (a) {try {_changeToBoxText();} catch (e) {}}r.preserveActiveTextSize = true;_hostState.setActiveLayerText.data = r;_setActiveLayerText();t.result = _hostState.setActiveLayerText.result;}}function setTextShapeRLayerText(e) {var t = e && e.text && e.style && e.style.textProps && e.style.textProps.layerText && e.style.textProps.layerText.textStyleRange && e.style.textProps.layerText.textStyleRange[0];if (!t) return setActiveLayerText(e);if (!documents.length) return "doc";var r = _hostState.setTextShapeRText;r.data = e;r.result = "";app.activeDocument.suspendHistory("TyperTools Change", "_setTextShapeRText()");return r.result;}function _createTextLayerInSelection() {var e = _hostState.createTextLayerInSelection;if (!documents.length) {e.result = "doc";return;}if (e.data.preserveActiveTextSize) {if (!_layerIsTextLayer()) {e.result = "sizeSource";return;}e.data.textSizeOverride = _getTextLayerSize();}var t = _checkSelection({"adaptiveOpen": true});if (t.error) {e.result = t.error;return;}var r = _punctuationOnlyBoxDimensions(_calculateSelectionDimensions(t, e.padding), e.data);_createAndSetLayerText(e.data, r.width, r.height);var a = _getCurrentTextLayerBounds();_changeToPointText();a = _getCurrentTextLayerBounds();_positionLayerWithinSelection(t, a);if (_autoCenterEnabled(e.data)) {_autoCenterCreated([ _safeActiveLayerId() ], {"autoCenter": e.data.autoCenter,"resizeTextBox": e.data.resizeTextBox,"padding": e.padding});}e.result = "";}function _wandBubbleOfActiveText() {var e = _currentLayerBox();if (!e) return;_withoutLettering(function() {try {_magicWandAt(e.xMid, e.yMid, _BUBBLE_WAND_TOLERANCE);} catch (e) {}});}function _alignCurrentTextLayerToSelection() {var e = _hostState.alignTextLayerToSelection;if (!_layerIsTextLayer()) {return "layer";}var t = e.placements["id" + _safeActiveLayerId()] || _checkSelection({"adaptiveOpen": true,"holes": [ _currentLayerBox() ]});if (t.error) {if (t.error === "noSelection") {_wandBubbleOfActiveText();t = _checkSelection({"adaptiveOpen": true});}if (t.error) {return t.error;}}var r = _textLayerIsPointText();if (!r) {_changeToPointText();r = true;}var a = _getCurrentTextLayerBounds();if (e.resize && !r) {var n = _calculateSelectionDimensions(t, e.padding);_setTextBoxSize(n.width, n.height);var i = _getCurrentTextLayerBounds();_resizeTextBoxToContent(n.width, i);a = _getCurrentTextLayerBounds();}var o = e.keep ? _saveSelectionState() : null;try {_deselect();} catch (e) {}_positionLayerWithinSelection(t, a);if (r) {_changeToPointText();}if (o) _restoreSelectionState(o, false);return "";}function _alignTextLayerToSelection() {var e = _hostState.alignTextLayerToSelection;if (!documents.length) {e.result = "doc";return;}var t = 0;var r = "";var a = _forEachSelectedLayer(function() {var e = _alignCurrentTextLayerToSelection();if (e) {if (!r) r = e;return;}t++;});if (!a) {r = _alignCurrentTextLayerToSelection();if (!r) t++;}e.result = t > 0 ? "" : r;}function _changeActiveLayerTextSize() {var i = _hostState.changeActiveLayerTextSize;if (!documents.length) {i.result = "doc";return;} else if (!_layerIsTextLayer()) {i.result = "layer";return;} else if (!i.value) {i.result = "";return;}var o = _getDocumentResolution();var s = 0;var c = "";_forEachSelectedLayer(function() {var e = null;try {e = _currentLayerBox();} catch (e) {}var t = null;try {t = jamText.getLayerText();} catch (e) {}var r = t ? _textResizePlan(t, i.value, o) : null;var a = _readTextStyleSize();var n = false;if (!r || r.uniform) {try {_resizeTextStyleFast(r, i.value);n = true;} catch (e) {}}if (!n) {try {if (!t) t = jamText.getLayerText();} catch (e) {c = "layer";return;}if (!_resizeTextRebuild(t, r, i.value)) {c = "layer";return;}}if (r && r.frame) {try {_fitFrameToTextSize(r, a, n ? null : r.ratio, t.typeUnit);} catch (e) {}}_recentreOnBox(e);s++;});i.result = s > 0 ? "" : c;}function _readTextStyleSize() {try {var e = new ActionReference();e.putProperty(charID.Property, charID.TextStyle);e.putEnumerated(charID.TextLayer, charID.Ordinal, charID.Target);var t = executeActionGet(e);if (!t.hasKey(charID.TextStyle)) return null;var r = t.getObjectValue(charID.TextStyle);if (!r.hasKey(charID.Size)) return null;return {"value": r.getUnitDoubleValue(charID.Size),"unit": r.getUnitDoubleType(charID.Size)};} catch (e) {return null;}}function _resizeTextStyleFast(e, t) {var r = _readTextStyleSize();if (!r) throw new Error("no textStyle");var a = e ? e.nextShown : r.value + t;if (!(a > 0)) throw new Error("bad size");var n = e ? stringIDToTypeID(e.unit) : r.unit;var i = new ActionDescriptor();i.putUnitDouble(charID.Size, n, a);if (e && e.scaleLeading && e.nextLeading > 0) {i.putUnitDouble(stringIDToTypeID("leading"), n, e.nextLeading);}var o = new ActionDescriptor();var s = new ActionReference();s.putProperty(charID.Property, charID.TextStyle);s.putEnumerated(charID.TextLayer, charID.Ordinal, charID.Target);o.putReference(charID.Null, s);o.putObject(charID.To, charID.TextStyle, i);executeAction(charID.Set, o, DialogModes.NO);}function _resizeTextRebuild(e, t, r) {var a = e && e.layerText;var n = a ? _normalizeTextKey(a.textKey) : "";if (!n || !a.textStyleRange || !a.textStyleRange.length) return false;var i = Number(a.textStyleRange[0].textStyle && a.textStyleRange[0].textStyle.size);var o = 1;if (t) {o = t.ratio;} else if (i > 0) {o = Math.max(.1, i + r) / i;}var s = _transformScale(a);var c = {"typeUnit": e.typeUnit,"layerText": {"textKey": n,"textGridding": a.textGridding || "none","orientation": a.orientation || "horizontal","antiAlias": a.antiAlias || "antiAliasSmooth","textStyleRange": []}};for (var l = 0; l < a.textStyleRange.length; l++) {var u = _clone(a.textStyleRange[l]);var p = u.textStyle || {};var y = Number(p.size);if (y > 0) p.size = Math.max(.1, _displayedStyleValue(p, "size", "impliedFontSize", s) * o);if (p.autoLeading || p.leading === undefined) {p.autoLeading = true;delete p.leading;} else {p.leading = Math.max(.1, _displayedStyleValue(p, "leading", "impliedLeading", s) * o);p.autoLeading = false;}if (p.baselineShift !== undefined) {p.baselineShift = _displayedStyleValue(p, "baselineShift", "impliedBaselineShift", s);}delete p.impliedFontSize;delete p.impliedLeading;delete p.impliedBaselineShift;u.textStyle = p;if (u.to > n.length) u.to = n.length;c.layerText.textStyleRange.push(u);}c.layerText.textStyleRange[c.layerText.textStyleRange.length - 1].to = n.length;if (a.paragraphStyleRange && a.paragraphStyleRange[0]) {var f = _clone(a.paragraphStyleRange[0]);var h = f.paragraphStyle || {};h.textEveryLineComposer = h.textEveryLineComposer || false;h.burasagari = h.burasagari || "burasagariNone";f.paragraphStyle = h;f.to = n.length;c.layerText.paragraphStyleRange = [ f ];}var g = _scaleTextShape(t ? t.frame : a.textShape && a.textShape[0], o);if (g) c.layerText.textShape = [ g ];jamText.setLayerText(c);_applyMiddleEast(c.layerText.textStyleRange[0].textStyle);return true;}function _fitFrameToTextSize(e, t, r, a) {var n = _appliedSizeRatio(t, _readTextStyleSize(), e.ratio);if (r !== null && Math.abs(n - r) < 1e-9) return;var i = _scaleTextShape(e.frame, n);if (!i) return;var o = {"layerText": {"textShape": [ i ]}};if (a) o.typeUnit = a;jamText.setLayerText(o);}function _recentreOnBox(e) {if (!e) return;var t = null;try {t = _currentLayerBox();} catch (e) {}if (!t) return;var r = e.xMid - t.xMid;var a = e.yMid - t.yMid;if (r || a) _moveLayer(r, a);}function nativeAlert(e) {if (!e) return "";alert(e.text, e.title, e.isError);}function nativeConfirm(e) {if (!e) return "";var t = confirm(e.text, false, e.title);return t ? "1" : "";}function getUserFonts() {var e = [];for (var t = 0; t < app.fonts.length; t++) {var r = app.fonts[t];e.push({"name": r.name,"postScriptName": r.postScriptName,"family": r.family,"style": r.style});}return jamJSON.stringify({"fonts": e});}function reloadUserFonts() {try {app.refreshFonts();} catch (e) {}return getUserFonts();}var frontmostCheckCache = {"time": 0,"front": true};function isHostAppFrontmost() {if ($.os && $.os.indexOf("Windows") === 0) return true;var e = new Date().getTime();if (e - frontmostCheckCache.time < 300) return frontmostCheckCache.front;var t = true;try {t = app.system("lsappinfo info -only name `lsappinfo front` 2>/dev/null | grep -qi photoshop") === 0;} catch (e) {t = true;}frontmostCheckCache.time = e;frontmostCheckCache.front = t;return t;}function getHotkeyPressed() {var e = ScriptUI.environment.keyboardState;var t = "a";if (e.metaKey) {t += "WINa";}if (e.ctrlKey) {t += "CTRLa";}if (e.altKey) {t += "ALTa";}if (e.shiftKey) {t += "SHIFTa";}if (e.keyName) {t += e.keyName.toUpperCase() + "a";}if (t !== "a" && !isHostAppFrontmost()) {return "a";}return t;}function getActiveLayerText() {if (!documents.length) {return "";}if (!_layerIsTextLayer()) {return "";}var e = null;try {var t = stringIDToTypeID("layerID");var r = new ActionReference();r.putProperty(charID.Property, t);r.putEnumerated(charID.Layer, charID.Ordinal, charID.Target);e = executeActionGet(r).getInteger(t);} catch (e) {}var a = null;try {a = _getCurrentTextLayerBounds();} catch (e) {}var n = null;try {n = _getLayerStroke();} catch (e) {}var i = "";try {var o = new ActionReference();o.putProperty(charID.Property, charIDToTypeID("Nm  "));o.putEnumerated(charID.Layer, charID.Ordinal, charID.Target);i = executeActionGet(o).getString(charIDToTypeID("Nm  "));} catch (e) {}return jamJSON.stringify({"layerId": e,"layerName": i,"bounds": a,"textType": _textLayerIsPointText() ? "point" : "paragraph","textProps": jamText.getLayerText(),"stroke": n});}function _getRenderedTextLines() {var e = _hostState.getRenderedTextLines;var t = null;try {t = _getActiveLayerId();} catch (e) {}var r = false;try {_duplicateActiveLayer();r = true;_changeToPointText();var a = jamText.getLayerText();if (a && a.layerText && typeof a.layerText.textKey === "string") {e.result = a.layerText.textKey;}} catch (e) {}if (r) {try {_deleteActiveLayer();} catch (e) {}}if (t !== null) {try {_selectLayerById(t);} catch (e) {}}}function getRenderedTextLines() {if (!documents.length || !_layerIsTextLayer()) {return jamJSON.stringify({"error": "layer"});}if (_textLayerIsPointText()) {var e = jamText.getLayerText();var t = e && e.layerText ? e.layerText.textKey : "";return jamJSON.stringify({"text": t || ""});}var r = _hostState.getRenderedTextLines;r.result = "";app.activeDocument.suspendHistory("TyperTools Read Shape", "_getRenderedTextLines()");return jamJSON.stringify({"text": r.result});}function _collectTextLayerIds(e, t, r) {for (var a = 0; a < e.layers.length; a++) {if (t.length >= r) return;var n = e.layers[a];if (n.typename === "LayerSet") {_collectTextLayerIds(n, t, r);} else if (n.kind === LayerKind.TEXT && n.visible) {t.push(n.id);}}}function _getAllRenderedTextLines() {var e = _hostState.getAllRenderedTextLines;var t = null;try {t = _getActiveLayerId();} catch (e) {}var r = false;if (e.scanBubbles) {try {r = !_getCurrentSelectionBounds();} catch (e) {}}var a = [];try {_collectTextLayerIds(app.activeDocument, a, 80);} catch (e) {}var n = [];for (var i = 0; i < a.length; i++) {try {_selectLayerById(a[i]);if (!_layerIsTextLayer()) continue;var o = null;if (r) {try {var s = _scanActiveLayerBubble(20, 17);if (s && !s.error && s.bounds && s.rows && s.rows.length) {o = {"rows": s.rows,"width": s.bounds.width,"height": s.bounds.height};}} catch (e) {}}var c = "";if (_textLayerIsPointText()) {var l = jamText.getLayerText();c = l && l.layerText ? l.layerText.textKey : "";} else {var u = false;try {_duplicateActiveLayer();u = true;_changeToPointText();var p = jamText.getLayerText();if (p && p.layerText && typeof p.layerText.textKey === "string") {c = p.layerText.textKey;}} catch (e) {}if (u) {try {_deleteActiveLayer();} catch (e) {}}}if (c) n.push({"text": c,"bubble": o});} catch (e) {}}if (t !== null) {try {_selectLayerById(t);} catch (e) {}}e.result = jamJSON.stringify({"entries": n});}function getAllRenderedTextLines(e) {if (!documents.length) {return jamJSON.stringify({"error": "document"});}var t = _hostState.getAllRenderedTextLines;t.scanBubbles = !!(e && e.scanBubbles);t.result = jamJSON.stringify({"entries": []});app.activeDocument.suspendHistory("TyperTools Read Shapes", "_getAllRenderedTextLines()");return t.result;}function _collectTrainingTextLayers(e, t, r, a) {for (var n = 0; n < e.layers.length; n++) {var i = e.layers[n];var o = r ? r + " / " + i.name : i.name;var s = a && i.visible;if (i.typename === "LayerSet") {_collectTrainingTextLayers(i, t, o, s);} else if (i.kind === LayerKind.TEXT) {t.push({"layerId": i.id,"name": i.name,"layerPath": o,"visible": s});}}}function _readTextShapeRTrainingLayers() {var e = _hostState.textShapeRTraining;var t = [];_collectTrainingTextLayers(app.activeDocument, t, "", true);for (var r = 0; r < t.length; r++) {var a = t[r];a.text = "";try {_selectLayerById(a.layerId);if (_textLayerIsPointText()) {var n = jamText.getLayerText();a.text = n && n.layerText ? n.layerText.textKey || "" : "";} else {_hostState.getRenderedTextLines.result = "";_getRenderedTextLines();a.text = _hostState.getRenderedTextLines.result || "";if (!a.text) a.error = "readFailed";}} catch (e) {a.error = "readFailed";}}e.entries = t;}function scanTextShapeRTraining(e) {var t = null;var r = null;var a = null;var n = null;var i = app.displayDialogs;try {t = app.activeDocument;} catch (e) {}try {if (e) {if (!/\.psd$/i.test(e)) return jamJSON.stringify({"error": "badPath"});n = new File(e);if (!n.exists) return jamJSON.stringify({"error": "notFound"});for (var o = 0; o < app.documents.length; o++) {try {if (app.documents[o].fullName.fsName === n.fsName) {r = app.documents[o];break;}} catch (e) {}}} else {r = t;if (!r) return jamJSON.stringify({"error": "document"});}app.displayDialogs = DialogModes.NO;if (r) {app.activeDocument = r;a = r.duplicate("TypeR Training Preview", false);} else {a = app.open(n);}app.activeDocument = a;_hostState.textShapeRTraining = {"entries": []};a.suspendHistory("TypeR Read Training", "_readTextShapeRTrainingLayers()");return jamJSON.stringify({"entries": _hostState.textShapeRTraining.entries});} catch (e) {return jamJSON.stringify({"error": "scanFailed"});} finally {if (a) {try {a.close(SaveOptions.DONOTSAVECHANGES);} catch (e) {}}if (t) {try {app.activeDocument = t;} catch (e) {}}app.displayDialogs = i;_hostState.textShapeRTraining = null;}}function setActiveLayerText(e) {var t = _hostState.setActiveLayerText;t.data = e;t.result = "";app.activeDocument.suspendHistory("TyperTools Change", "_setActiveLayerText()");return t.result;}function _setSelectedTextLayers() {var t = _hostState.setSelectedTextLayers;var e = t.data && t.data.items ? t.data.items : [];var r = t.data && t.data.restoreLayerIds ? t.data.restoreLayerIds : [];var a = [];t.result = "";if (!documents.length) {t.result = "doc";return;}if (e.length < 2) {t.result = "layer";return;}var n = r.length ? r : e;for (var i = 0; i < n.length; i++) {var o = r.length ? n[i] : n[i].layerId;var s = parseInt(o, 10);if (!isNaN(s)) a.push(s);}for (var c = 0; c < e.length; c++) {var l = parseInt(e[c].layerId, 10);if (isNaN(l)) {t.result = "layer";break;}try {_selectLayerById(l);if (!_layerIsTextLayer() || app.activeDocument.activeLayer.allLocked) {t.result = "layer";break;}} catch (e) {t.result = "scriptError: " + (e && e.message ? e.message : e);break;}}if (t.result) {if (a.length) {try {_selectLayersById(a);} catch (e) {}}return;}for (var u = 0; u < e.length; u++) {var p = parseInt(e[u].layerId, 10);if (isNaN(p)) {t.result = "layer";break;}try {_selectLayerById(p);if (!_layerIsTextLayer()) {t.result = "layer";break;}_hostState.setActiveLayerText.data = e[u];_hostState.setActiveLayerText.result = "";_setActiveLayerText();if (_hostState.setActiveLayerText.result) {t.result = _hostState.setActiveLayerText.result;break;}} catch (e) {t.result = "scriptError: " + (e && e.message ? e.message : e);break;}}if (a.length) {try {_selectLayersById(a);} catch (e) {}}}function setSelectedTextLayers(e) {var t = _hostState.setSelectedTextLayers;t.data = e;t.result = "";if (!documents.length) return "doc";var r = null;try {r = app.activeDocument.activeHistoryState;} catch (e) {}app.activeDocument.suspendHistory("TyperTools Multiple Paste", "_setSelectedTextLayers()");if (t.result && r) {try {app.activeDocument.activeHistoryState = r;} catch (e) {}var a = e && e.restoreLayerIds ? e.restoreLayerIds : [];if (a.length) {try {_selectLayersById(a);} catch (e) {}}}return t.result;}function createTextLayerInSelection(e, t) {var r = _hostState.createTextLayerInSelection;r.data = e;r.point = t;r.padding = e.padding || 0;r.result = "";app.activeDocument.suspendHistory("TyperTools Paste", "_createTextLayerInSelection()");return r.result;}function alignTextLayerToSelection(e) {var t = _hostState.alignTextLayerToSelection;t.resize = !!e.resizeTextBox;t.keep = !!e.keepSelection;t.padding = e.padding || 0;t.result = "";t.placements = {};try {if (e.placements && String(app.activeDocument.id) === String(e.documentId)) {t.placements = _alignPlacementMap(e.placements);}} catch (e) {}app.activeDocument.suspendHistory("TyperTools Align", "_alignTextLayerToSelection()");t.placements = {};return t.result;}function _alignPlacementMap(e) {var t = {};for (var r = 0; e && r < e.length; r++) {var a = e[r];var n = a && a.rect;var i = n ? _rectFrom(n.left, n.top, n.right, n.bottom) : null;if (!i || a.id === undefined || a.id === null) continue;var o = Number(n.xMid);var s = Number(n.yMid);if (isFinite(o) && isFinite(s) && _containsPoint(i, o, s)) {i.xMid = o;i.yMid = s;}t["id" + a.id] = i;}return t;}function alignCapture() {if (!documents.length) return jamJSON.stringify({"error": "doc"});var e = _withTemporaryHistory("TypeR Read Bubble", _alignCaptureRun, {"discardRedo": true});if (!e || e.error) return jamJSON.stringify({"error": e && e.error || "capture"});return jamJSON.stringify(e);}function _layerStackIndex(e) {try {var t = stringIDToTypeID("itemIndex");var r = new ActionReference();r.putProperty(charID.Property, t);r.putIdentifier(charID.Layer, e);return executeActionGet(r).getInteger(t);} catch (e) {return 0;}}function _alignReadOutline() {var e = _liveSelectionBounds();if (!e) return null;_makeWorkPathFromSelection(2);var t = _smartReadWorkPath();if (!t) return null;return {"selectionBounds": {"left": e.left,"top": e.top,"right": e.right,"bottom": e.bottom},"rawPath": t,"textIds": []};}function _alignCaptureRun() {var n = _getDocumentPixelSize();var e = _targetLayerEntries();var t = [];var i = [];var o, s;for (o = 0; o < e.length; o++) {t.push(e[o].id);if (!e[o].text) continue;_selectLayerById(e[o].id);var r = _currentLayerBox();if (r) i.push({"id": e[o].id,"index": _layerStackIndex(e[o].id),"box": r,"sizePixels": _currentDisplayedTextPixels()});}var c = [];if (_liveSelectionBounds()) {var a = _alignReadOutline();if (a) {for (o = 0; o < i.length; o++) a.textIds.push(i[o].id);c.push(a);}} else {_withoutLettering(function() {for (o = 0; o < i.length; o++) {var e = _probeBubble(i[o].box, i[o].sizePixels, [], n).best;var t = e ? _liveSelectionBounds() : null;if (!t) continue;var r = null;for (s = 0; s < c.length && !r; s++) {var a = c[s].selectionBounds;if (a.left === t.left && a.top === t.top && a.right === t.right && a.bottom === t.bottom) r = c[s];}if (!r) {r = _alignReadOutline();if (!r) continue;c.push(r);}r.textIds.push(i[o].id);}});}if (t.length > 1) _selectLayersById(t); else if (t.length) _selectLayerById(t[0]);return {"documentId": app.activeDocument.id,"width": n.width,"height": n.height,"resolution": _getDocumentResolution(),"texts": i,"bubbles": c};}function countSelectedTextLayers() {try {if (!documents.length) return "0";var e = _targetLayerEntries();var t = 0;for (var r = 0; e && r < e.length; r++) {if (e[r] && e[r].text) t++;}return String(t);} catch (e) {return "0";}}function getSelectedTextLayerBoxes(e) {if (!documents.length) return jamJSON.stringify({"error": "doc"});var t = null;try {t = _targetLayerEntries();} catch (e) {t = null;}var r = !!(e && e.single);if (r) {if (!t || t.length !== 1 || !t[0].text) return jamJSON.stringify({"error": "doubleBubbleLayers"});} else if (!_doubleBubbleEntriesValid(t)) {return jamJSON.stringify({"error": "doubleBubbleLayers"});}var a = [];var n = [];try {for (var i = 0; i < t.length; i++) {_selectLayerById(t[i].id);var o = _currentLayerBox();if (!o) return jamJSON.stringify({"error": "doubleBubbleEmpty"});a.push({"id": t[i].id,"left": o.left,"top": o.top,"right": o.right,"bottom": o.bottom});n.push(t[i].id);}} finally {try {_selectLayersById(n);} catch (e) {}}return jamJSON.stringify({"items": a});}function getCurrentSelectionPolygons() {if (!documents.length) return jamJSON.stringify({"error": "doc"});var e = _getCurrentSelectionBounds();if (!e) return jamJSON.stringify({"error": "noSelection"});var t = _withTemporaryHistory("TypeR Outline Scan", function() {return _withDialogsSuppressed(function() {var e = app.activeDocument;if (_findWorkPath(e)) return {"error": "workPath"};var t = _createTempSelectionChannel(e);if (!t) return {"error": "channel"};var r = null;var a = "";try {_makeWorkPathFromSelection(2);} catch (e) {a = "make";}if (!a) {var n = _findWorkPath(e);if (n) {try {r = _readPathPolygons(n);} catch (e) {a = "read";}try {_deleteWorkPath();} catch (e) {try {n.remove();} catch (e) {}}} else {a = "noWorkPath";}}try {e.selection.load(t);} catch (e) {}try {t.remove();} catch (e) {}if (a || !r || !r.length) return {"error": a || "noPolygons"};return {"polygons": r};});});if (!t || t.error) return jamJSON.stringify({"error": t && t.error || "scan"});var r = [];for (var a = 0; a < t.polygons.length; a++) {var n = t.polygons[a];var i = [];for (var o = 0; o < n.length; o++) i.push([ Math.round(n[o][0] * 10) / 10, Math.round(n[o][1] * 10) / 10 ]);r.push(i);}return jamJSON.stringify({"bounds": {"left": e.left,"top": e.top,"width": e.width,"height": e.height},"polygons": r});}var _placeRectsState = {"items": [],"resize": false,"keep": false,"padding": 0,"result": ""};function _placeLayersInRectsRun() {var t = _placeRectsState;var e = _saveSelectionState();var r = [];try {for (var a = 0; a < t.items.length; a++) {var n = t.items[a];var i = _rectFrom(n.left, n.top, n.right, n.bottom);if (!i) {t.result = "doubleBubbleEmpty";return;}_selectLayerById(n.id);if (!_placeLayerInRect(i, t.resize, t.padding)) {t.result = "doubleBubbleEmpty";return;}r.push(n.id);}_selectLayersById(r);} catch (e) {t.result = "scriptError: " + (e && e.message ? e.message : e);}_restoreSelectionState(e, !t.result && !t.keep);}function placeLayersInRects(e) {var t = _placeRectsState;t.items = e && e.items || [];t.resize = !!(e && e.resizeTextBox);t.keep = !!(e && e.keepSelection);t.padding = e && e.padding || 0;t.result = "";if (!documents.length) return "doc";var r = app.activeDocument;var a = null;try {a = r.activeHistoryState;} catch (e) {}try {r.suspendHistory("TyperTools Align Double", "_placeLayersInRectsRun()");} catch (e) {t.result = "scriptError: " + (e && e.message ? e.message : e);}if (t.result && a) {try {r.activeHistoryState = a;} catch (e) {}}t.items = [];return t.result;}function alignTextLayersToDoubleBubble(e) {var t = _hostState.alignTextLayersToDoubleBubble;t.resize = !!(e && e.resizeTextBox);t.padding = e && e.padding || 0;t.result = "";t.entries = null;if (!documents.length) return "doc";var r = null;try {r = _targetLayerEntries();} catch (e) {r = null;}if (!_doubleBubbleEntriesValid(r)) return "doubleBubbleLayers";t.entries = r;var a = app.activeDocument;var n = null;try {n = a.activeHistoryState;} catch (e) {}try {a.suspendHistory("TyperTools Align Double", "_alignTextLayersToDoubleBubble()");} catch (e) {t.result = "scriptError: " + (e && e.message ? e.message : e);}if (t.result && n) {try {a.activeHistoryState = n;} catch (e) {}}t.entries = null;return t.result;}function changeActiveLayerTextSize(e) {var t = _hostState.changeActiveLayerTextSize;t.value = e;t.result = "";app.activeDocument.suspendHistory("TyperTools Resize", "_changeActiveLayerTextSize()");return t.result;}function getCurrentSelection() {if (!documents.length) {return jamJSON.stringify({"error": "doc"});}var e = _checkSelection({"adjustAmount": 0});if (e.error) {return jamJSON.stringify({"error": e.error});}return jamJSON.stringify(e);}function _buildBoundsShapeRows(e, t) {var r = [];for (var a = 0; a < t; a++) {var n = t <= 1 ? .5 : a / (t - 1);r.push({"y": n,"left": 0,"right": 1,"width": 1});}return {"bounds": e,"rows": r,"fallback": true};}function _normalizeShapeSampleCount(e, t) {var r = e ? parseInt(e, 10) : t;if (isNaN(r)) r = t;if (r < 5) r = 5;if (r > 31) r = 31;return r;}function _sampleCurrentSelectionShape(e, t) {var r = app.activeDocument;var a = _createTempSelectionChannel(r);if (!a) {return _buildBoundsShapeRows(e, t);}var n = [];var i = app.preferences.rulerUnits;var o = true;try {app.preferences.rulerUnits = Units.PIXELS;for (var s = 0; s < t; s++) {var c = t <= 1 ? .5 : s / (t - 1);var l = e.top + e.height * c;var u = Math.max(1, Math.ceil(e.height / t));var p = Math.max(e.top, Math.round(l - u / 2));var y = Math.min(e.bottom, Math.round(l + u / 2));if (y <= p) y = p + 1;try {r.selection.select([ [ e.left, p ], [ e.right, p ], [ e.right, y ], [ e.left, y ] ], SelectionType.REPLACE, 0, false);r.selection.load(a, SelectionType.INTERSECT);} catch (e) {o = false;break;}var f = _getCurrentSelectionBounds();if (f && f.width > 0) {n.push({"y": c,"left": Math.max(0, Math.min(1, (f.left - e.left) / e.width)),"right": Math.max(0, Math.min(1, (f.right - e.left) / e.width)),"width": Math.max(0, Math.min(1, f.width / e.width))});} else {n.push({"y": c,"left": .5,"right": .5,"width": 0});}}} catch (e) {o = false;} finally {try {r.selection.load(a);} catch (e) {}try {a.remove();} catch (e) {}app.preferences.rulerUnits = i;}if (!o || !n.length) {return _buildBoundsShapeRows(e, t);}return {"bounds": e,"rows": n,"fallback": false};}function _findWorkPath(e) {try {for (var t = 0; t < e.pathItems.length; t++) {if (e.pathItems[t].kind === PathKind.WORKPATH) return e.pathItems[t];}} catch (e) {}return null;}function _readPathPolygons(e) {var t = [];var r = e.subPathItems;for (var a = 0; a < r.length; a++) {var n = r[a].pathPoints;var i = n.length;if (i < 3) continue;var o = i > 500 ? 1 : 6;var s = [];for (var c = 0; c < i; c++) {var l = n[c];var u = n[(c + 1) % i];var p = l.anchor;var y = l.rightDirection;var f = u.leftDirection;var h = u.anchor;var g = y[0] === p[0] && y[1] === p[1] && f[0] === h[0] && f[1] === h[1];var d = g ? 1 : o;for (var v = 0; v < d; v++) {var m = v / d;var T = 1 - m;s.push([ T * T * T * p[0] + 3 * T * T * m * y[0] + 3 * T * m * m * f[0] + m * m * m * h[0], T * T * T * p[1] + 3 * T * T * m * y[1] + 3 * T * m * m * f[1] + m * m * m * h[1] ]);}}if (s.length >= 3) t.push(s);}return t;}function _polygonScanlineSpan(e, t) {var r = null;var a = null;for (var n = 0; n < e.length; n++) {var i = e[n];for (var o = 0; o < i.length; o++) {var s = i[o];var c = i[(o + 1) % i.length];if (s[1] <= t && c[1] > t || c[1] <= t && s[1] > t) {var l = s[0] + (t - s[1]) / (c[1] - s[1]) * (c[0] - s[0]);if (r === null || l < r) r = l;if (a === null || l > a) a = l;}}}return r === null ? null : {"left": r,"right": a};}function _buildPathShapeRows(e, t) {var r = Infinity;var a = Infinity;var n = -Infinity;var i = -Infinity;for (var o = 0; o < e.length; o++) {for (var s = 0; s < e[o].length; s++) {var c = e[o][s];if (c[0] < r) r = c[0];if (c[0] > n) n = c[0];if (c[1] < a) a = c[1];if (c[1] > i) i = c[1];}}var l = n - r;var u = i - a;if (!(l > 0) || !(u > 0)) return null;var p = u / t;var y = [];var f = 0;for (var h = 0; h < t; h++) {var g = t <= 1 ? .5 : h / (t - 1);var d = a + u * g;var v = null;var m = null;var T = [ -p / 2, 0, p / 2 ];for (var I = 0; I < T.length; I++) {var D = d + T[I];if (D <= a) D = a + u * .002;if (D >= i) D = i - u * .002;var b = _polygonScanlineSpan(e, D);if (b) {if (v === null || b.left < v) v = b.left;if (m === null || b.right > m) m = b.right;}}if (v !== null && m > v) {f++;y.push({"y": g,"left": Math.max(0, Math.min(1, (v - r) / l)),"right": Math.max(0, Math.min(1, (m - r) / l)),"width": Math.max(0, Math.min(1, (m - v) / l))});} else {y.push({"y": g,"left": .5,"right": .5,"width": 0});}}if (!f) return null;return y;}function _withDialogsSuppressed(e) {var t = null;try {t = app.displayDialogs;app.displayDialogs = DialogModes.NO;} catch (e) {t = null;}var r = null;try {r = e();} finally {if (t !== null) {try {app.displayDialogs = t;} catch (e) {}}}return r;}function _makeWorkPathFromSelection(e) {var t = [ charID.SelectionClass, charID.Channel ];var r = null;for (var a = 0; a < t.length; a++) {try {var n = new ActionDescriptor();var i = new ActionReference();i.putClass(charID.Path);n.putReference(charID.Null, i);var o = new ActionReference();o.putProperty(t[a], charID.FrameSelect);n.putReference(charID.From, o);n.putUnitDouble(charID.Tolerance, charID.PixelUnit, e);executeAction(charID.Make, n, DialogModes.NO);return;} catch (e) {r = e;}}throw r;}function _deleteWorkPath() {var e = new ActionDescriptor();var t = new ActionReference();t.putProperty(charID.Path, charID.WorkPath);e.putReference(charID.Null, t);executeAction(charID.Delete, e, DialogModes.NO);}function _sampleSelectionShapeViaPath(e, t, r) {if ((_hostState.pathScanFails || 0) >= 3) {var a = new Date().getTime();if (a - (_hostState.pathScanBackoffAt || 0) < _PATH_SCAN_RETRY_MS) return null;_hostState.pathScanFails = 2;}var n = app.activeDocument;if (_findWorkPath(n)) return null;var i = _createTempSelectionChannel(n);if (!i) return null;var o = null;var s = "";try {_makeWorkPathFromSelection(2);} catch (e) {s = "make:" + String(e.message || e);}if (!s) {var c = _findWorkPath(n);if (c) {try {o = _readPathPolygons(c);} catch (e) {s = "read:" + String(e.message || e);}try {_deleteWorkPath();} catch (e) {try {c.remove();} catch (e) {}}} else {s = "noWorkPath";}}var l = null;if (!s && o && o.length) {l = _buildPathShapeRows(o, t);if (!l) s = "emptyRows";} else if (!s) {s = "noPolygons";}if (r || !l) {try {n.selection.load(i);} catch (e) {}}try {i.remove();} catch (e) {}if (!l) {_hostState.pathScanFails = (_hostState.pathScanFails || 0) + 1;if (_hostState.pathScanFails >= 3) {_hostState.pathScanBackoffAt = new Date().getTime();}_hostState.lastPathScanError = s;return null;}_hostState.pathScanFails = 0;_hostState.lastPathScanError = "";return {"scan": "path","bounds": e,"rows": l,"fallback": false};}function getCurrentSelectionShape(e) {if (!documents.length) {return jamJSON.stringify({"error": "doc"});}var t = _getCurrentSelectionBounds();if (!t) {return jamJSON.stringify({"error": "noSelection"});}var r = _normalizeShapeSampleCount(e && e.samples, 17);var a = _withTemporaryHistory("TypeR Shape Scan", function() {return _withDialogsSuppressed(function() {return _sampleSelectionShapeViaPath(t, r, true) || _sampleCurrentSelectionShape(t, r);});});if (a && a.error) return jamJSON.stringify(a);a = a || _buildBoundsShapeRows(t, r);var n = {"scan": a.scan || "legacy"};if (n.scan === "legacy" && _hostState.lastPathScanError) {n.scanError = _hostState.lastPathScanError;}n.bounds = a.bounds;n.rows = a.rows;n.fallback = a.fallback;return jamJSON.stringify(n);}function _scanActiveLayerBubble(s, c) {return _withDialogsSuppressed(function() {var t = null;try {var e = _getCurrentTextLayerBounds();_createMagicWandSelection(s);var r = _getCurrentSelectionBounds();if (!r || r.width * r.height < 200) {_deselect();return {"error": "noBubble"};}if (e && e.width > 0 && e.height > 0) {var a = r.width * r.height / (e.width * e.height);if (a > 60) {_deselect();return {"error": "noBubble"};}}var n = Math.max(4, Math.round(_getTextLayerSize() / 2));_modifySelectionBounds(n);var i = _getCurrentSelectionBounds();var o = _clampAdjustAmount(i, -n);if (o !== 0) _modifySelectionBounds(o);r = _getCurrentSelectionBounds() || r;t = _sampleSelectionShapeViaPath(r, c, false) || _sampleCurrentSelectionShape(r, c);} catch (e) {t = null;}try {_deselect();} catch (e) {}return t;});}function getActiveLayerBubbleShape(e) {if (!documents.length) {return jamJSON.stringify({"error": "doc"});}if (!_layerIsTextLayer()) {return jamJSON.stringify({"error": "layer"});}if (_getCurrentSelectionBounds()) {return jamJSON.stringify({"error": "hasSelection"});}if (_getTargetLayerCount() > 1) {return jamJSON.stringify({"error": "multi"});}var t = e && e.tolerance ? parseInt(e.tolerance, 10) : 20;if (isNaN(t)) t = 20;var r = _normalizeShapeSampleCount(e && e.samples, 21);var a = _withTemporaryHistory("TypeR Bubble Scan", function() {return _scanActiveLayerBubble(t, r);});if (!a) {return jamJSON.stringify({"error": "shape"});}if (a.error) {return jamJSON.stringify({"error": a.error});}var n = {"scan": a.scan || "legacy"};if (n.scan === "legacy" && _hostState.lastPathScanError) {n.scanError = _hostState.lastPathScanError;}n.bounds = a.bounds;n.rows = a.rows;n.fallback = a.fallback;return jamJSON.stringify(n);}function getSelectedTextLayers() {if (!documents.length) {return jamJSON.stringify({"error": "doc"});}var e = [];var t = stringIDToTypeID("targetLayers");var r = stringIDToTypeID("layerID");var a = [];var n = new ActionReference();n.putProperty(charID.Property, t);n.putEnumerated(charID.Document, charID.Ordinal, charID.Target);var i = executeActionGet(n);if (i.hasKey(t)) {var o = i.getList(t);var s = new ActionReference();s.putProperty(charID.Property, charID.Background);s.putEnumerated(charID.Layer, charID.Ordinal, charID.Back);var c = executeActionGet(s).getBoolean(charID.Background) ? 0 : 1;for (var l = 0; l < o.count; l++) {a.push(o.getReference(l).getIndex() + c);}} else {a.push(-1);}for (var u = 0; u < a.length; u++) {try {var p = new ActionReference();p.putProperty(charID.Property, charID.Text);if (a[u] === -1) {p.putEnumerated(charID.Layer, charID.Ordinal, charID.Target);} else {p.putIndex(charID.Layer, a[u]);}if (!executeActionGet(p).hasKey(charID.Text)) continue;var y = new ActionReference();y.putProperty(charID.Property, r);if (a[u] === -1) {y.putEnumerated(charID.Layer, charID.Ordinal, charID.Target);} else {y.putIndex(charID.Layer, a[u]);}e.push({"id": executeActionGet(y).getInteger(r)});} catch (e) {}}return jamJSON.stringify({"layers": e});}function getActiveLayerTextIfChanged(e) {if (!documents.length || !_layerIsTextLayer()) {return jamJSON.stringify({"error": "layer","signature": ""});}var t = null;var r = null;try {t = _getActiveLayerId();} catch (e) {}try {r = _getActiveHistoryIndex();} catch (e) {}var a = String(t) + ":" + String(r);if (t !== null && r !== null && e && e.signature === a) {return jamJSON.stringify({"unchanged": true,"signature": a});}var n = null;try {n = jamJSON.parse(getActiveLayerText());} catch (e) {}if (!n) return jamJSON.stringify({"error": "layer","signature": a});n.signature = a;return jamJSON.stringify(n);}function getActiveTextLayerGeometry() {if (!documents.length) {return jamJSON.stringify({"error": "layer","signature": ""});}var e = null;var t = null;var r = null;try {e = _getActiveLayerId();} catch (e) {}try {t = _getActiveHistoryIndex();} catch (e) {}try {r = _getCurrentTextLayerBounds();} catch (e) {}if (e === null || !r) {return jamJSON.stringify({"error": "layer","signature": ""});}return jamJSON.stringify({"layerId": e,"bounds": r,"signature": String(e) + ":" + String(t)});}function getTypeRSelectionSnapshot() {var e = null;var t = {"layers": []};try {e = jamJSON.parse(getCurrentSelection());} catch (e) {}try {t = jamJSON.parse(getSelectedTextLayers()) || t;} catch (e) {}return jamJSON.stringify({"selection": e && !e.error ? e : null,"layers": t.layers || []});}function getTypeRPanelSnapshot(e) {var t = null;var r = {"selection": null,"layers": []};try {t = jamJSON.parse(getActiveLayerTextIfChanged(e || {}));} catch (e) {}try {r = jamJSON.parse(getTypeRSelectionSnapshot()) || r;} catch (e) {}return jamJSON.stringify({"activeLayer": t,"selection": r.selection,"layers": r.layers || []});}function _getTargetLayerCount() {var e = stringIDToTypeID("targetLayers");var t = new ActionReference();t.putProperty(charID.Property, e);t.putEnumerated(charID.Document, charID.Ordinal, charID.Target);var r = executeActionGet(t);if (!r.hasKey(e)) return 1;return r.getList(e).count;}function selectLayerById(e) {try {var t = parseInt(e, 10);if (isNaN(t)) return "error";var r = new ActionDescriptor();var a = new ActionReference();a.putIdentifier(charID.Layer, t);r.putReference(charID.Null, a);r.putBoolean(stringIDToTypeID("makeVisible"), false);executeAction(charID.Select, r, DialogModes.NO);return "";} catch (e) {return "error";}}function startSelectionMonitoring() {var e = _hostState.selectionMonitor;if (e.callback) {app.removeNotifier("Slct", e.callback);e.callback = null;}}function stopSelectionMonitoring() {var e = _hostState.selectionMonitor;if (e.callback) {app.removeNotifier("Slct", e.callback);e.callback = null;}e.lastBoundsKey = null;e.lastBounds = null;e.multiWarnBounds = null;}function deselectDocumentSelection() {try {if (!documents.length) return "doc";try {_deselect();} catch (e) {}var e = _hostState.selectionMonitor;e.lastBounds = null;e.lastBoundsKey = null;e.multiWarnBounds = null;return "";} catch (e) {return "error";}}function _getActiveHistoryIndex() {var e = new ActionReference();e.putEnumerated(stringIDToTypeID("historyState"), charID.Ordinal, charID.Target);var t = executeActionGet(e);return t.getInteger(stringIDToTypeID("itemIndex")) - 1;}function undoLastTyperChange() {try {if (!documents.length) return "doc";var e = app.activeDocument;var t = e.historyStates;if (!t.length) return "none";var r;try {r = _getActiveHistoryIndex();} catch (e) {r = t.length - 1;}if (r < 0) r = 0;if (r > t.length - 1) r = t.length - 1;for (var a = r; a > 0; a--) {if (t[a].name === "TyperTools Change") {e.activeHistoryState = t[a - 1];return "";}}return "none";} catch (e) {return "error";}}function getTypeRDocumentKey() {return documents.length ? _hostState.documentSession + ":" + String(app.activeDocument.id) : "";}function getSelectionChanged() {var e = _hostState.selectionMonitor;var t = getTypeRDocumentKey();if (e.documentKey !== t) {e.documentKey = t;e.lastBoundsKey = null;e.lastBounds = null;e.multiWarnBounds = null;return jamJSON.stringify({"documentChanged": true,"documentKey": t});}var r = jamJSON.parse(_getSelectionChanged());r.documentKey = t;var a = r.multiSelection || [];for (var n = 0; n < a.length; n++) a[n].documentKey = t;return jamJSON.stringify(r);}function _getSelectionChanged() {try {var e = _hostState.selectionMonitor;var t = ScriptUI.environment && ScriptUI.environment.keyboardState;var r = !!(t && t.shiftKey);var a = _getCurrentSelectionBounds();if (!a) {e.multiWarnBounds = null;return jamJSON.stringify({"noChange": true,"shiftKey": r});}var n = Object.prototype.toString.call(a) === "[object Array]" ? a : [ a ];var i = [];for (var o = 0; o < n.length; o++) {if (n[o].width < 2 && n[o].height < 2) continue;i.push([ n[o] ]);}var s = true;var c = 30;while (s) {s = false;for (var l = 0; l < i.length; l++) {for (var u = l + 1; u < i.length; u++) {var p = false;for (var y = 0; y < i[l].length; y++) {for (var f = 0; f < i[u].length; f++) {var h = i[l][y];var g = i[u][f];if (!(h.right + c < g.left - c || h.left - c > g.right + c || h.bottom + c < g.top - c || h.top - c > g.bottom + c)) {p = true;break;}}if (p) break;}if (p) {i[l] = i[l].concat(i[u]);i.splice(u, 1);s = true;break;}}if (s) break;}}var d = [];for (var v = 0; v < i.length; v++) {var m = i[v];var T = 99999;var I = 99999;var D = -99999;var b = -99999;for (var S = 0; S < m.length; S++) {if (m[S].left < T) T = m[S].left;if (m[S].top < I) I = m[S].top;if (m[S].right > D) D = m[S].right;if (m[S].bottom > b) b = m[S].bottom;}var x = D - T;var _ = b - I;if (x > 2 && _ > 2) {d.push({"top": I,"left": T,"right": D,"bottom": b,"width": x,"height": _,"xMid": (T + D) / 2,"yMid": (I + b) / 2});}}if (d.length === 0) {return jamJSON.stringify({"noChange": true,"shiftKey": r});}var k = false;if (e.lastBounds && d.length === 1) {var j = Math.abs(d[0].top - e.lastBounds.top);var L = Math.abs(d[0].left - e.lastBounds.left);var E = Math.abs(d[0].right - e.lastBounds.right);var C = Math.abs(d[0].bottom - e.lastBounds.bottom);if (j <= 5 && L <= 5 && E <= 5 && C <= 5) {k = true;}}if (k && !r) {return jamJSON.stringify({"noChange": true,"shiftKey": r});}if (e.multiWarnBounds && d.length === 1 && Math.abs(d[0].top - e.multiWarnBounds.top) <= 5 && Math.abs(d[0].left - e.multiWarnBounds.left) <= 5 && Math.abs(d[0].right - e.multiWarnBounds.right) <= 5 && Math.abs(d[0].bottom - e.multiWarnBounds.bottom) <= 5) {return jamJSON.stringify({"noChange": true,"shiftKey": r});}if (r && !k && e.lastBounds && d.length === 1 && d[0].top <= e.lastBounds.top + 5 && d[0].left <= e.lastBounds.left + 5 && d[0].right >= e.lastBounds.right - 5 && d[0].bottom >= e.lastBounds.bottom - 5) {e.multiWarnBounds = d[0];return jamJSON.stringify({"multipleSelections": true,"shiftKey": r});}e.multiWarnBounds = null;var A = d;if (d.length === 1) {var w = _withTemporaryHistory("TypeR Selection Capture", function() {return _getAdaptiveOpenedSelectionBounds(d[0]);});A = [ w && !w.error ? w : d[0] ];}e.lastBounds = d[0];e.lastBoundsKey = _selectionBoundsKey(d[0]);var O = [];for (var P = 0; P < A.length; P++) {O.push({"shiftKey": r,"top": A[P].top,"left": A[P].left,"right": A[P].right,"bottom": A[P].bottom,"width": A[P].width,"height": A[P].height,"xMid": A[P].xMid,"yMid": A[P].yMid});}return jamJSON.stringify({"multiSelection": O,"shiftKey": r,"top": A[0].top,"left": A[0].left,"right": A[0].right,"bottom": A[0].bottom,"width": A[0].width,"height": A[0].height,"xMid": A[0].xMid,"yMid": A[0].yMid});} catch (e) {return jamJSON.stringify({"error": true,"message": "getSelectionChanged inner error: " + e.message + " on line " + e.line,"shiftKey": false});}}function _createTextLayersInStoredSelections() {var t = _hostState.createTextLayersInStoredSelections;if (!documents.length) {t.result = "doc";return;}var e = null;if (t.data.preserveActiveTextSize) {if (!_layerIsTextLayer()) {t.result = "sizeSource";return;}e = _getTextLayerSize();}var r = t.data.texts || [];var a = t.data.styles || [];if (r.length === 0 || t.selections.length === 0) {t.result = "noSelection";return;}var n = Math.min(r.length, t.selections.length);var i = _autoCenterEnabled(t.data);var o = [];for (var s = 0; s < n; s++) {try {var c = r[s] || r[r.length - 1] || "";var l = t.data.richTextRuns ? t.data.richTextRuns[s] || t.data.richTextRuns[t.data.richTextRuns.length - 1] : null;var u = a[s] || a[a.length - 1] || null;var p = _ensureStyle(u);var y = t.selections[s];if (!y || typeof y.width !== "number" || typeof y.height !== "number") {t.result = "invalidSelection";return;}if (!c) continue;var f = _calculateSelectionDimensions(y, t.padding);if (!f || isNaN(f.width) || isNaN(f.height) || f.width <= 0 || f.height <= 0) {t.result = "invalidSelection";return;}var h = {"text": c,"style": p,"direction": t.data.direction,"richTextRuns": l,"textSizeOverride": e};f = _punctuationOnlyBoxDimensions(f, h);_createAndSetLayerText(h, f.width, f.height);var g = _getCurrentTextLayerBounds();var d = t.data.pointModes || [];var v = true;if (v) {_changeToPointText();} else {_resizeTextBoxToContent(f.width, g);}g = _getCurrentTextLayerBounds();_positionLayerWithinSelection(y, g);if (i) o.push(_safeActiveLayerId());} catch (e) {t.result = "scriptError: " + (e && e.message ? e.message : e);return;}}if (i) {_autoCenterCreated(o, {"autoCenter": t.data.autoCenter,"resizeTextBox": t.data.resizeTextBox,"padding": t.padding});}t.selections = [];t.result = "";}function createTextLayersInStoredSelections(e, t) {var r = _hostState.createTextLayersInStoredSelections;r.data = e;r.point = t;r.padding = e.padding || 0;r.result = "";if (e && e.selections) {r.selections = e.selections;} else {r.selections = [];}if (!documents.length) return "doc";var a = getTypeRDocumentKey();var n = r.selections.length;if (!n || !e.texts || e.texts.length !== n) return "noSelection";for (var i = 0; i < n; i++) {var o = r.selections[i];if (!o || !o.documentKey || o.documentKey !== a) return "wrongDocument";if (!e.texts[i]) return "noText";var s = _calculateSelectionDimensions(o, r.padding);if (!s || !isFinite(s.width) || !isFinite(s.height) || s.width <= 0 || s.height <= 0) return "invalidSelection";}var c = app.activeDocument;var l = c.activeHistoryState;try {c.suspendHistory("TyperTools Multiple Paste", "_createTextLayersInStoredSelections()");} catch (e) {r.result = "scriptError: " + e.message;}if (r.result) {try {c.activeHistoryState = l;} catch (e) {return "rollbackFailed";}}return r.result;}function openFile(t, e) {try {var r = File(t);if (!r.exists) throw new Error("File not found");var a = _hostState.lastOpenedDocId;var n = app.open(r);if (e && a !== null && a !== n.id) {for (var i = 0; i < app.documents.length; i++) {var o = app.documents[i];if (o.id === a) {try {o.close(SaveOptions.SAVECHANGES);} catch (e) {app.activeDocument = o;throw e;}break;}}}app.activeDocument = n;_hostState.lastOpenedDocId = n.id;return jamJSON.stringify({"ok": true,"path": t,"documentKey": getTypeRDocumentKey()});} catch (e) {return jamJSON.stringify({"ok": false,"path": t,"error": String(e.message || e)});}}function deleteFolder(e) {try {var t = new Folder(e);if (t.exists) {var r = t.getFiles();for (var a = 0; a < r.length; a++) {if (r[a] instanceof Folder) {deleteFolder(r[a].fsName);} else {r[a].remove();}}t.remove();}return "OK";} catch (e) {return "ERROR: " + e.message;}}function openFolder(e) {try {var t = $.os.toLowerCase();if (t.indexOf("win") !== -1) {app.system('explorer "' + e.replace(/\//g, "\\") + '"');} else {app.system('open "' + e + '"');}return "OK";} catch (e) {return "ERROR: " + e.message;}}function _collectDocumentFontData(e) {var t = [];var a = charIDToTypeID("Prpr");var n = charIDToTypeID("Lyr ");var r = charIDToTypeID("Dcmn");var i = charIDToTypeID("Ordn");var o = charIDToTypeID("Trgt");var s = charIDToTypeID("Nm  ");var c = stringIDToTypeID("layerKind");var l = stringIDToTypeID("numberOfLayers");var u = stringIDToTypeID("hasBackgroundLayer");var p = function(e) {var t = new ActionReference();t.putProperty(a, e);t.putEnumerated(r, i, o);return executeActionGet(t);};var y = function(e, t) {var r = new ActionReference();r.putProperty(a, e);r.putIndex(n, t);return executeActionGet(r);};var f = 0;try {f = p(l).getInteger(l);} catch (e) {return t;}var h = false;try {h = p(u).getBoolean(u);} catch (e) {}var g = h ? 0 : 1;var d = h ? f - 1 : f;var v = jamEngine.meaningfulIds;var m = jamEngine.parseFriendly;jamEngine.meaningfulIds = true;jamEngine.parseFriendly = true;try {for (var T = g; T <= d; T++) {try {if (y(c, T).getInteger(c) !== 3) continue;var I = jamEngine.jsonGet([ {"property": {"<property>": "textKey"}}, {"layer": {"<index>": T}} ]);if (!("textKey" in I)) continue;var D = jamText.fromLayerTextObject(I["textKey"]);if (!D || !D.layerText) continue;var b = D.layerText;var S = b.textStyleRange || [];var x = [];for (var _ = 0; _ < S.length; _++) {if (S[_] && S[_].textStyle) x.push(S[_].textStyle);}if (!x.length) continue;var k = null;if (b.paragraphStyleRange && b.paragraphStyleRange[0]) {k = b.paragraphStyleRange[0].paragraphStyle || null;}var j = null;try {j = _getLayerStroke(T);} catch (e) {}var L = "";try {L = y(s, T).getString(s);} catch (e) {}t.push({"layerName": L,"antiAlias": b.antiAlias || "antiAliasSmooth","typeUnit": D.typeUnit || "pixelsUnit","paragraphStyle": k,"stroke": j,"runs": x});} catch (e) {}}} finally {jamEngine.meaningfulIds = v;jamEngine.parseFriendly = m;}return t;}function scanPsdFonts(t) {if (!t) return jamJSON.stringify({"error": "badPath"});var e = new File(t);if (!e.exists) return jamJSON.stringify({"error": "notFound","file": t});var r = null;var a = false;for (var n = 0; n < app.documents.length; n++) {try {if (app.documents[n].fullName && app.documents[n].fullName.fsName === e.fsName) {r = app.documents[n];a = true;break;}} catch (e) {}}var i = null;try {i = app.activeDocument;} catch (e) {}var o = app.displayDialogs;app.displayDialogs = DialogModes.NO;try {if (r) {app.activeDocument = r;} else {r = app.open(e);}var s = _collectDocumentFontData(r);if (!a) {r.close(SaveOptions.DONOTSAVECHANGES);if (i) {try {app.activeDocument = i;} catch (e) {}}}return jamJSON.stringify({"file": e.fsName,"layers": s});} catch (e) {if (r && !a) {try {r.close(SaveOptions.DONOTSAVECHANGES);} catch (e) {}}return jamJSON.stringify({"error": "scanFailed","file": t,"message": e && e.message ? e.message : String(e)});} finally {app.displayDialogs = o;}}function _listActionSetCount() {var e = 0;for (var t = 1; t < 2e3; t++) {var r = new ActionReference();r.putIndex(charIDToTypeID("ASet"), t);try {executeActionGet(r);e = t;} catch (e) {break;}}return e;}function _actionSetInfo(e) {var t = new ActionReference();t.putIndex(charIDToTypeID("ASet"), e);var r = executeActionGet(t);var a = r.getString(charIDToTypeID("Nm  "));var n = r.hasKey(charIDToTypeID("NmbC")) ? r.getInteger(charIDToTypeID("NmbC")) : 0;var i = [];for (var o = 1; o <= n; o++) {var s = new ActionReference();s.putIndex(charIDToTypeID("Actn"), o);s.putIndex(charIDToTypeID("ASet"), e);try {i.push(executeActionGet(s).getString(charIDToTypeID("Nm  ")));} catch (e) {i.push("Action " + o);}}return {"name": a,"actions": i};}function _playActionByIndex(e, t) {var r = new ActionReference();r.putIndex(charIDToTypeID("Actn"), t);r.putIndex(charIDToTypeID("ASet"), e);var a = new ActionDescriptor();a.putReference(charIDToTypeID("null"), r);executeAction(charIDToTypeID("Ply "), a, DialogModes.NO);}function _deleteActionSetByIndex(e) {var t = new ActionReference();t.putIndex(charIDToTypeID("ASet"), e);var r = new ActionDescriptor();r.putReference(charIDToTypeID("null"), t);executeAction(charIDToTypeID("Dlt "), r, DialogModes.NO);}function scanActionFonts(t) {if (!t) return jamJSON.stringify({"error": "badPath"});var e = new File(t);if (!e.exists) return jamJSON.stringify({"error": "notFound","file": t});var r = null;var a = 300;try {r = app.activeDocument;a = r.resolution || 300;} catch (e) {}var n = app.displayDialogs;var i = null;app.displayDialogs = DialogModes.NO;var o = null;var s = 0;var c = 0;var l = [];try {var u = _listActionSetCount();app.load(e);var p = _listActionSetCount();s = u + 1;c = p;if (p <= u) return jamJSON.stringify({"error": "scanFailed","file": t,"message": "no action set loaded"});o = app.documents.add(800, 800, a, "TypeR action scan", NewDocumentMode.RGB, DocumentFill.WHITE);for (var y = s; y <= c; y++) {var f = _actionSetInfo(y);for (var h = 0; h < f.actions.length; h++) {try {app.activeDocument = o;var g = o.artLayers.add();g.kind = LayerKind.TEXT;g.textItem.contents = "A";_playActionByIndex(y, h + 1);var d = _collectDocumentFontData(o);for (var v = 0; v < d.length; v++) {d[v].layerName = f.name + " / " + f.actions[h];l.push(d[v]);}} catch (e) {}try {while (o.layers.length > 1) o.layers[0].remove();} catch (e) {}}}return jamJSON.stringify({"file": e.fsName,"layers": l});} catch (e) {return jamJSON.stringify({"error": "scanFailed","file": t,"message": e && e.message ? e.message : String(e)});} finally {if (o) {try {o.close(SaveOptions.DONOTSAVECHANGES);} catch (e) {}}if (r) {try {app.activeDocument = r;} catch (e) {}}for (var m = c; m >= s && s > 0; m--) {try {_deleteActionSetByIndex(m);} catch (e) {}}app.displayDialogs = n;}}var _imageLayerState = {};function _activeLayerHasUserMask() {var e = new ActionReference();e.putProperty(charIDToTypeID("Prpr"), stringIDToTypeID("hasUserMask"));e.putEnumerated(charIDToTypeID("Lyr "), charIDToTypeID("Ordn"), charIDToTypeID("Trgt"));var t = executeActionGet(e);return t.hasKey(stringIDToTypeID("hasUserMask")) && t.getBoolean(stringIDToTypeID("hasUserMask"));}function _makeUserMaskRevealAll() {var e = new ActionDescriptor();e.putClass(charIDToTypeID("Nw  "), charIDToTypeID("Chnl"));var t = new ActionReference();t.putEnumerated(charIDToTypeID("Chnl"), charIDToTypeID("Chnl"), charIDToTypeID("Msk "));e.putReference(charIDToTypeID("At  "), t);e.putEnumerated(charIDToTypeID("Usng"), charIDToTypeID("UsrM"), charIDToTypeID("RvlA"));executeAction(charIDToTypeID("Mk  "), e, DialogModes.NO);}function _loadActiveLayerTransparency() {var e = new ActionDescriptor();var t = new ActionReference();t.putProperty(charIDToTypeID("Chnl"), charIDToTypeID("fsel"));e.putReference(charIDToTypeID("null"), t);var r = new ActionReference();r.putEnumerated(charIDToTypeID("Chnl"), charIDToTypeID("Chnl"), charIDToTypeID("Trsp"));e.putReference(charIDToTypeID("T   "), r);executeAction(charIDToTypeID("setd"), e, DialogModes.NO);}function _makeUserMaskFromSelection(e) {var t = new ActionDescriptor();t.putClass(charIDToTypeID("Nw  "), charIDToTypeID("Chnl"));var r = new ActionReference();r.putEnumerated(charIDToTypeID("Chnl"), charIDToTypeID("Chnl"), charIDToTypeID("Msk "));t.putReference(charIDToTypeID("At  "), r);t.putEnumerated(charIDToTypeID("Usng"), charIDToTypeID("UsrM"), charIDToTypeID(e ? "HdSl" : "RvlS"));executeAction(charIDToTypeID("Mk  "), t, DialogModes.NO);}function _deleteUserMask() {var e = new ActionDescriptor();var t = new ActionReference();t.putEnumerated(charIDToTypeID("Chnl"), charIDToTypeID("Chnl"), charIDToTypeID("Msk "));e.putReference(charIDToTypeID("null"), t);e.putBoolean(charIDToTypeID("Aply"), false);executeAction(charIDToTypeID("Dlt "), e, DialogModes.NO);}function _placeImageFile(e) {var t = new ActionDescriptor();t.putPath(charIDToTypeID("null"), e);t.putEnumerated(charIDToTypeID("FTcs"), charIDToTypeID("QCSt"), charIDToTypeID("Qcsa"));var r = new ActionDescriptor();r.putUnitDouble(charIDToTypeID("Hrzn"), charIDToTypeID("#Pxl"), 0);r.putUnitDouble(charIDToTypeID("Vrtc"), charIDToTypeID("#Pxl"), 0);t.putObject(charIDToTypeID("Ofst"), charIDToTypeID("Ofst"), r);executeAction(charIDToTypeID("Plc "), t, DialogModes.NO);}function _placeImageCovering(e, t) {var r = app.activeDocument;_placeImageFile(e);var a = r.activeLayer;var n = a.bounds;var i = n[0].as("px");var o = n[1].as("px");var s = n[2].as("px") - i;var c = n[3].as("px") - o;if (s > 0 && c > 0) {var l = Math.max(t.w / s, t.h / c) * 100;a.resize(l, l, AnchorPosition.MIDDLECENTER);n = a.bounds;var u = t.l + t.w / 2 - (n[0].as("px") + n[2].as("px")) / 2;var p = t.t + t.h / 2 - (n[1].as("px") + n[3].as("px")) / 2;a.translate(u, p);}return a;}function _activeLayerRect() {var e = app.activeDocument.activeLayer;var t = e.bounds;var r = t[0].as("px");var a = t[1].as("px");return {"l": r,"t": a,"w": t[2].as("px") - r,"h": t[3].as("px") - a};}function _imageToLayerClipRun() {var t = _imageLayerState;try {var e = app.activeDocument;var r = e.activeLayer;if (r.isBackgroundLayer) {t.error = "backgroundLayer";return;}var a = _activeLayerRect();if (!(a.w > 0) || !(a.h > 0)) {t.error = "emptyLayer";return;}var n = _placeImageCovering(new File(t.path), a);n.rasterize(RasterizeType.ENTIRELAYER);n.name = t.name;n.grouped = true;} catch (e) {t.error = "failed";t.message = e && e.message ? e.message : String(e);}}function _imageToLayerMaskRun() {var t = _imageLayerState;try {var e = app.activeDocument;var r = e.activeLayer;var a = null;try {a = _saveSelectionState();} catch (e) {}var n = _placeImageCovering(new File(t.path), t.rect);n.rasterize(RasterizeType.ENTIRELAYER);_loadActiveLayerTransparency();var i = true;try {var o = e.selection.bounds;} catch (e) {i = false;}if (!i) {n.remove();e.activeLayer = r;t.error = "emptyImage";return;}e.activeLayer = r;if (_activeLayerHasUserMask()) _deleteUserMask();_makeUserMaskFromSelection(!!t.invert);try {e.selection.deselect();} catch (e) {}n.remove();e.activeLayer = r;if (a) {try {_restoreSelectionState(a, false);} catch (e) {}}} catch (e) {t.error = "failed";t.message = e && e.message ? e.message : String(e);}}function applyImageToLayer(e) {if (!e || !e.path) return jamJSON.stringify({"error": "badPath"});var t = new File(e.path);if (!t.exists) return jamJSON.stringify({"error": "notFound","file": e.path});var r = null;try {r = app.activeDocument;} catch (e) {return jamJSON.stringify({"error": "noDocument"});}var a = e.mode === "mask" ? "mask" : "clip";_imageLayerState = {"path": e.path,"mode": a,"invert": !!e.invert,"name": decodeURI(t.name).replace(/\.[^.]*$/, "")};var n = _imageLayerState;var i = app.preferences.rulerUnits;var o = app.displayDialogs;app.preferences.rulerUnits = Units.PIXELS;app.displayDialogs = DialogModes.NO;try {var s = r.activeLayer;if (s.isBackgroundLayer) {n.error = "backgroundLayer";} else {var c = _activeLayerRect();if (!(c.w > 0) || !(c.h > 0)) {n.error = "emptyLayer";} else if (a === "mask") {n.rect = c;r.suspendHistory(n.invert ? "TypeR Mask (outer)" : "TypeR Mask", "_imageToLayerMaskRun()");} else {r.suspendHistory("TypeR Clipping Mask", "_imageToLayerClipRun()");}}} catch (e) {n.error = "failed";n.message = e && e.message ? e.message : String(e);} finally {app.preferences.rulerUnits = i;app.displayDialogs = o;}if (n.error) return jamJSON.stringify({"error": n.error,"message": n.message || ""});return jamJSON.stringify({"ok": true});}function makeExecutable(e) {try {var t = $.os.toLowerCase();if (t.indexOf("mac") !== -1) {app.system('chmod +x "' + e + '"');}return "OK";} catch (e) {return "ERROR: " + e.message;}}function launchInstaller(e) {try {var t = new File(e);if (!t.exists) {return "ERROR: file not found";}var r = t.execute();if (r) return "OK";var a = $.os.toLowerCase();if (a.indexOf("mac") !== -1) {app.system('open "' + t.fsName + '"');return "OK";}return "ERROR: execute failed";} catch (e) {return "ERROR: " + e.message;}}var _SMART_CLEAN_LAYER = "TypeR Clean";var _SMART_HISTORY_NAME = "TyperTools Smart Paste";function _smartUnit(e, t, r) {var a = e.getUnitDoubleType(t);var n = "pixelsUnit";if (a === r.distance || a === r.points) n = "distanceUnit";return {"_unit": n,"_value": e.getUnitDoubleValue(t)};}function _smartPathPoint(e, t) {return {"horizontal": _smartUnit(e, charID.Horizontal, t),"vertical": _smartUnit(e, charID.Vertical, t)};}function _smartReadPath(e, t) {var r = executeActionGet(e);var a = stringIDToTypeID("pathContents");if (!r.hasKey(a)) return null;var n = r.getObjectValue(a);var i = n.getList(stringIDToTypeID("pathComponents"));var o = {"distance": charIDToTypeID("#Rlt"),"points": charIDToTypeID("#Pnt")};var s = stringIDToTypeID("subpathListKey");var c = stringIDToTypeID("points");var l = stringIDToTypeID("anchor");var u = stringIDToTypeID("forward");var p = stringIDToTypeID("backward");var y = stringIDToTypeID("closedSubpath");var f = [];var h = 0;for (var g = 0; g < i.count; g++) {var d = i.getObjectValue(g);var v = d.getList(s);var m = [];for (var T = 0; T < v.count; T++) {var I = v.getObjectValue(T);var D = I.getList(c);var b = [];h += D.count;if (h > t) throw new Error("pathBudget");for (var S = 0; S < D.count; S++) {var x = D.getObjectValue(S);var _ = {"anchor": _smartPathPoint(x.getObjectValue(l), o)};if (x.hasKey(u)) _.forward = _smartPathPoint(x.getObjectValue(u), o);if (x.hasKey(p)) _.backward = _smartPathPoint(x.getObjectValue(p), o);b.push(_);}m.push({"closedSubpath": I.hasKey(y) && I.getBoolean(y),"points": b});}f.push({"subpathListKey": m});}return {"pathContents": {"pathComponents": f}};}function _smartReadWorkPath() {var e = new ActionReference();e.putProperty(charID.Path, charIDToTypeID("WrPt"));return _smartReadPath(e, 4096);}function _smartAtlasMetrics(e, t) {if (!(t >= 1 && t <= 24 && t === Math.floor(t))) return null;var r = _getDocumentPixelSize();var a = _getDocumentResolution();var n = r.width / 2;var i = r.height / 2;var o = [];var s, c, l, u, p;for (s = 0; s < t; s++) o.push({"left": Infinity,"top": Infinity,"right": -Infinity,"bottom": -Infinity});var y = e && e.pathContents && e.pathContents.pathComponents;if (!y) return null;var f = [ "anchor", "forward", "backward" ];for (c = 0; c < y.length; c++) {var h = y[c].subpathListKey || [];for (l = 0; l < h.length; l++) {var g = h[l].points || [];var d = Infinity, v = Infinity, m = -Infinity, T = -Infinity;for (u = 0; u < g.length; u++) {for (p = 0; p < f.length; p++) {var I = g[u][f[p]];if (!I || !I.horizontal || !I.vertical) continue;if (I.horizontal._unit !== "pixelsUnit" && I.horizontal._unit !== "distanceUnit" || I.vertical._unit !== "pixelsUnit" && I.vertical._unit !== "distanceUnit") return null;var D = I.horizontal._unit === "distanceUnit" ? I.horizontal._value * a / 72 : I.horizontal._value;var b = I.vertical._unit === "distanceUnit" ? I.vertical._value * a / 72 : I.vertical._value;if (!isFinite(D) || !isFinite(b)) return null;d = Math.min(d, D);m = Math.max(m, D);v = Math.min(v, b);T = Math.max(T, b);}}if (!isFinite(d)) continue;var S = Math.floor(((v + T) / 2 - i + 128) / 256);if (S < 0 || S >= t || v < i + S * 256 - 128 || T > i + S * 256 + 128) return null;o[S].left = Math.min(o[S].left, d);o[S].right = Math.max(o[S].right, m);o[S].top = Math.min(o[S].top, v);o[S].bottom = Math.max(o[S].bottom, T);}}for (s = 0; s < o.length; s++) {var x = o[s];if (!(x.right > x.left && x.bottom > x.top)) return null;o[s] = {"left": (x.left - n - 1) / 64,"right": (x.right - n + 1) / 64,"top": (x.top - (i + s * 256) - 1) / 64,"bottom": (x.bottom - (i + s * 256) + 1) / 64};}return o;}function _smartReadChannelHistograms() {var e = [];var t = app.activeDocument.componentChannels;for (var r = 0; r < t.length && r < 3; r++) e.push(t[r].histogram);return e;}function _smartSelectionHistograms() {try {return _smartReadChannelHistograms();} catch (e) {}try {var e = new ActionDescriptor();e.putBoolean(charIDToTypeID("Dplc"), true);executeAction(charIDToTypeID("MrgV"), e, DialogModes.NO);return _smartReadChannelHistograms();} catch (e) {return [];}}function smartPasteCapture(e) {if (!app.documents.length) return jamJSON.stringify({"error": "doc"});if (e && e.trigger && e.trigger.documentKey && e.trigger.documentKey !== getTypeRDocumentKey()) return jamJSON.stringify({"error": "doc"});var t = _getCurrentSelectionBounds();if (!t || t.width < 8 || t.height < 8) return jamJSON.stringify({"error": "noSelection"});var r = app.activeDocument;var a = _getDocumentPixelSize();var n = {"documentId": r.id,"width": a.width,"height": a.height,"resolution": _getDocumentResolution(),"selectionBounds": {"left": t.left,"top": t.top,"right": t.right,"bottom": t.bottom},"histograms": [],"rawPath": null,"activeTextSize": null};if (e && e.keepSize) {try {if (_layerIsTextLayer()) n.activeTextSize = _getTextLayerSize();} catch (e) {}}var i = !e || !e.trigger || e.trigger.source !== "rectangle";var o = _withTemporaryHistory("TypeR Read Bubble", function() {var e = _smartSelectionHistograms();var t = null;if (i) {_makeWorkPathFromSelection(2);t = _smartReadWorkPath();}return {"path": t,"histograms": e};}, {"discardRedo": true});if (!o || o.error || i && !o.path) return jamJSON.stringify({"error": "shape"});n.rawPath = o.path;n.histograms = o.histograms || [];return jamJSON.stringify(n);}function _smartCreateMeasureGroup() {var e = new ActionReference();e.putClass(stringIDToTypeID("layerSection"));var t = new ActionDescriptor();t.putReference(charID.Null, e);var r = new ActionDescriptor();r.putUnitDouble(stringIDToTypeID("opacity"), stringIDToTypeID("percentUnit"), 0);t.putObject(stringIDToTypeID("using"), stringIDToTypeID("layerSection"), r);executeAction(charID.Make, t, DialogModes.NO);var a = app.activeDocument.activeLayer;if (a.opacity !== 0) a.visible = false;return a;}function smartPasteMeasure(e) {if (!app.documents.length) return jamJSON.stringify({"error": "doc"});var h = e && e.requests || [];if (!h.length) return jamJSON.stringify([]);var t = _withTemporaryHistory("TypeR text measurement", function() {var t = [];var e = false;var r = _smartCreateMeasureGroup();try {for (var a = 0; a < h.length; a++) {var n = h[a];var i = n.params;if (n.kind === "atlas" && i.typeUnit === "pixelsUnit") {i = _clone(i);var o = i.layerText.textStyleRange || [];var s = _getDocumentResolution() / 72;for (var c = 0; c < o.length; c++) {var l = o[c].textStyle;if (l && typeof l.leading === "number") l.leading *= s;}}var u = jamText.toLayerTextObject(i);if (!e) {executeAction(charID.Make, jamEngine.jsonToActionDescriptor({"target": [ "<reference>", [ [ "textLayer", [ "<class>", null ] ] ] ],"using": u}), DialogModes.NO);e = true;} else {executeAction(charID.Set, jamEngine.jsonToActionDescriptor({"target": [ "<reference>", [ [ "layer", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ],"to": u}), DialogModes.NO);}if (n.kind === "atlas") {try {executeAction(charID.Make, jamEngine.jsonToActionDescriptor({"target": [ "<reference>", [ [ "contentLayer", [ "<class>", null ] ] ] ],"using": [ "<reference>", [ [ "textLayer", [ "<enumerated>", [ "ordinal", "targetEnum" ] ] ] ] ]}), DialogModes.NO);var p = new ActionReference();p.putEnumerated(charID.Path, charID.Path, stringIDToTypeID("vectorMask"));t.push({"metrics": _smartAtlasMetrics(_smartReadPath(p, 65536), n.count)});} catch (e) {t.push(null);}var y = app.activeDocument.activeLayer;if (y.parent !== r) throw new Error("measureLayer");if (a + 1 < h.length) {y.remove();app.activeDocument.activeLayer = r;}e = false;} else {var f = _currentLayerBox();t.push(f ? {"bounds": {"left": f.left,"top": f.top,"right": f.right,"bottom": f.bottom}} : null);}}return {"replies": t};} finally {r.remove();}}, {"discardRedo": true});if (!t || t.error || !t.replies) return jamJSON.stringify({"error": "measure"});return jamJSON.stringify(t.replies);}function _smartSelectPolygon(e) {var t = new ActionDescriptor();var r = new ActionReference();r.putProperty(charID.Channel, charID.FrameSelect);t.putReference(charID.Null, r);var a = new ActionDescriptor();var n = new ActionList();for (var i = 0; i < e.length; i++) {var o = new ActionDescriptor();o.putUnitDouble(charID.Horizontal, charID.PixelUnit, e[i][0]);o.putUnitDouble(charID.Vertical, charID.PixelUnit, e[i][1]);n.putObject(charIDToTypeID("Pnt "), o);}a.putList(charIDToTypeID("Pts "), n);t.putObject(charID.To, charIDToTypeID("Plgn"), a);executeAction(charIDToTypeID("setd"), t, DialogModes.NO);}function _smartCleanLayer() {var e = app.activeDocument;var t = e.layers;var r = null;for (var a = 0; a < t.length; a++) {var n = t[a];if (n.typename !== "ArtLayer") continue;if (n.name === _SMART_CLEAN_LAYER && n.kind === LayerKind.NORMAL) return n;if (!r && n.kind !== LayerKind.TEXT) r = n;}if (r) e.activeLayer = r;var i = e.artLayers.add();i.name = _SMART_CLEAN_LAYER;return i;}function _smartPaintCleanup(e) {var t = app.activeDocument;t.activeLayer = _smartCleanLayer();_smartSelectPolygon(e.cleanupPolygon);if (e.cleanupInset > 0) t.selection.contract(new UnitValue(e.cleanupInset, "px"));var r = e.fillRGB || {"red": 255,"green": 255,"blue": 255};var a = new SolidColor();a.rgb.red = r.red;a.rgb.green = r.green;a.rgb.blue = r.blue;t.selection.fill(a, ColorBlendMode.NORMAL, 100, false);t.selection.deselect();}function _smartMakeText(t) {try {jamEngine.jsonPlay("make", {"target": [ "<reference>", [ [ "textLayer", [ "<class>", null ] ] ] ],"using": jamText.toLayerTextObject(t)});} catch (e) {var r = t.layerText.paragraphStyleRange || [];var a = null;for (var n = 0; n < r.length; n++) {if (!r[n].paragraphStyle) continue;if (r[n].paragraphStyle.directionType) {a = r[n].paragraphStyle.directionType === "dirRightToLeft" ? "rtl" : "ltr";}delete r[n].paragraphStyle.directionType;delete r[n].paragraphStyle.textComposerEngine;}jamEngine.jsonPlay("make", {"target": [ "<reference>", [ [ "textLayer", [ "<class>", null ] ] ] ],"using": jamText.toLayerTextObject(t)});_applyTextDirection(a);}}function _smartPlaceText(e, t) {t = true;var r = e.text.params;_smartMakeText(r);_raiseNewTextLayer();var a = r.layerText.textStyleRange;if (a && a[0]) _applyMiddleEast(a[0].textStyle);if (!t) {var n = _currentLayerBox();_changeToBoxText();var i = _currentLayerBox();if (n && i) {if (Math.abs(n.width - i.width) > 1.5 || Math.abs(n.height - i.height) > 1.5) {_changeToPointText();var o = _currentLayerBox();if (o) _moveLayer(n.left - o.left, n.top - o.top);} else if (Math.abs(n.left - i.left) > .01 || Math.abs(n.top - i.top) > .01) {_moveLayer(n.left - i.left, n.top - i.top);}}}if (e.text.stroke) _setLayerStroke(e.text.stroke);return _getActiveLayerId();}function _smartPasteCommitRun() {var t = _hostState.smartCommit;var e = t.data.sessions || [];try {for (var r = 0; r < e.length; r++) {var a = e[r].plan;if (a.autoClean && a.cleanupPolygon) {var n = _safeActiveLayerId();_smartPaintCleanup(a);if (n !== null) _selectLayerById(n);}try {app.activeDocument.selection.deselect();} catch (e) {}var i = _smartPlaceText(e[r], !!t.data.pointText);t.layerIds.push(i);}} catch (e) {t.error = String(e && e.message ? e.message : e);}}function _smartHistoryKey(e) {var t = stringIDToTypeID("ID");if (e.hasKey(t)) return e.getInteger(t);var r = charIDToTypeID("Nm  ");var a = e.hasKey(r) ? e.getString(r) : "";return "i" + e.getInteger(stringIDToTypeID("itemIndex")) + ":" + a;}function _smartCurrentHistoryKey() {var e = new ActionReference();e.putEnumerated(stringIDToTypeID("historyState"), charID.Ordinal, charID.Target);return _smartHistoryKey(executeActionGet(e));}function smartPasteCommit(e) {if (!app.documents.length) return jamJSON.stringify({"error": "doc"});var t = app.activeDocument;if (!e || String(t.id) !== String(e.documentId)) return jamJSON.stringify({"error": "doc"});var r = null;try {r = _smartCurrentHistoryKey();} catch (e) {}var a = t.historyStates.length;_hostState.smartCommit = {"data": e,"layerIds": [],"error": null};try {t.suspendHistory(_SMART_HISTORY_NAME, "_smartPasteCommitRun()");} catch (e) {_hostState.smartCommit.error = String(e);}var n = _hostState.smartCommit;_hostState.smartCommit = null;if (n.error) {try {var i = t.historyStates;if (i.length > a && i[i.length - 1].name === _SMART_HISTORY_NAME) {t.activeHistoryState = i[i.length - 2];}} catch (e) {}return jamJSON.stringify({"error": "commit","message": n.error});}var o = null;try {o = _smartCurrentHistoryKey();} catch (e) {}return jamJSON.stringify({"layerIds": n.layerIds,"history": {"documentId": t.id,"before": r,"after": o}});}function getHistorySnapshot() {if (!app.documents.length) return jamJSON.stringify(null);try {var e = app.activeDocument;var t = e.historyStates.length;var r = [];for (var a = 1; a <= t; a++) {var n = new ActionReference();n.putIndex(stringIDToTypeID("historyState"), a);r.push(_smartHistoryKey(executeActionGet(n)));}return jamJSON.stringify({"documentId": e.id,"current": _smartCurrentHistoryKey(),"states": r});} catch (e) {return jamJSON.stringify(null);}}function restoreHistoryState(e) {if (!app.documents.length) return jamJSON.stringify({"error": "doc"});var t = app.activeDocument;if (!e || String(t.id) !== String(e.documentId)) return jamJSON.stringify({"error": "doc"});try {var r = t.historyStates.length;for (var a = 1; a <= r; a++) {var n = new ActionReference();n.putIndex(stringIDToTypeID("historyState"), a);if (String(_smartHistoryKey(executeActionGet(n))) === String(e.state)) {t.activeHistoryState = t.historyStates[a - 1];return jamJSON.stringify({"ok": true});}}} catch (e) {return jamJSON.stringify({"error": "history"});}return jamJSON.stringify({"error": "history"});}function replaySelectionTrigger(e) {if (!app.documents.length) return jamJSON.stringify({"error": "doc"});if (!e) return jamJSON.stringify({"error": "trigger"});if (e.documentKey && e.documentKey !== getTypeRDocumentKey()) return jamJSON.stringify({"error": "doc"});try {var t = new ActionDescriptor();var r = new ActionReference();r.putProperty(charID.Channel, charID.FrameSelect);t.putReference(charID.Null, r);if (e.source === "wand") {var a = e.unit === "distanceUnit" ? _getDocumentResolution() / 72 : 1;var n = new ActionDescriptor();n.putUnitDouble(charID.Horizontal, charID.PixelUnit, e.x * a);n.putUnitDouble(charID.Vertical, charID.PixelUnit, e.y * a);t.putObject(charID.To, charIDToTypeID("Pnt "), n);var i = e.options || {};t.putInteger(charIDToTypeID("Tlrn"), typeof i.tolerance === "number" ? i.tolerance : 32);t.putBoolean(charIDToTypeID("AntA"), i.antiAlias !== false);if (i.contiguous === false) t.putBoolean(charIDToTypeID("Cntg"), false);if (i.merged === true) t.putBoolean(stringIDToTypeID("merged"), true);} else if (e.source === "rectangle" && typeof e.left === "number") {var o = new ActionDescriptor();o.putUnitDouble(charIDToTypeID("Top "), charID.PixelUnit, e.top);o.putUnitDouble(charIDToTypeID("Left"), charID.PixelUnit, e.left);o.putUnitDouble(charIDToTypeID("Btom"), charID.PixelUnit, e.bottom);o.putUnitDouble(charIDToTypeID("Rght"), charID.PixelUnit, e.right);t.putObject(charID.To, charIDToTypeID("Rctn"), o);} else {return jamJSON.stringify({"error": "trigger"});}executeAction(charIDToTypeID("setd"), t, DialogModes.NO);return jamJSON.stringify({"ok": true});} catch (e) {return jamJSON.stringify({"error": "replay"});}}function ensureWandSampleAll() {try {var e = new ActionReference();e.putEnumerated(charIDToTypeID("capp"), charID.Ordinal, charID.Target);var t = executeActionGet(e);if (typeIDToStringID(t.getEnumerationType(stringIDToTypeID("tool"))) !== "magicWandTool") return jamJSON.stringify({"wasOff": false});var r = charIDToTypeID("WndS");var a = t.getObjectValue(stringIDToTypeID("currentToolOptions"));if (!a.hasKey(r) || a.getBoolean(r)) return jamJSON.stringify({"wasOff": false});var n = new ActionReference();n.putClass(stringIDToTypeID("magicWandTool"));var i = new ActionDescriptor();i.putBoolean(r, true);var o = new ActionDescriptor();o.putReference(charID.Null, n);o.putObject(charID.To, stringIDToTypeID("currentToolOptions"), i);executeAction(charIDToTypeID("setd"), o, DialogModes.NO);return jamJSON.stringify({"wasOff": true});} catch (e) {return jamJSON.stringify({"error": "sampleAll"});}}function smartPasteSelectionProbe() {if (!app.documents.length) return jamJSON.stringify({"error": "doc"});var t = "";try {t = String(app.currentTool || "");} catch (e) {try {var r = new ActionReference();r.putProperty(charIDToTypeID("Prpr"), stringIDToTypeID("tool"));r.putEnumerated(charIDToTypeID("capp"), charID.Ordinal, charID.Target);var a = executeActionGet(r);t = typeIDToStringID(a.getEnumerationType(stringIDToTypeID("tool")));} catch (e) {t = "";}}var e = null;try {e = _getCurrentSelectionBounds();} catch (e) {}return jamJSON.stringify({"documentId": app.activeDocument.id,"tool": t,"bounds": e ? {"left": e.left,"top": e.top,"right": e.right,"bottom": e.bottom} : null});}
;
// ============================================================
// Copy Style From Below
// Chọn layer trên cùng -> chạy script:
//  1. Tìm layer "dùng được" gần nhất bên dưới VÀ đè lên layer chọn trên canvas
//     (bỏ qua ẩn / khoá / trống / không chồng lên nhau)
//  2. Copy layer style + mặt nạ trắng đen (layer mask) của nó sang layer đang chọn
//     (mask của B chỉ được chép khi phần đen của nó che pixel của B)
//  3. Nếu layer dưới bị clipping mask:
//     - base là LAYER thường -> dup base (kèm mask) rồi clip layer chọn vào
//     - base là GROUP -> dup group (giữ ruột nếu KEEP_GROUP_CONTENTS = true), bỏ layer chọn VÀO TRONG group
//       (không clip), rồi dup các layer đang clip lên group đó (vd dots-pattern) và clip lại vào group mới
//  4. Nếu layer dưới nằm trong group CÓ effect/mask/blend mode/opacity -> dup group,
//     xoá ruột, đặt tên = tên layer chọn, rồi bỏ layer chọn vào trong.
//     Group "trơn" (Normal / Pass Through, không effect) thì bỏ qua, không dup.
//     Mask của group chỉ được tính khi phần đen của nó che pixel của B; mask chỉ che
//     các layer khác trong group thì bỏ qua.
//  5. Các layer bị clip vào B (nằm ngay trên B) chỉ được copy nếu chúng có phần bị xoá
//     (trong suốt / đen trong mask) nằm trên pixel của B; còn nguyên hoặc chỉ xoá chỗ khác thì bỏ qua.
//  6. A và B đều là TEXT: A lấy màu chữ của B, và size của A được nhân theo tỉ lệ
//     size(B) / size mốc của font B. Size mốc = size được dùng nhiều nhất của font đó trong file
//     (không tính các layer đang chọn). VD mốc 10.67pt, B = 11pt -> A phóng to 11 / 10.67 lần.
//  7. A và B đều là TEXT: nếu B dùng style khác style phổ biến nhất của family B trong file
//     (bold / italic / bold-italic, hoặc weight khác như Medium; bằng font family hay faux đều tính)
//     thì A cũng đổi theo. Thứ tự: kết quả các action font (B / I / BI) -> font cùng family đã cài
//     -> faux bold / faux italic (chỉ khi family không có style đó).
// ============================================================

function sTID(s) { return stringIDToTypeID(s); }
function cTID(s) { return charIDToTypeID(s); }

// Các ID dùng lại nhiều lần -> tạo 1 lần cho nhanh
var ID_PROPERTY = sTID("property");
var ID_LAYER = sTID("layer");
var ID_ORDINAL = sTID("ordinal");
var ID_TARGET = sTID("targetEnum");
var ID_LAYER_ID = sTID("layerID");
var ID_BOUNDS = sTID("bounds");
var ID_LEFT = sTID("left");
var ID_TOP = sTID("top");
var ID_RIGHT = sTID("right");
var ID_BOTTOM = sTID("bottom");
var ID_EFFECTS = sTID("layerEffects");
var ID_HAS_MASK = sTID("hasUserMask");
var ID_GROUP = sTID("group"); // true = layer đang là clipping mask

// true: dup group nền giữ nguyên các layer bên trong (như ảnh mẫu), layer chọn được thêm vào trên cùng
// false: dup group nền rồi xoá sạch ruột, chỉ còn layer chọn
var KEEP_GROUP_CONTENTS = false;

// ---------- Tuỳ chọn: phóng to chữ theo tỉ lệ của layer B ----------
var SCALE_TEXT_BY_B = true;    // false = tắt tính năng
var ONLY_SCALE_UP = true;      // true = chỉ phóng to (B nhỏ hơn mốc thì bỏ qua, A giữ nguyên, KHÔNG BAO GIỜ thu nhỏ)
var COUNT_HIDDEN_TEXT = false; // true = tính cả layer text đang ẩn khi tìm size mốc
var SCALE_TOLERANCE = 0.005;   // lệch dưới 0.5% so với mốc thì coi như bằng mốc
var SCALE_BONUS = 0.10;        // B zoom trong khoảng [MIN, MAX] so với mốc thì A zoom thêm 10% (cộng thẳng vào %)
var SCALE_BONUS_MIN = 0.01;    // từ +1%
var SCALE_BONUS_MAX = 0.30;    // đến +30%; lớn hơn khoảng này thì không cộng thêm
var MANUAL_BASE_SIZE = 0;      // > 0 = size gốc của B do người dùng nhập (Sp / Nar), thay cho size mốc tự thống kê
var FONT_STATS = null;         // font -> { "10.67": số layer dùng size đó }

// ---------- Tuỳ chọn: áp bold / italic / bold-italic (hoặc weight khác) của B lên A ----------
var MATCH_STYLE_FROM_B = true; // false = tắt tính năng
// "" = tự dò: set action nào có cặp "tên" + "tên B" / "tên I" / "tên BI" (vd "448 Speech" + "448 Speech B")
// Ghi đúng tên set action để chỉ dùng set đó (khi đó chạy thử MỌI action trong set)
var FONT_ACTION_SET = "";
var ACTION_SUFFIXES = [" BI", " B", " I"];
var DEBUG_STYLE = false;       // true = hiện 1 bảng thông báo cuối cùng: đọc được gì ở A / B và quyết định ra sao
var DEBUG_LOG = [];
var STYLE_STATS = null;        // family -> { "Style|faux": số layer }
var ACTION_FONTS = null;       // font mà từng action tạo ra (chạy thử trên layer tạm, dò 1 lần khi cần)
var FAMILY_FONTS = {};         // cache: family -> font đã cài trong máy

var ID_FONT_PS = sTID("fontPostScriptName");
var ID_FONT_NAME = sTID("fontName");
var ID_FONT_STYLE = sTID("fontStyleName");
var ID_SYN_BOLD = sTID("syntheticBold");
var ID_SYN_ITALIC = sTID("syntheticItalic");
var ID_ASET = sTID("actionSet");
var ID_ACTION = sTID("action");
var ID_NAME = sTID("name");
var ID_NUMCHILD = sTID("numberOfChildren");

var ID_TEXTKEY = sTID("textKey");
var ID_TSR = sTID("textStyleRange");
var ID_TEXTSTYLE = sTID("textStyle");
var ID_SIZE = sTID("size");
var ID_LEADING = sTID("leading");
var ID_AUTOLEADING = sTID("autoLeading");

function isLocked(l) {
    try { return l.allLocked == true; } catch (e) {}
    return false;
}

// Mở khoá layer / group (mọi loại khoá). Layer clip bị khoá vẫn được xử lý bình thường.
function unlockLayer(l) {
    try { if (l.allLocked) l.allLocked = false; } catch (e) {}
    try { l.pixelsLocked = false; } catch (e) {}
    try { l.positionLocked = false; } catch (e) {}
    try { l.transparentPixelsLocked = false; } catch (e) {}
}

function isEmpty(l) {
    try {
        var b = l.bounds;
        return (b[2].as("px") - b[0].as("px")) <= 0 || (b[3].as("px") - b[1].as("px")) <= 0;
    } catch (e) { return false; }
}

// ID của layer (nếu bản Photoshop hỗ trợ). Không có thì trả null.
function layerId(l) {
    try { var v = l.id; if (typeof v == "number") return v; } catch (e) {}
    return null;
}

// Tạo reference tới layer (và 1 property nếu cần) mà KHÔNG phải chọn layer đó
// -> nhanh hơn nhiều vì Photoshop không phải vẽ lại panel. Không có ID thì mới chọn layer.
function layerRef(layer, prop) {
    var r = new ActionReference();
    if (prop) r.putProperty(ID_PROPERTY, prop);
    var id = layerId(layer);
    if (id !== null) {
        r.putIdentifier(ID_LAYER, id);
    } else {
        app.activeDocument.activeLayer = layer;
        r.putEnumerated(ID_LAYER, ID_ORDINAL, ID_TARGET);
    }
    return r;
}

// Vị trí của layer trong container.layers (-1 nếu không thấy)
function indexInContainer(container, layer) {
    var layers = container.layers;
    var n = layers.length;
    var id = layerId(layer);
    if (id !== null) {
        for (var i = 0; i < n; i++) {
            if (layerId(layers[i]) === id) return i;
        }
        return -1;
    }
    // Dự phòng: đổi tên tạm để nhận diện
    var orig = layer.name;
    var tag = "__T_" + (new Date()).getTime();
    layer.name = tag;
    var k = -1;
    for (var j = 0; j < n; j++) {
        if (layers[j].name == tag) { k = j; break; }
    }
    layer.name = orig;
    return k;
}

function getAncestors(layer) {
    var res = [];
    var p = layer.parent;
    while (p && p.typename == "LayerSet") {
        res.push(p);
        p = p.parent;
    }
    return res; // từ trong ra ngoài
}

function getId(layer) {
    var id = layerId(layer);
    if (id !== null) return id;
    app.activeDocument.activeLayer = layer;
    var r = new ActionReference();
    r.putProperty(ID_PROPERTY, ID_LAYER_ID);
    r.putEnumerated(ID_LAYER, ID_ORDINAL, ID_TARGET);
    return executeActionGet(r).getInteger(ID_LAYER_ID);
}

function stripGroup(g) {
    while (g.layers.length > 0) {
        var c = g.layers[0];
        try { c.allLocked = false; } catch (e) {}
        c.remove();
    }
}

// Bounds của layer theo px: [trái, trên, phải, dưới]
// Dùng bounds của Action Manager: đã tính cả layer style (viền, glow, shadow...)
// nên khớp với thứ nhìn thấy trên canvas. Lỗi thì quay về bounds thường.
function getBounds(l) {
    try {
        var d = executeActionGet(layerRef(l, ID_BOUNDS)).getObjectValue(ID_BOUNDS);
        return [
            d.getUnitDoubleValue(ID_LEFT),
            d.getUnitDoubleValue(ID_TOP),
            d.getUnitDoubleValue(ID_RIGHT),
            d.getUnitDoubleValue(ID_BOTTOM)
        ];
    } catch (e) {
        var b = l.bounds;
        return [b[0].as("px"), b[1].as("px"), b[2].as("px"), b[3].as("px")];
    }
}

// 2 layer có đè lên nhau trên canvas không? (giao nhau thực sự, không chỉ chạm cạnh)
function overlaps(a, b) {
    return a[0] < b[2] && b[0] < a[2] && a[1] < b[3] && b[1] < a[3];
}

// Layer / group có layer style (effect) không?
function hasEffects(layer) {
    try {
        var d = executeActionGet(layerRef(layer, ID_EFFECTS));
        if (!d.hasKey(ID_EFFECTS)) return false;
        return d.getObjectValue(ID_EFFECTS).count > 1; // ngoài key "scale"
    } catch (e) { return false; }
}

// Layer có mặt nạ trắng đen (raster mask) không?
function hasMask(layer) {
    var d = executeActionGet(layerRef(layer, ID_HAS_MASK));
    return d.hasKey(ID_HAS_MASK) && d.getBoolean(ID_HAS_MASK);
}

// Group "trơn": không effect, opacity 100, blend mode Normal / Pass Through,
// và không có mask ảnh hưởng tới layer B (maskMatters = false)
// -> không cần dup group, chỉ cần copy layer bên trong
function isPlainGroup(g, maskMatters) {
    try {
        if (g.blendMode != BlendMode.PASSTHROUGH && g.blendMode != BlendMode.NORMAL) return false;
        if (g.opacity < 100) return false;
        if (maskMatters) return false;
        if (hasEffects(g)) return false;
    } catch (e) { return false; }
    return true;
}

// Duyệt theo thứ tự từ trên xuống dưới (đi sâu vào group), bắt đầu từ vị trí "from",
// dừng ngay khi gặp layer hợp lệ đầu tiên đè lên aBounds.
// Group ẩn/khoá thì bỏ qua cả nhánh (con của nó chắc chắn không hợp lệ).
var EXCLUDE = {}; // id các layer đang được chọn (chế độ nhiều layer): không dùng làm nguồn style

function isExcluded(l) {
    for (var k in EXCLUDE) { // chỉ tốn công khi thực sự có layer bị loại
        return EXCLUDE[getId(l)] === true;
    }
    return false;
}

function cs_scan(container, from, parentOk, aBounds) {
    var layers = container.layers;
    var n = layers.length;
    for (var i = from; i < n; i++) {
        var l = layers[i];
        if (l.typename == "LayerSet") {
            var ok = parentOk && l.visible && !isLocked(l);
            if (!ok || isClipped(l)) continue; // group đang bị clip = layer trang trí, không phải nguồn style
            var r = cs_scan(l, 0, ok, aBounds);
            if (r) return r;
        } else {
            if (!parentOk || !l.visible || isLocked(l) || isEmpty(l) || isClipped(l) || isExcluded(l)) continue; // bỏ layer clip (dots-pattern...) và layer đang chọn
            var cb = null;
            try { cb = getBounds(l); } catch (e) {}
            if (cb && overlaps(aBounds, cb)) return l;
        }
    }
    return null;
}

// Tìm layer B bên dưới A mà không phải quét cả tài liệu:
// quét phần còn lại của container chứa A, rồi đi dần ra các group cha.
// Trả về: layer B | null (không có layer hợp lệ) | undefined (không xác định được vị trí A)
function findB(doc, A, aBounds) {
    var anc = getAncestors(A);
    var n = anc.length;

    // okAt[k]: tất cả group từ anc[k] trở ra ngoài đều hiện & không khoá
    var okAt = [];
    var acc = true;
    for (var k = n - 1; k >= 0; k--) {
        acc = acc && anc[k].visible && !isLocked(anc[k]);
        okAt[k] = acc;
    }
    okAt[n] = true;

    for (var c = 0; c <= n; c++) {
        var container = (c < n) ? anc[c] : doc;
        var item = (c == 0) ? A : anc[c - 1];
        var pos = indexInContainer(container, item);
        if (pos < 0) return undefined;
        var r = cs_scan(container, pos + 1, okAt[c], aBounds);
        if (r) return r;
    }
    return null;
}

// Thao tác selection với 1 channel của layer đang active (CHỈ ĐỌC channel, không sửa channel).
// ev: "setd" = thay selection bằng channel | "Intr" = giao selection với channel | "Sbtr" = trừ channel khỏi selection
// chan: "Trsp" = vùng pixel (transparency) | "Msk " = mặt nạ trắng đen
function selOp(ev, chan) {
    var d = new ActionDescriptor();
    var rc = new ActionReference();
    rc.putEnumerated(cTID("Chnl"), cTID("Chnl"), cTID(chan));
    var rs = new ActionReference();
    rs.putProperty(cTID("Chnl"), cTID("fsel"));
    if (ev == "setd") {
        d.putReference(cTID("null"), rs);
        d.putReference(cTID("T   "), rc);
    } else if (ev == "Intr") {
        d.putReference(cTID("null"), rc);
        d.putReference(cTID("With"), rs);
    } else if (ev == "Sbtr") {
        d.putReference(cTID("null"), rc);
        d.putReference(cTID("From"), rs);
    } else {
        throw new Error("selOp: lệnh không hỗ trợ: " + ev);
    }
    executeAction(cTID(ev), d, DialogModes.NO);
}

// Layer C (bị clip vào B) có phần BỊ XOÁ nằm trên pixel của B không?
// "Bị xoá" = chỗ trong suốt (tẩy mất pixel) hoặc chỗ đen của layer mask của C.
// Cách làm: selection = pixel của B, trừ đi phần C còn đang phủ; còn dư dù 1 chút = có chỗ bị xoá.
// C còn nguyên (phủ kín B) hoặc chỉ bị xoá ở chỗ không có pixel của B -> false.
// Lỗi (layer không hỗ trợ) thì coi như có để không bỏ sót.
function hasHoleOver(B, C) {
    var doc = app.activeDocument;
    try {
        var bMask = hasMask(B);
        var cMask = hasMask(C);
        var found = false;
        for (var pass = 0; pass < 2 && !found; pass++) {
            if (pass == 1 && !cMask) break;
            doc.activeLayer = B;
            selOp("setd", "Trsp");
            if (bMask) selOp("Intr", "Msk "); // chỉ tính phần B đang hiện
            doc.activeLayer = C;
            selOp("Sbtr", pass == 0 ? "Trsp" : "Msk ");
            try { doc.selection.bounds; found = true; } catch (e) {} // selection rỗng -> chưa bị xoá
        }
        try { doc.selection.deselect(); } catch (e) {}
        return found;
    } catch (e) {
        try { doc.selection.deselect(); } catch (e2) {}
        return true;
    }
}

// Mask đen của group G có che mất phần nào pixel của B không?
// (selection = pixel của B, trừ đi phần mask của G cho hiện; còn dư dù 1 chút = có che)
// Mask chỉ che các layer khác trong group, không đụng tới B -> false.
// Lỗi thì coi như có che để không bỏ sót.
function maskHidesPartOf(B, G) {
    var doc = app.activeDocument;
    try {
        doc.activeLayer = B;
        selOp("setd", "Trsp");
        if (hasMask(B)) selOp("Intr", "Msk "); // chỉ tính phần B đang hiện
        doc.activeLayer = G;
        selOp("Sbtr", "Msk ");
        var found = false;
        try { doc.selection.bounds; found = true; } catch (e) {}
        try { doc.selection.deselect(); } catch (e) {}
        return found;
    } catch (e) {
        try { doc.selection.deselect(); } catch (e2) {}
        return true;
    }
}

// Mask trắng đen của chính B có che mất phần nào pixel của B không?
// Mask chỉ đen ở chỗ không có pixel của B (ví dụ mask bao quanh hình dạng B) -> false,
// không có lý do gì để chép sang A.
// Lỗi thì coi như có che để không bỏ sót.
function ownMaskHidesPartOfB(B) {
    var doc = app.activeDocument;
    try {
        doc.activeLayer = B;
        selOp("setd", "Trsp");
        selOp("Sbtr", "Msk ");
        var found = false;
        try { doc.selection.bounds; found = true; } catch (e) {}
        try { doc.selection.deselect(); } catch (e) {}
        return found;
    } catch (e) {
        try { doc.selection.deselect(); } catch (e2) {}
        return true;
    }
}

// Xoá layer mask của layer / group (bỏ hẳn, không apply)
function deleteMask(layer) {
    app.activeDocument.activeLayer = layer;
    var d = new ActionDescriptor();
    var r = new ActionReference();
    r.putEnumerated(cTID("Chnl"), cTID("Chnl"), cTID("Msk "));
    d.putReference(cTID("null"), r);
    d.putBoolean(cTID("Aply"), false);
    executeAction(cTID("Dlt "), d, DialogModes.NO);
}

// Copy mặt nạ trắng đen từ layer "from" sang layer "to"
// (load mask thành selection -> tạo mask mới từ selection, giữ nguyên mức xám)
function copyMask(from, to) {
    var doc = app.activeDocument;
    if (!hasMask(from) || hasMask(to)) return;

    doc.activeLayer = from;
    var d = new ActionDescriptor();
    var r = new ActionReference();
    r.putProperty(cTID("Chnl"), cTID("fsel"));
    d.putReference(cTID("null"), r);
    var r2 = new ActionReference();
    r2.putEnumerated(cTID("Chnl"), cTID("Chnl"), cTID("Msk "));
    d.putReference(cTID("T   "), r2);
    executeAction(cTID("setd"), d, DialogModes.NO);

    // Mask đen hoàn toàn -> selection rỗng -> phải tạo mask "hide all"
    var empty = false;
    try { doc.selection.bounds; } catch (e) { empty = true; }

    doc.activeLayer = to;
    var d2 = new ActionDescriptor();
    d2.putClass(cTID("Nw  "), cTID("Chnl"));
    var r3 = new ActionReference();
    r3.putEnumerated(cTID("Chnl"), cTID("Chnl"), cTID("Msk "));
    d2.putReference(cTID("At  "), r3);
    d2.putEnumerated(cTID("Usng"), cTID("UsrM"), empty ? cTID("HdAl") : cTID("RvlS"));
    executeAction(cTID("Mk  "), d2, DialogModes.NO);

    try { doc.selection.deselect(); } catch (e) {}
}



// ---------- Màu chữ (text layer) ----------
// Chỉ dùng Action Manager, KHÔNG đụng vào layer.textItem (DOM) -> không bật hộp thoại "missing fonts"
function isTextLayer(l) {
    try { return l.kind == LayerKind.TEXT; } catch (e) { return false; }
}

function readColorFromStyle(ts) {
    if (ts.hasKey(sTID("color"))) {
        return { desc: ts.getObjectValue(sTID("color")), type: ts.getObjectType(sTID("color")) };
    }
    return null;
}

// Lấy màu chữ của layer text (lấy theo đoạn chữ đầu tiên)
function getTextColor(layer) {
    var d = executeActionGet(layerRef(layer, sTID("textKey")));
    if (!d.hasKey(sTID("textKey"))) return null;
    var tk = d.getObjectValue(sTID("textKey"));
    if (tk.hasKey(sTID("textStyleRange"))) {
        var rl = tk.getList(sTID("textStyleRange"));
        if (rl.count > 0) {
            var r0 = rl.getObjectValue(0);
            if (r0.hasKey(sTID("textStyle"))) {
                var c = readColorFromStyle(r0.getObjectValue(sTID("textStyle")));
                if (c) return c;
            }
        }
    }
    if (tk.hasKey(sTID("textStyle"))) return readColorFromStyle(tk.getObjectValue(sTID("textStyle")));
    return null;
}

// Đặt màu chữ cho toàn bộ layer text, giữ nguyên font và các thuộc tính khác
function setTextColor(layer, c) {
    app.activeDocument.activeLayer = layer;
    var d = new ActionDescriptor();
    var r = new ActionReference();
    r.putProperty(cTID("Prpr"), sTID("textStyle"));
    r.putEnumerated(cTID("TxLr"), ID_ORDINAL, ID_TARGET);
    d.putReference(cTID("null"), r);
    var td = new ActionDescriptor();
    td.putObject(sTID("color"), c.type, c.desc);
    d.putObject(cTID("T   "), sTID("textStyle"), td);
    executeAction(cTID("setd"), d, DialogModes.NO);
}

// ---------- Size chữ (text layer) ----------
// Đọc font + size của layer text (theo đoạn chữ đầu tiên), chỉ dùng Action Manager.
// size = size thực tế (đã nhân hệ số transform nếu layer từng bị scale bằng Free Transform)
// raw  = size lưu trong textStyle, dùng để ghi ngược lại
function getTextInfo(layer) {
    var d = executeActionGet(layerRef(layer, ID_TEXTKEY));
    if (!d.hasKey(ID_TEXTKEY)) return null;
    var tk = d.getObjectValue(ID_TEXTKEY);
    var ts = null;
    if (tk.hasKey(ID_TSR)) {
        // Layer có nhiều đoạn chữ (vd 1 vài từ bold / italic) -> lấy đoạn chiếm nhiều ký tự nhất
        var rl = tk.getList(ID_TSR);
        var bestSpan = -1;
        for (var ri = 0; ri < rl.count; ri++) {
            var rd = rl.getObjectValue(ri);
            if (!rd.hasKey(ID_TEXTSTYLE)) continue;
            var span = 1;
            try { span = rd.getInteger(sTID("to")) - rd.getInteger(sTID("from")); } catch (e) {}
            if (span > bestSpan) { bestSpan = span; ts = rd.getObjectValue(ID_TEXTSTYLE); }
        }
    }
    if (!ts && tk.hasKey(ID_TEXTSTYLE)) ts = tk.getObjectValue(ID_TEXTSTYLE);
    if (!ts || !ts.hasKey(ID_SIZE)) return null;

    var raw = ts.getUnitDoubleValue(ID_SIZE);
    var k = 1;
    try {
        if (tk.hasKey(sTID("transform"))) {
            var tr = tk.getObjectValue(sTID("transform"));
            if (tr.hasKey(sTID("yy"))) k = Math.abs(tr.getDouble(sTID("yy")));
        }
    } catch (e) {}
    if (!(k > 0)) k = 1;

    var font = "";
    if (ts.hasKey(sTID("fontPostScriptName"))) font = ts.getString(sTID("fontPostScriptName"));
    else if (ts.hasKey(sTID("fontName"))) font = ts.getString(sTID("fontName"));

    var auto = ts.hasKey(ID_AUTOLEADING) ? ts.getBoolean(ID_AUTOLEADING) : true;
    var lead = (!auto && ts.hasKey(ID_LEADING)) ? ts.getUnitDoubleValue(ID_LEADING) : null;

    var family = ts.hasKey(ID_FONT_NAME) ? ts.getString(ID_FONT_NAME) : "";
    var style = ts.hasKey(ID_FONT_STYLE) ? ts.getString(ID_FONT_STYLE) : "";
    if (!style && font.indexOf("-") > 0) style = font.substr(font.lastIndexOf("-") + 1).replace(/MT$/, "");
    var fauxB = ts.hasKey(ID_SYN_BOLD) ? ts.getBoolean(ID_SYN_BOLD) : false;
    var fauxI = ts.hasKey(ID_SYN_ITALIC) ? ts.getBoolean(ID_SYN_ITALIC) : false;

    return { font: font, family: family, style: style, fauxB: fauxB, fauxI: fauxI,
             raw: raw, size: raw * k, leading: lead };
}

// Đặt size (và leading nếu đang để thủ công) cho toàn bộ layer text
function setTextSize(layer, raw, leading) {
    app.activeDocument.activeLayer = layer;
    var d = new ActionDescriptor();
    var r = new ActionReference();
    r.putProperty(cTID("Prpr"), ID_TEXTSTYLE);
    r.putEnumerated(cTID("TxLr"), ID_ORDINAL, ID_TARGET);
    d.putReference(cTID("null"), r);
    var td = new ActionDescriptor();
    td.putUnitDouble(ID_SIZE, cTID("#Pnt"), raw);
    if (leading !== null) {
        td.putBoolean(ID_AUTOLEADING, false);
        td.putUnitDouble(ID_LEADING, cTID("#Pnt"), leading);
    }
    d.putObject(cTID("T   "), ID_TEXTSTYLE, td);
    executeAction(cTID("setd"), d, DialogModes.NO);
}

function round2(x) { return Math.round(x * 100) / 100; }

// Duyệt toàn bộ file, đếm số layer text theo (font, size)
function collectTextStats(container, parentVisible, excludeIds, stats) {
    var ls = container.layers;
    for (var i = 0; i < ls.length; i++) {
        var l = ls[i];
        if (l.typename == "LayerSet") {
            collectTextStats(l, parentVisible && l.visible, excludeIds, stats);
            continue;
        }
        if (!isTextLayer(l)) continue;
        if (!COUNT_HIDDEN_TEXT && !(parentVisible && l.visible)) continue;
        if (excludeIds[getId(l)] === true) continue;
        var info = null;
        try { info = getTextInfo(l); } catch (e) {}
        if (!info || !info.font) continue;
        var key = round2(info.size).toFixed(2);
        if (!stats[info.font]) stats[info.font] = {};
        stats[info.font][key] = (stats[info.font][key] || 0) + 1;
        if (STYLE_STATS) {
            mergeFaux(info, l);
            var fk = familyKey(info);
            var sk = styleKey(info);
            if (!STYLE_STATS[fk]) STYLE_STATS[fk] = {};
            STYLE_STATS[fk][sk] = (STYLE_STATS[fk][sk] || 0) + 1;
        }
    }
}

// Thống kê 1 lần trước khi sửa gì. Không tính các layer đang chọn (chúng sắp bị đổi size).
// Không có layer text nào được chọn -> khỏi thống kê (null).
function buildFontStats(doc, sel) {
    var hasText = false;
    var ex = {};
    for (var i = 0; i < sel.length; i++) {
        if (isTextLayer(sel[i])) hasText = true;
        ex[getId(sel[i])] = true;
    }
    if (!hasText) return null;
    var stats = {};
    STYLE_STATS = MATCH_STYLE_FROM_B ? {} : null;
    var oldDlg = app.displayDialogs;
    app.displayDialogs = DialogModes.NO; // đọc textItem (faux) không được bật popup missing font
    try { collectTextStats(doc, true, ex, stats); } catch (e) {}
    app.displayDialogs = oldDlg;
    return stats;
}

// Size mốc của font = size được dùng nhiều nhất; hoà thì lấy size nhỏ hơn
function getBaseSize(font) {
    if (!FONT_STATS || !FONT_STATS[font]) return 0;
    var m = FONT_STATS[font];
    var best = 0, bestCnt = 0;
    for (var k in m) {
        var v = parseFloat(k);
        if (m[k] > bestCnt || (m[k] == bestCnt && v < best)) { best = v; bestCnt = m[k]; }
    }
    return best;
}

// A (text) được nhân size theo tỉ lệ  size(B) / size mốc của font B (+10% nếu B zoom 8%..40%).  Trả về true nếu đã đổi size.
function scaleTextLikeB(A, B) {
    if (!SCALE_TEXT_BY_B || (!FONT_STATS && !(MANUAL_BASE_SIZE > 0))) return false;
    var bi = getTextInfo(B);
    if (!bi || !bi.font) return false;
    var base = MANUAL_BASE_SIZE > 0 ? MANUAL_BASE_SIZE : getBaseSize(bi.font);
    if (!(base > 0)) return false;
    var ratio = bi.size / base;
    if (Math.abs(ratio - 1) < SCALE_TOLERANCE) return false;
    // chỉ phóng to: B bằng hoặc nhỏ hơn mốc thì A giữ nguyên (không bao giờ thu nhỏ)
    if (ONLY_SCALE_UP && ratio < 1) return false;
    // zoom của B từ +1% đến +30% thì A zoom thêm 10% nữa (vd B +20% -> A +30%) để dễ nhận ra khác biệt
    var zoom = ratio - 1;
    if (zoom >= SCALE_BONUS_MIN - 0.00001 && zoom <= SCALE_BONUS_MAX + 0.00001) ratio += SCALE_BONUS;
    if (ONLY_SCALE_UP && ratio < 1) return false; // chốt chặn cuối: tuyệt đối không giảm
    var ai = getTextInfo(A);
    if (!ai) return false;
    setTextSize(A, ai.raw * ratio, ai.leading === null ? null : ai.leading * ratio);
    return true;
}

// ---------- Bold / Italic / Bold-Italic (hoặc weight khác) theo layer B ----------
// Faux bold / faux italic theo DOM (textItem) - dự phòng khi Action Manager không đọc được.
// Gọi khi đã tắt hộp thoại (displayDialogs = NO) để khỏi bật popup missing font.
function domFaux(layer) {
    try {
        var ti = layer.textItem;
        return { b: ti.fauxBold === true, i: ti.fauxItalic === true };
    } catch (e) { return null; }
}

function mergeFaux(info, layer) {
    var d = domFaux(layer);
    if (d) {
        if (d.b) info.fauxB = true;
        if (d.i) info.fauxI = true;
    }
}

function cs_dbg(msg) { if (DEBUG_STYLE) DEBUG_LOG.push(msg); }

function showDebug() {
    if (DEBUG_STYLE && DEBUG_LOG.length > 0) {
        try { alert(DEBUG_LOG.join("\n")); } catch (e) {}
    }
    DEBUG_LOG = [];
}

function fxStr(info) { return (info.fauxB ? "B" : "-") + (info.fauxI ? "I" : "-"); }

function familyKey(info) { return String(info.family || info.font || "").toLowerCase(); }
function styleKey(info) { return (info.style || "") + "|" + (info.fauxB ? 1 : 0) + (info.fauxI ? 1 : 0); }

// Chuẩn hoá style -> { weight: "regular" | "bold" | "medium" | ..., italic: true/false }
// Faux bold / faux italic được tính như bold / italic thật.
function classifyStyle(style, fauxB, fauxI) {
    var s = String(style || "").toLowerCase();
    var italic = /italic|oblique/.test(s);
    var w = s.replace(/italic|oblique/g, "").replace(/[\s_\-]+/g, "");
    if (w == "" || w == "regular" || w == "normal" || w == "roman" || w == "book") w = "regular";
    if (fauxB && w == "regular") w = "bold";
    return { weight: w, italic: italic || !!fauxI };
}

function sameStyle(a, b) { return a.weight == b.weight && a.italic == b.italic; }

function scoreStyleKey(k) {
    var p = k.split("|");
    var f = p.length > 1 ? p[1] : "00";
    var c = classifyStyle(p[0], f.charAt(0) == "1", f.charAt(1) == "1");
    return (c.weight == "regular" ? 0 : 1) + (c.italic ? 1 : 0);
}

// Style phổ biến nhất của 1 family trong file; hoà thì lấy style "thường" hơn
function getBaseStyleKey(fk) {
    var m = STYLE_STATS && STYLE_STATS[fk];
    if (!m) return null;
    var best = null, bestCnt = 0, bestScore = 99;
    for (var k in m) {
        var sc = scoreStyleKey(k);
        if (m[k] > bestCnt || (m[k] == bestCnt && sc < bestScore)) { best = k; bestCnt = m[k]; bestScore = sc; }
    }
    return best;
}

// Đặt font (+ faux bold / italic) cho toàn bộ layer text. KHÔNG đụng size / scale / màu.
function setTextFont(layer, ps, family, style, fauxB, fauxI) {
    app.activeDocument.activeLayer = layer;
    var d = new ActionDescriptor();
    var r = new ActionReference();
    r.putProperty(cTID("Prpr"), ID_TEXTSTYLE);
    r.putEnumerated(cTID("TxLr"), ID_ORDINAL, ID_TARGET);
    d.putReference(cTID("null"), r);
    var td = new ActionDescriptor();
    td.putString(ID_FONT_PS, ps);
    if (family) td.putString(ID_FONT_NAME, family);
    if (style) td.putString(ID_FONT_STYLE, style);
    td.putBoolean(ID_SYN_BOLD, !!fauxB);
    td.putBoolean(ID_SYN_ITALIC, !!fauxI);
    d.putObject(cTID("T   "), ID_TEXTSTYLE, td);
    executeAction(cTID("setd"), d, DialogModes.NO);
    // Kiểm tra lại faux bằng DOM; nếu Action Manager không ăn thì đặt lại bằng DOM
    try {
        var ti = layer.textItem;
        if (ti.fauxBold !== !!fauxB) ti.fauxBold = !!fauxB;
        if (ti.fauxItalic !== !!fauxI) ti.fauxItalic = !!fauxI;
    } catch (e) {}
}

// Font cùng family đã cài trong máy: [{ ps, family, style }]
function getFamilyFonts(family) {
    var key = String(family || "").toLowerCase();
    if (key == "") return [];
    if (FAMILY_FONTS[key]) return FAMILY_FONTS[key];
    var out = [];
    try {
        var fl = app.fonts;
        var n = fl.length;
        for (var i = 0; i < n; i++) {
            var f = fl[i];
            var fam = "";
            try { fam = f.family; } catch (e) {}
            if (String(fam).toLowerCase() != key) continue;
            out.push({ ps: f.postScriptName, family: f.family, style: f.style });
        }
    } catch (e2) {}
    FAMILY_FONTS[key] = out;
    return out;
}

// ---------- Đọc các action font ----------
function readActionSets() {
    var sets = [];
    for (var i = 1; i < 300; i++) {
        var d = null;
        try {
            var ref = new ActionReference();
            ref.putIndex(ID_ASET, i);
            d = executeActionGet(ref);
        } catch (e) { break; }
        var cnt = d.hasKey(ID_NUMCHILD) ? d.getInteger(ID_NUMCHILD) : 0;
        var names = [];
        for (var j = 1; j <= cnt; j++) {
            try {
                var r = new ActionReference();
                r.putIndex(ID_ACTION, j);
                r.putIndex(ID_ASET, i);
                names.push(executeActionGet(r).getString(ID_NAME));
            } catch (e2) {}
        }
        sets.push({ name: d.getString(ID_NAME), actions: names });
    }
    return sets;
}

// Chỉ giữ các action có cặp "tên" + "tên B/I/BI" -> không bao giờ chạy nhầm action lạ
function pickFontActions(names) {
    var has = {};
    for (var i = 0; i < names.length; i++) has[names[i]] = true;
    var out = {};
    for (var k = 0; k < names.length; k++) {
        var n = names[k];
        for (var s = 0; s < ACTION_SUFFIXES.length; s++) {
            var suf = ACTION_SUFFIXES[s];
            if (n.length > suf.length && n.substr(n.length - suf.length) == suf) {
                var base = n.substr(0, n.length - suf.length);
                if (has[base]) { out[base] = true; out[n] = true; }
            }
        }
    }
    var list = [];
    for (var key in out) list.push(key);
    return list;
}

// Tách tên action: "448 Speech BI" -> { base: "448 Speech", suffix: " BI" }; không có hậu tố -> suffix ""
function splitActionName(n) {
    for (var s = 0; s < ACTION_SUFFIXES.length; s++) {
        var suf = ACTION_SUFFIXES[s];
        if (n.length > suf.length && n.substr(n.length - suf.length) == suf) {
            return { base: n.substr(0, n.length - suf.length), suffix: suf };
        }
    }
    return { base: n, suffix: "" };
}

// Chạy thử từng action font trên 1 layer text TẠM rồi đọc font nó tạo ra (family, style, faux).
// Layer thật không bị chạy action -> size / scale của A không bị ghi đè. Dò 1 lần, xong xoá layer tạm.
function getActionFonts() {
    if (ACTION_FONTS) return ACTION_FONTS;
    ACTION_FONTS = [];
    var doc = app.activeDocument;
    var jobs = [];
    try {
        var sets = readActionSets();
        for (var i = 0; i < sets.length; i++) {
            var names;
            if (FONT_ACTION_SET != "") {
                if (sets[i].name != FONT_ACTION_SET) continue;
                names = sets[i].actions;
            } else {
                names = pickFontActions(sets[i].actions);
            }
            for (var j = 0; j < names.length; j++) {
                var sp = splitActionName(names[j]);
                jobs.push({ set: sets[i].name, name: names[j], group: sets[i].name + "::" + sp.base, suffix: sp.suffix });
            }
        }
    } catch (e) {}
    if (jobs.length == 0) return ACTION_FONTS;

    var oldDlg = app.displayDialogs;
    var keep = doc.activeLayer;
    // Mỗi action chạy trên 1 layer tạm MỚI (không dùng chung): action "B" chỉ bật bold, không tắt italic,
    // nên nếu dùng chung layer thì italic của action "I" chạy trước đó bị dính sang kết quả của "B".
    // Action biến thể (B / I / BI) được chạy SAU action gốc của nhóm (trạng thái Regular, như khi dùng tay).
    var baseOf = {};
    for (var bi0 = 0; bi0 < jobs.length; bi0++) if (jobs[bi0].suffix === "") baseOf[jobs[bi0].group] = jobs[bi0];
    app.displayDialogs = DialogModes.NO;
    for (var k = 0; k < jobs.length; k++) {
        var scratch = null;
        try {
            scratch = doc.artLayers.add();
            scratch.kind = LayerKind.TEXT;
            scratch.textItem.contents = "x";
            doc.activeLayer = scratch;
            var bj = baseOf[jobs[k].group];
            if (jobs[k].suffix !== "" && bj) {
                app.doAction(bj.name, bj.set);
                doc.activeLayer = scratch;
            }
            app.doAction(jobs[k].name, jobs[k].set);
            doc.activeLayer = scratch;
            var info = getTextInfo(scratch);
            if (info && info.font) {
                mergeFaux(info, scratch);
                info.name = jobs[k].name;
                info.group = jobs[k].group;
                info.suffix = jobs[k].suffix;
                ACTION_FONTS.push(info);
            }
        } catch (e2) {}
        try { if (scratch) scratch.remove(); } catch (e4) {}
    }
    app.displayDialogs = oldDlg;
    try { doc.activeLayer = keep; } catch (e5) {}
    return ACTION_FONTS;
}

// Nhóm action "group" có phải nhóm font của A không? (bất kỳ action nào trong nhóm cho font trùng A)
function actionGroupIsFontOfA(acts, group, ai, fk) {
    for (var i = 0; i < acts.length; i++) {
        var m = acts[i];
        if (m.group != group) continue;
        if (familyKey(m) == fk) return true;
        if (m.font && ai.font && m.font == ai.font) return true;
    }
    return false;
}

// Đổi A sang style "target". Thứ tự: action font -> font cùng family đã cài -> faux
function setStyleVariant(A, ai, target) {
    var fk = familyKey(ai);

    // 1. ACTION font (ưu tiên cao nhất, kể cả khi action dùng faux).
    //    a) Tìm NHÓM action ("448 Speech" + " B" / " I" / " BI") mà font của nó là font của A:
    //       trùng family HOẶC trùng tên PostScript HOẶC trùng tên gốc của font.
    //    b) Trong nhóm đó lấy action theo hậu tố: bold+italic -> BI, bold -> B, italic -> I, thường -> action gốc.
    //       Chọn theo TÊN action nên không phụ thuộc việc đọc lại faux có chính xác hay không.
    var acts = getActionFonts();
    var wantSuf = null;
    if (target.weight == "bold") wantSuf = target.italic ? " BI" : " B";
    else if (target.weight == "regular") wantSuf = target.italic ? " I" : "";
    if (wantSuf !== null) {
        for (var i = 0; i < acts.length; i++) {
            var a = acts[i];
            if (a.suffix !== wantSuf) continue;
            if (!actionGroupIsFontOfA(acts, a.group, ai, fk)) continue;
            setTextFont(A, a.font, a.family, a.style, a.fauxB, a.fauxI);
            cs_dbg("  [action] " + a.name + " -> " + a.font + " / " + a.style + " / faux " + fxStr(a));
            return true;
        }
    }
    // Weight khác (Medium...): dò theo kết quả của action nếu có
    for (var i2 = 0; i2 < acts.length; i2++) {
        var a2 = acts[i2];
        if (familyKey(a2) != fk) continue;
        if (sameStyle(classifyStyle(a2.style, a2.fauxB, a2.fauxI), target)) {
            setTextFont(A, a2.font, a2.family, a2.style, a2.fauxB, a2.fauxI);
            cs_dbg("  [action] " + a2.name + " -> " + a2.font + " / " + a2.style + " / faux " + fxStr(a2));
            return true;
        }
    }

    // 2. Font cùng family đã cài, đúng style (không cần faux)
    var fonts = getFamilyFonts(ai.family);
    for (var j = 0; j < fonts.length; j++) {
        if (sameStyle(classifyStyle(fonts[j].style, false, false), target)) {
            setTextFont(A, fonts[j].ps, fonts[j].family, fonts[j].style, false, false);
            cs_dbg("  [family] " + fonts[j].ps);
            return true;
        }
    }

    // 3. Faux: chỉ cho bold / italic. Chọn font nền cần ít faux nhất
    //    (kể cả font hiện tại của A đã bỏ faux, phòng khi font đó không có trong danh sách font cài)
    if (target.weight != "regular" && target.weight != "bold") return false;
    var cands = [];
    for (var m = 0; m < fonts.length; m++) {
        cands.push({ ps: fonts[m].ps, family: fonts[m].family, style: fonts[m].style,
                     c: classifyStyle(fonts[m].style, false, false) });
    }
    cands.push({ ps: ai.font, family: ai.family, style: ai.style, c: classifyStyle(ai.style, false, false) });

    var best = null, bestNeed = 99, bestB = false, bestI = false;
    for (var n = 0; n < cands.length; n++) {
        var c = cands[n].c;
        if (c.weight != "regular" && c.weight != "bold") continue;
        if (c.weight == "bold" && target.weight != "bold") continue; // faux không gỡ được bold thật
        if (c.italic && !target.italic) continue;
        var needB = (target.weight == "bold" && c.weight != "bold");
        var needI = (target.italic && !c.italic);
        var need = (needB ? 1 : 0) + (needI ? 1 : 0);
        if (need < bestNeed) { best = cands[n]; bestNeed = need; bestB = needB; bestI = needI; }
    }
    if (!best || !best.ps) return false;
    setTextFont(A, best.ps, best.family, best.style, bestB, bestI);
    cs_dbg("  [faux] " + best.ps + " B=" + bestB + " I=" + bestI);
    return true;
}

// Mô tả style: weight (tên weight thật của font), bold (bold thật HOẶC faux), italic (italic thật HOẶC faux)
function describeStyle(style, fauxB, fauxI) {
    var c = classifyStyle(style, false, false);
    return { weight: c.weight, bold: /bold|black|heavy/.test(c.weight) || !!fauxB, italic: c.italic || !!fauxI };
}

function parseStyleKey(k) {
    var p = k.split("|");
    var f = p.length > 1 ? p[1] : "00";
    return describeStyle(p[0], f.charAt(0) == "1", f.charAt(1) == "1");
}

// Style A cần có = phần B CÓ THÊM so với style mốc của family B (A "thường" = Regular, đứng thẳng).
// VD mốc là Medium + faux italic, B là Medium + faux italic + faux bold -> A chỉ cần bold (không italic).
// B nhẹ hơn / bằng mốc, không thêm gì -> null (A giữ nguyên).
function styleTargetForA(b, base) {
    var wantBold = b.bold && !base.bold;
    var wantItalic = b.italic && !base.italic;
    var wantWeight = null;
    if (!b.bold && !base.bold && b.weight != "regular" && b.weight != base.weight) wantWeight = b.weight;
    if (!wantBold && !wantItalic && !wantWeight) return null;
    return { weight: wantBold ? "bold" : (wantWeight || "regular"), italic: wantItalic };
}

// B dùng style khác style phổ biến nhất của family B trong file -> A đổi theo phần khác đó. Trả về true nếu đã đổi.
function applyStyleLikeB(A, B) {
    if (!MATCH_STYLE_FROM_B || !STYLE_STATS) return false;
    var bi = getTextInfo(B);
    var ai = getTextInfo(A);
    if (!bi || !ai || !ai.font) return false;
    mergeFaux(bi, B); // faux bold / italic của B (AM + DOM)
    mergeFaux(ai, A);
    var base = getBaseStyleKey(familyKey(bi));
    var cur = classifyStyle(ai.style, ai.fauxB, ai.fauxI);
    var log = "A: " + ai.font + " / " + ai.style + " / faux " + fxStr(ai) +
              "  |  B: " + bi.font + " / " + bi.style + " / faux " + fxStr(bi) +
              "  |  mốc family B: " + base;
    if (base === null || base == styleKey(bi)) { cs_dbg(log + "  => B đúng style mốc, giữ nguyên A"); return false; }
    var target = styleTargetForA(describeStyle(bi.style, bi.fauxB, bi.fauxI), parseStyleKey(base));
    if (!target) { cs_dbg(log + "  => B không thêm bold / italic / weight so với mốc, giữ nguyên A"); return false; }
    log += "  |  A cần: " + target.weight + (target.italic ? "+italic" : "");
    if (sameStyle(cur, target)) { cs_dbg(log + "  => A đã đúng style"); return false; }
    var ok = setStyleVariant(A, ai, target);
    cs_dbg(log + (ok ? "  => đã đổi A" : "  => không có font / faux phù hợp, giữ nguyên A"));
    return ok;
}

// ---------- Auto center: A (text) nằm giữa B (text) ----------
var AUTO_CENTER_TEXT = false;  // panel ghi đè mỗi lần bấm nút
var CENTER_OK = false;         // true khi bật tính năng VÀ mọi layer đang chọn đều là text

// Bounds KHÔNG tính layer style (shadow / stroke / glow lệch 1 phía sẽ làm căn sai) - [trái, trên, phải, dưới] px
function getBoundsNoFx(l) {
    try {
        var d = executeActionGet(layerRef(l, sTID("boundsNoEffects"))).getObjectValue(sTID("boundsNoEffects"));
        return [d.getUnitDoubleValue(ID_LEFT), d.getUnitDoubleValue(ID_TOP),
                d.getUnitDoubleValue(ID_RIGHT), d.getUnitDoubleValue(ID_BOTTOM)];
    } catch (e) {
        var b = l.bounds;
        return [b[0].as("px"), b[1].as("px"), b[2].as("px"), b[3].as("px")];
    }
}

// Dời CHỈ layer A sao cho tâm của A trùng tâm của B. B tuyệt đối không bị đụng tới.
// Gọi sau khi A đã đổi size / font xong (kích thước cuối cùng của A mới đúng).
function centerOnB(A, B) {
    var ab = getBoundsNoFx(A);
    var bb = getBoundsNoFx(B);
    var dx = (bb[0] + bb[2]) / 2 - (ab[0] + ab[2]) / 2;
    var dy = (bb[1] + bb[3]) / 2 - (ab[1] + ab[3]) / 2;
    if (Math.abs(dx) < 0.01 && Math.abs(dy) < 0.01) return false;
    A.translate(new UnitValue(dx, "px"), new UnitValue(dy, "px"));
    cs_dbg("  [center] dx=" + round2(dx) + " dy=" + round2(dy));
    return true;
}

// ---------- Clipping mask ----------
// Layer / group có đang bị clip vào layer bên dưới không?
// (ArtLayer.grouped không có trên LayerSet -> dùng Action Manager cho cả hai)
function isClipped(layer) {
    try {
        var d = executeActionGet(layerRef(layer, ID_GROUP));
        if (d.hasKey(ID_GROUP)) return d.getBoolean(ID_GROUP);
    } catch (e) {}
    try { return layer.grouped == true; } catch (e2) {}
    return false;
}

function setClipped(layer, want) {
    if (isClipped(layer) == want) return;
    app.activeDocument.activeLayer = layer;
    if (want) {
        try { layer.grouped = true; return; } catch (e) {}
        var d = new ActionDescriptor();
        var r = new ActionReference();
        r.putEnumerated(ID_LAYER, ID_ORDINAL, ID_TARGET);
        d.putReference(cTID("null"), r);
        executeAction(sTID("groupEvent"), d, DialogModes.NO);
    } else {
        try { layer.grouped = false; return; } catch (e) {}
        var d2 = new ActionDescriptor();
        var r2 = new ActionReference();
        r2.putEnumerated(ID_LAYER, ID_ORDINAL, ID_TARGET);
        d2.putReference(cTID("null"), r2);
        executeAction(sTID("ungroup"), d2, DialogModes.NO);
    }
}

// Chuỗi clipping chứa layer: base (nền, layer không bị clip nằm dưới cùng)
// và clips (các layer bị clip lên base, thứ tự từ dưới lên trên).
// Layer không bị clip: base = chính nó, clips = các layer clip trực tiếp lên nó.
function getChain(layer) {
    var cont = layer.parent;
    var ls = cont.layers;
    var n = ls.length;
    var k = indexInContainer(cont, layer);
    if (k < 0) return null;
    var bi = k;
    while (bi + 1 < n && isClipped(ls[bi])) bi++;
    var clips = [];
    for (var u = bi - 1; u >= 0; u--) {
        if (!isClipped(ls[u])) break;
        clips.push(ls[u]);
    }
    return { base: ls[bi], clips: clips };
}

// Duplicate THẲNG tới vị trí mong muốn.
// KHÔNG dùng duplicate() trơn rồi move: bản dup chen vào giữa chuỗi clipping của layer gốc
// làm layer gốc (vd dots-pattern) bị mất clipping mask.
function dupAt(src, rel, place) {
    var d = null;
    try { d = src.duplicate(rel, place); } catch (e) { d = null; }
    if (!d) {
        d = src.duplicate();
        d.move(rel, place);
    }
    return d;
}

// Không hiện popup: gặp lỗi / không có gì để copy thì chỉ phát tiếng ting của hệ thống
var SILENT = false; // nhiều layer: bỏ qua im lặng, không ting

function cs_notify() {
    if (SILENT) return;
    try { app.beep(); return; } catch (e) {}
    try { beep(); } catch (e2) {}
}

// ---------- Layer đang chọn ----------
function findLayerById(container, id) {
    var ls = container.layers;
    for (var i = 0; i < ls.length; i++) {
        var l = ls[i];
        if (layerId(l) === id) return l;
        if (l.typename == "LayerSet") {
            var r = findLayerById(l, id);
            if (r) return r;
        }
    }
    return null;
}

// Danh sách layer đang chọn, thứ tự từ dưới lên trên. Lỗi -> chỉ trả về layer active.
function getSelectedLayers(doc) {
    var out = [];
    try {
        var ref = new ActionReference();
        ref.putEnumerated(cTID("Dcmn"), ID_ORDINAL, ID_TARGET);
        var d = executeActionGet(ref);
        if (!d.hasKey(sTID("targetLayers"))) return [doc.activeLayer];
        var list = d.getList(sTID("targetLayers"));
        var hasBg = false;
        try { var bg = doc.backgroundLayer; hasBg = true; } catch (e) {}
        var items = [];
        for (var i = 0; i < list.count; i++) {
            var idx = list.getReference(i).getIndex();
            if (!hasBg) idx += 1;
            var r = new ActionReference();
            r.putProperty(ID_PROPERTY, ID_LAYER_ID);
            r.putIndex(ID_LAYER, idx);
            items.push({ idx: idx, id: executeActionGet(r).getInteger(ID_LAYER_ID) });
        }
        items.sort(function (a, b) { return a.idx - b.idx; });
        for (var k = 0; k < items.length; k++) {
            var L = findLayerById(doc, items[k].id);
            if (L) out.push({ id: items[k].id, layer: L });
        }
    } catch (e) { return [doc.activeLayer]; }
    if (out.length == 0) return [doc.activeLayer];
    var res = [];
    for (var m = 0; m < out.length; m++) res.push(out[m].layer);
    return res;
}

function cs_run() {
    if (app.documents.length == 0) { cs_notify(); return; }
    var doc = app.activeDocument;
    var sel = getSelectedLayers(doc);

    // Auto center chỉ chạy khi TẤT CẢ layer đang chọn là text (B cũng phải là text, kiểm tra ở processLayer)
    CENTER_OK = AUTO_CENTER_TEXT;
    for (var ci = 0; ci < sel.length && CENTER_OK; ci++) if (!isTextLayer(sel[ci])) CENTER_OK = false;

    // Thống kê size mốc của từng font (1 lần, trước khi dup / sửa bất cứ thứ gì)
    FONT_STATS = null;
    STYLE_STATS = null;
    ACTION_FONTS = null;  // panel giữ biến toàn cục giữa các lần bấm -> dò lại action mỗi lần
    FAMILY_FONTS = {};
    if (SCALE_TEXT_BY_B || MATCH_STYLE_FROM_B) {
        try { FONT_STATS = buildFontStats(doc, sel); } catch (e) { FONT_STATS = null; }
    }

    if (sel.length <= 1) {
        SILENT = false;
        EXCLUDE = {};
        processLayer(doc, doc.activeLayer);
        showDebug();
        return;
    }

    // Nhiều layer: mỗi layer copy style từ layer nằm dưới NÓ, layer nào không có gì để copy thì bỏ qua im lặng
    SILENT = true;
    EXCLUDE = {};
    for (var i = 0; i < sel.length; i++) EXCLUDE[getId(sel[i])] = true;
    for (var j = 0; j < sel.length; j++) {
        try { processLayer(doc, sel[j]); } catch (e) {}
    }
    SILENT = false;
    EXCLUDE = {};
    showDebug();
}

function processLayer(doc, A) {

    if (A.typename == "LayerSet") {
        cs_notify();
        return;
    }

    // --- 1. Tìm layer B bên dưới A: gần nhất, hợp lệ, ĐÈ LÊN A trên canvas ---
    var aBounds = getBounds(A);
    var B = findB(doc, A, aBounds);

    if (B === undefined) { cs_notify(); return; }
    if (!B) { cs_notify(); return; }

    // --- 2. Copy & paste layer style ---
    // B không có effect thì vẫn đi tiếp (B có thể chỉ nằm trong group có effect / mask / clip)
    var did = false; // đã copy được thứ gì từ B chưa
    try {
        doc.activeLayer = B;
        executeAction(sTID("copyEffects"), undefined, DialogModes.NO);
        doc.activeLayer = A;
        executeAction(sTID("pasteEffects"), undefined, DialogModes.NO);
        did = true;
    } catch (e) {}

    // --- 2b. Copy mặt nạ trắng đen của B (nếu có) sang A ---
    try {
        // Chỉ chép mask của B khi phần đen của nó thực sự che pixel của B
        if (hasMask(B) && ownMaskHidesPartOfB(B)) { copyMask(B, A); did = true; }
    } catch (e) { cs_notify(); }
    doc.activeLayer = A;


    // --- 2c. Cả A và B đều là text -> A lấy màu chữ của B ---
    if (isTextLayer(A) && isTextLayer(B)) {
        var oldDlg = app.displayDialogs;
        app.displayDialogs = DialogModes.NO; // phòng hộp thoại missing font
        try {
            var tc = getTextColor(B);
            if (tc) { setTextColor(A, tc); did = true; }
        } catch (e) {}
        // A phóng to / thu nhỏ theo tỉ lệ size của B so với size mốc của font B
        try { if (scaleTextLikeB(A, B)) did = true; } catch (e) {}
        // A đổi bold / italic / weight theo B (so với style phổ biến nhất của family B)
        try { if (applyStyleLikeB(A, B)) did = true; } catch (e) {}
        // A tự căn giữa B (sau khi size / font của A đã chốt). Chỉ dời A, không đụng B.
        try { if (CENTER_OK && centerOnB(A, B)) did = true; } catch (e) {}
        app.displayDialogs = oldDlg;
        doc.activeLayer = A;
    }

    // --- 3. Chuỗi clipping của B: base (nền) + các layer clip lên base ---
    var chain = getChain(B);
    if (!chain) { cs_notify(); return; }
    var bClipped = isClipped(B);
    var base = chain.base;
    var groupBase = bClipped && base.typename == "LayerSet"; // B clip lên 1 GROUP
    var layerBase = bClipped && !groupBase;                  // B clip lên 1 layer thường

    // Layer cần dup rồi clip lại:
    //  - base là group: toàn bộ layer đang clip lên group (gồm cả B, vd dots-pattern)
    //  - B không bị clip: chỉ các layer clip lên B mà có phần bị xoá nằm trên pixel của B
    var clipSources = [];
    for (var u = 0; u < chain.clips.length; u++) {
        var C = chain.clips[u];
        if (!C.visible) continue;
        unlockLayer(C); // layer clip bị khoá -> mở khoá rồi làm tiếp
        if (groupBase) clipSources.push(C);
        else if (!bClipped && hasHoleOver(B, C)) clipSources.push(C);
    }
    doc.activeLayer = A;

    // base là layer thường -> dup base để A clip vào
    var baseDup = null;
    if (layerBase) {
        baseDup = dupAt(base, A, ElementPlacement.PLACEBEFORE);
        baseDup.name = base.name;
    }

    // --- 4. Chuẩn bị các group wrapper (bỏ những group A đã nằm sẵn trong) ---
    var aIds = [];
    var aAnc = getAncestors(A);
    for (var x = 0; x < aAnc.length; x++) aIds.push(getId(aAnc[x]));

    var wrappers = [];     // từ trong ra ngoài
    var placeholders = [];
    var wrapperClips = []; // layer đang clip lên group GỐC của từng wrapper (song song với wrappers)

    // Trong cùng: group nền mà B đang bị clip vào -> A nằm TRONG group này, không clip
    if (groupBase) {
        var gd = dupAt(base, A, ElementPlacement.PLACEBEFORE);
        if (!KEEP_GROUP_CONTENTS) stripGroup(gd);
        var ph0 = gd.artLayers.add(); // layer tạm làm mốc để chèn A vào trên cùng group
        ph0.name = "__placeholder__";
        wrappers.push(gd);
        placeholders.push(ph0);
        wrapperClips.push([]);
    }

    var bAnc = getAncestors(B);
    for (var y = 0; y < bAnc.length; y++) {
        // Mask của group chỉ tính khi phần đen của nó che pixel của B
        var gHasMask = false;
        var maskHitsB = false;
        try {
            gHasMask = hasMask(bAnc[y]);
            if (gHasMask) maskHitsB = maskHidesPartOf(B, bAnc[y]);
        } catch (e) { maskHitsB = gHasMask; }
        if (isPlainGroup(bAnc[y], maskHitsB)) continue; // group trơn -> bỏ qua, không dup
        var gid = getId(bAnc[y]);
        var shared = false;
        for (var z = 0; z < aIds.length; z++) if (aIds[z] == gid) { shared = true; break; }
        if (shared) continue;
        // Layer clip lên group gốc (vd dots-pattern): ghi lại TRƯỚC khi dup / di chuyển gì
        var wc = [];
        try {
            if (!isClipped(bAnc[y])) {
                var wch = getChain(bAnc[y]);
                if (wch) for (var wi = 0; wi < wch.clips.length; wi++) {
                    if (wch.clips[wi].visible) {
                        unlockLayer(wch.clips[wi]); // bị khoá -> mở khoá rồi làm tiếp
                        wc.push(wch.clips[wi]);
                    }
                }
            }
        } catch (e) {}
        var w = dupAt(bAnc[y], A, ElementPlacement.PLACEBEFORE);
        // Group phải dup vì lý do khác (effect, blend...) nhưng mask không đụng B -> bỏ mask khỏi bản dup
        if (gHasMask && !maskHitsB) { try { deleteMask(w); } catch (e) {} }
        stripGroup(w);
        w.name = A.name;
        // PLACEINSIDE báo lỗi 1320 với group rỗng -> thêm layer tạm làm mốc
        var ph = w.artLayers.add();
        ph.name = "__placeholder__";
        wrappers.push(w);
        placeholders.push(ph);
        wrapperClips.push(wc);
    }

    // --- 5. Ráp cấu trúc ---
    if (wrappers.length > 0) {
        wrappers[0].move(A, ElementPlacement.PLACEBEFORE);
        if (baseDup) {
            baseDup.move(placeholders[0], ElementPlacement.PLACEBEFORE);
            A.move(baseDup, ElementPlacement.PLACEBEFORE); // A nằm trên base
        } else {
            A.move(placeholders[0], ElementPlacement.PLACEBEFORE);
        }
        for (var n = 1; n < wrappers.length; n++) {
            wrappers[n].move(wrappers[n - 1], ElementPlacement.PLACEBEFORE);
            wrappers[n - 1].move(placeholders[n], ElementPlacement.PLACEBEFORE);
        }
        for (var p = 0; p < placeholders.length; p++) {
            try { placeholders[p].remove(); } catch (e) {}
        }
    } else if (baseDup) {
        baseDup.move(A, ElementPlacement.PLACEAFTER);
    }

    // A clip vào base layer (chỉ khi base là layer thường)
    if (layerBase) setClipped(A, true);

    // Dup các layer clip (vd dots-pattern) đặt ngay trên nền mới rồi clip lại:
    //  - nền mới là group dup (groupBase) -> neo vào group đó
    //  - còn lại -> neo vào A
    var anchor = groupBase ? wrappers[0] : A;
    for (var v = 0; v < clipSources.length; v++) {
        var dd = dupAt(clipSources[v], anchor, ElementPlacement.PLACEBEFORE);
        setClipped(dd, true);
        anchor = dd;
    }

    // Dup layer clip của từng group gốc, clip vào wrapper tương ứng (giữ nguyên effect riêng của chúng)
    for (var wk = 0; wk < wrappers.length; wk++) {
        var wAnchor = wrappers[wk];
        for (var wj = 0; wj < wrapperClips[wk].length; wj++) {
            var wd = dupAt(wrapperClips[wk][wj], wAnchor, ElementPlacement.PLACEBEFORE);
            setClipped(wd, true);
            wAnchor = wd;
        }
    }

    // --- 6. Khôi phục clipping của các layer GỐC (dots-pattern...) ---
    // Photoshop có thể tự gỡ clip của layer gốc khi dup / move base của chúng.
    // Chuỗi clip gốc đã lưu ở bước 3 -> kiểm tra lại, layer nào mất clip thì clip lại.
    var restore = chain.clips.slice(0);
    for (var rk = 0; rk < wrapperClips.length; rk++) restore = restore.concat(wrapperClips[rk]);
    for (var q = 0; q < restore.length; q++) {
        try { setClipped(restore[q], true); } catch (e) {}
    }

    // Không copy được effect / mask / màu chữ và cũng không có group, clip nào để dựng lại -> báo bằng tiếng ting
    if (!did && wrappers.length == 0 && !baseDup && clipSources.length == 0) cs_notify();

    doc.activeLayer = A;
}

// ---------- Điểm vào cho panel ----------
// Panel gọi: copyStylePanelRun(matchStyle, scaleSize, autoCenter, manualBase)
//   manualBase: > 0 = size gốc của B (ô Sp / Nar đang chọn), 0 = tự thống kê như cũ
//   matchStyle: true = copy bold/italic của B    | false = bỏ qua
//   scaleSize : true = chỉnh size A theo tỉ lệ B | false = bỏ qua
//   autoCenter: true = căn A vào giữa B (khi A và B đều là text) | false = bỏ qua
function copyStylePanelRun(matchStyle, scaleSize, autoCenter, manualBase) {
    var mb = parseFloat(manualBase);
    MANUAL_BASE_SIZE = (mb > 0) ? mb : 0;
    MATCH_STYLE_FROM_B = (matchStyle === true || matchStyle === "true");
    SCALE_TEXT_BY_B = (scaleSize === undefined) ? SCALE_TEXT_BY_B : (scaleSize === true || scaleSize === "true");
    AUTO_CENTER_TEXT = (autoCenter === true || autoCenter === "true");
    if (app.documents.length > 0) {
        app.activeDocument.suspendHistory("Copy Style From Below", "cs_run()");
    } else {
        cs_notify();
    }
    return "ok";
}

;
// ============================================================
// Typertool: apply a line-break option AND centre the layer in ONE host call
//
// The stock flow was: write the text (one history state) -> ask for the layer
// box -> save the selection to a channel, move the layer, reload the selection
// (a second history state) -> re-read the whole layer. Five round trips and a
// lot of document work for every click.
//
// This version does the same job in a single call and a single history state:
//   1. writes the text with the stock TypeR routine (_setTextShapeRText),
//   2. moves ONLY the layer so its centre lands on the target,
//   3. checks the selection outline: if anything dragged it along with the
//      layer, it is moved straight back (outline only, never the pixels).
// No selection channel, no layer re-selection, no extra history state.
// (ExtendScript = ES3: var / function only.)
// ============================================================

var _liteApply = {"data": null, "result": "", "bounds": null};

function _liteSelKey(r) {
    return r ? r.left + "," + r.top + "," + r.right + "," + r.bottom : "";
}

// Moves the selection outline only (Move tool on a selection): not the layer,
// not the pixels
function _liteMoveSelectionBy(dx, dy) {
    var ref = new ActionReference();
    ref.putProperty(charID.Channel, charID.FrameSelect);
    var offset = new ActionDescriptor();
    offset.putUnitDouble(charID.Horizontal, charID.PixelUnit, dx);
    offset.putUnitDouble(charID.Vertical, charID.PixelUnit, dy);
    var desc = new ActionDescriptor();
    desc.putReference(charID.Null, ref);
    desc.putObject(charID.To, charID.Offset, offset);
    executeAction(charID.Move, desc, DialogModes.NO);
}

// The point the text should be centred on, or null (the text keeps its own centre):
// the centre of the box of the live selection. Nothing else is computed: no outline,
// no tail, no extra round trip (the panel only says "centre on the selection").
function _liteTarget(center, live) {
    if (!center || !live) return null;
    if (live.width * live.height < _MIN_BUBBLE_AREA) return null;
    return {"x": live.xMid, "y": live.yMid};
}

// Text of a layer without line breaks / spaces: two texts that differ only in their line
// breaks are the same words
function _liteWords(value) {
    return String(value === undefined || value === null ? "" : value).replace(/[\s\u0003\u2028\u2029]+/g, "");
}

// Is the active layer still the one the options were made for? (the panel does not poll
// Photoshop any more, so it checks right before it writes)
function _liteStale(expect) {
    if (!expect) return false;
    try {
        if (expect.layerId !== undefined && expect.layerId !== null && Number(expect.layerId) !== Number(_getActiveLayerId())) return true;
        if (expect.text !== undefined) {
            var now = app.activeDocument.activeLayer.textItem.contents;
            if (_liteWords(now) !== _liteWords(expect.text)) return true;
        }
    } catch (e) {
        return false; // cannot tell: let the write decide
    }
    return false;
}

function _liteApplyRun() {
    var s = _liteApply;
    var d = s.data;
    s.result = "";
    s.bounds = null;
    try {
        if (_liteStale(d.expect)) {
            s.result = "stale";
            return;
        }
        var before = _liveSelectionBounds(); // also used to keep the selection where it was
        var target = d.center ? _liteTarget(d.center, before) : null;

        // 1. the text. Content only: the line breaks change and NOTHING else (size, font,
        //    leading, colour, stroke stay exactly as they are). The layer keeps its own
        //    centre unless a target was given.
        var e = d.text;
        var oldBox = target ? null : _currentLayerBox(); // only needed to keep the old centre
        var written = false;
        if (e && e.contentOnly) {
            try {
                app.activeDocument.activeLayer.textItem.contents = _normalizeTextKey(e.text);
                written = true;
            } catch (contentError) {
                written = false;
            }
        }
        if (written) {
            if (!target && oldBox) _recentreOnBox(oldBox);
        } else {
            // fallback: the stock TypeR routine (it also restores the old centre)
            var styled = e && e.text && e.style && e.style.textProps && e.style.textProps.layerText
                && e.style.textProps.layerText.textStyleRange && e.style.textProps.layerText.textStyleRange[0];
            if (styled) {
                var t = _hostState.setTextShapeRText;
                t.data = e;
                t.result = "";
                _setTextShapeRText();
                if (t.result) {
                    s.result = String(t.result);
                    return;
                }
            } else {
                var a = _hostState.setActiveLayerText;
                a.data = e;
                a.result = "";
                _setActiveLayerText();
                if (a.result) {
                    s.result = String(a.result);
                    return;
                }
            }
        }

        // 2. only the layer moves
        if (target) {
            var box = _currentLayerBox();
            if (box) {
                var dx = target.x - box.xMid;
                var dy = target.y - box.yMid;
                if (Math.abs(dx) >= 0.01 || Math.abs(dy) >= 0.01) _moveLayer(dx, dy);
            }
        }

        // 3. the selection must stay exactly where it was (best effort: the text is
        //    already written, so a problem here must never turn into an error)
        if (before) {
            try {
                var after = _liveSelectionBounds();
                if (after && (after.left !== before.left || after.top !== before.top)) {
                    _liteMoveSelectionBy(before.left - after.left, before.top - after.top);
                }
            } catch (guardError) {}
        }

        s.bounds = _getCurrentTextLayerBounds();
    } catch (err) {
        s.result = "scriptError: " + (err && err.message ? err.message : err);
    }
}

// payload: { text: { text, contentOnly: true }, center: true | null (centre on the selection),
//            expect: { layerId, text } | null (refuse when the layer is not that one any more) }
// returns JSON { error, bounds, signature }; signature has the format of
// getActiveLayerTextIfChanged so the panel need not re-read the layer
function typertoolApply(payload) {
    if (!documents.length) return jamJSON.stringify({"error": "doc", "bounds": null, "signature": ""});
    var s = _liteApply;
    s.data = payload;
    s.result = "";
    s.bounds = null;
    try {
        app.activeDocument.suspendHistory("TyperTools Change", "_liteApplyRun()");
    } catch (err) {
        s.result = "scriptError: " + (err && err.message ? err.message : err);
    }
    var signature = "";
    try {
        signature = String(_getActiveLayerId()) + ":" + String(_getActiveHistoryIndex());
    } catch (err2) {}
    var out = {"error": s.result, "bounds": s.bounds, "signature": signature};
    s.data = null;
    return jamJSON.stringify(out);
}

// ============================================================
// Check type: the text of the layers, read only when the panel asks.
// typertoolDocKey()    - which document is in front (cheap, one call)
// typertoolScanTexts() - every text layer of that document, in ONE pass over the layer
//                        indexes (the same flat ActionManager walk as the font scan: no DOM
//                        tree walk, no activeLayer switching). The panel runs it once per document;
//                        after that it only re-reads the layer you changed (getActiveLayerText).
// ============================================================

function typertoolDocKey() {
    try {
        if (!documents.length) return "";
        var doc = app.activeDocument;
        var id = "";
        try {
            id = String(doc.id);
        } catch (idError) {}
        return id + "|" + doc.name;
    } catch (error) {
        return "";
    }
}

function typertoolScanTexts() {
    if (!documents.length) return jamJSON.stringify({"error": "doc"});
    var propId = charIDToTypeID("Prpr");
    var layerRef = charIDToTypeID("Lyr ");
    var docRef = charIDToTypeID("Dcmn");
    var ordinalId = charIDToTypeID("Ordn");
    var targetId = charIDToTypeID("Trgt");
    var nameId = charIDToTypeID("Nm  ");
    var layerIdKey = stringIDToTypeID("layerID");
    var kindId = stringIDToTypeID("layerKind");
    var countId = stringIDToTypeID("numberOfLayers");
    var backgroundId = stringIDToTypeID("hasBackgroundLayer");
    var boundsKeys = [stringIDToTypeID("boundsNoEffects"), stringIDToTypeID("bounds")];

    var docProperty = function (key) {
        var ref = new ActionReference();
        ref.putProperty(propId, key);
        ref.putEnumerated(docRef, ordinalId, targetId);
        return executeActionGet(ref);
    };
    var layerProperty = function (key, index) {
        var ref = new ActionReference();
        ref.putProperty(propId, key);
        ref.putIndex(layerRef, index);
        return executeActionGet(ref);
    };

    var layerCount = 0;
    try {
        layerCount = docProperty(countId).getInteger(countId);
    } catch (countError) {
        return jamJSON.stringify({"error": "count"});
    }
    var hasBackground = false;
    try {
        hasBackground = docProperty(backgroundId).getBoolean(backgroundId);
    } catch (backgroundError) {}
    // Layer indexes are 0-based when a background layer exists, 1-based otherwise
    var first = hasBackground ? 0 : 1;
    var last = hasBackground ? layerCount - 1 : layerCount;

    var layers = [];
    var saveMeaningful = jamEngine.meaningfulIds;
    var saveParseFriendly = jamEngine.parseFriendly;
    jamEngine.meaningfulIds = true;
    jamEngine.parseFriendly = true;
    try {
        for (var i = first; i <= last; i++) {
            try {
                // groups and their end markers are not text layers (kind 3 is)
                if (layerProperty(kindId, i).getInteger(kindId) !== 3) continue;
                var got = jamEngine.jsonGet([
                    {"property": {"<property>": "textKey"}},
                    {"layer": {"<index>": i}}
                ]);
                if (!("textKey" in got)) continue;
                var params = jamText.fromLayerTextObject(got["textKey"]);
                if (!params || !params.layerText) continue;
                var name = "";
                try {
                    name = layerProperty(nameId, i).getString(nameId);
                } catch (nameError) {}
                var id = layerProperty(layerIdKey, i).getInteger(layerIdKey);
                // where the text sits on the page (the panel lists the closest texts together)
                var box = null;
                for (var k = 0; k < boundsKeys.length && !box; k++) {
                    try {
                        var b = layerProperty(boundsKeys[k], i).getObjectValue(boundsKeys[k]);
                        box = {
                            "left": b.getUnitDoubleValue(charIDToTypeID("Left")),
                            "top": b.getUnitDoubleValue(charIDToTypeID("Top ")),
                            "right": b.getUnitDoubleValue(charIDToTypeID("Rght")),
                            "bottom": b.getUnitDoubleValue(charIDToTypeID("Btom"))
                        };
                    } catch (boundsError) {}
                }
                layers.push({"id": id, "name": name, "text": String(params.layerText.textKey || ""), "box": box});
            } catch (layerError) {}
        }
    } finally {
        jamEngine.meaningfulIds = saveMeaningful;
        jamEngine.parseFriendly = saveParseFriendly;
    }
    return jamJSON.stringify({"docKey": typertoolDocKey(), "layers": layers});
}
